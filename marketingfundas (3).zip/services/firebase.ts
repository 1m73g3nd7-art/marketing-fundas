import AsyncStorage from '@react-native-async-storage/async-storage';
import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import * as FirebaseAuth from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { Platform } from 'react-native';

/**
 * Firebase is optional. Drop your credentials into a `.env` file (see
 * `.env.example`) and the whole app switches from the bundled sample data to
 * live Firebase Authentication + Firestore with no other code changes.
 *
 * Firestore layout the rest of the app expects — this is also the shape an
 * admin console should write to:
 *
 *   users/{uid}                                  → UserProfile
 *   users/{uid}/enrollments/{courseId}           → Enrollment
 *   users/{uid}/quizAttempts/{attemptId}         → QuizAttempt
 *   users/{uid}/certificates/{certificateId}     → Certificate
 *   users/{uid}/notifications/{notificationId}   → AppNotification
 *   users/{uid}/notes/{lessonId}                 → { text, updatedAt }
 *   courses/{courseId}                           → Course (sections + lessons embedded)
 *   quizzes/{quizId}                             → Quiz
 *   notifications/{notificationId}               → AppNotification (broadcast)
 */

const firebaseConfig = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
};

const REQUIRED_KEYS = ['apiKey', 'authDomain', 'projectId', 'appId'] as const;

export const isFirebaseConfigured = REQUIRED_KEYS.every(
  (key) => typeof firebaseConfig[key] === 'string' && firebaseConfig[key]!.length > 0,
);

/** Google OAuth client ids — only needed for the Google Sign-In button. */
export const googleClientIds = {
  expo: process.env.EXPO_PUBLIC_GOOGLE_EXPO_CLIENT_ID,
  ios: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID,
  android: process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID,
  web: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
};

export const isGoogleConfigured =
  isFirebaseConfigured && Object.values(googleClientIds).some(Boolean);

let app: FirebaseApp | null = null;
let authInstance: FirebaseAuth.Auth | null = null;
let dbInstance: Firestore | null = null;

const getFirebaseApp = (): FirebaseApp | null => {
  if (!isFirebaseConfigured) return null;
  if (app) return app;
  app = getApps().length ? getApp() : initializeApp(firebaseConfig as Required<typeof firebaseConfig>);
  return app;
};

export const getFirebaseAuth = (): FirebaseAuth.Auth | null => {
  const instance = getFirebaseApp();
  if (!instance) return null;
  if (authInstance) return authInstance;

  if (Platform.OS === 'web') {
    authInstance = FirebaseAuth.getAuth(instance);
  } else {
    // `getReactNativePersistence` only exists in the React Native build of
    // firebase/auth, which the published browser typings do not describe.
    const getReactNativePersistence = (
      FirebaseAuth as unknown as {
        getReactNativePersistence?: (storage: unknown) => FirebaseAuth.Persistence;
      }
    ).getReactNativePersistence;

    try {
      authInstance = getReactNativePersistence
        ? FirebaseAuth.initializeAuth(instance, {
            persistence: getReactNativePersistence(AsyncStorage),
          })
        : FirebaseAuth.getAuth(instance);
    } catch {
      // initializeAuth throws if it already ran (fast refresh) — fall back.
      authInstance = FirebaseAuth.getAuth(instance);
    }
  }
  return authInstance;
};

export const getDb = (): Firestore | null => {
  const instance = getFirebaseApp();
  if (!instance) return null;
  if (!dbInstance) dbInstance = getFirestore(instance);
  return dbInstance;
};

export const firebaseErrorMessage = (error: unknown): string => {
  const code = (error as { code?: string })?.code ?? '';
  switch (code) {
    case 'auth/invalid-email':
      return 'That email address does not look right.';
    case 'auth/user-disabled':
      return 'This account has been disabled. Contact support for help.';
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Email or password is incorrect.';
    case 'auth/email-already-in-use':
      return 'An account already exists with this email.';
    case 'auth/weak-password':
      return 'Choose a stronger password (at least 8 characters).';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please wait a moment and try again.';
    case 'auth/network-request-failed':
      return 'Network problem. Check your connection and try again.';
    case 'auth/requires-recent-login':
      return 'Please sign in again before making this change.';
    default:
      return (error as { message?: string })?.message ?? 'Something went wrong. Please try again.';
  }
};
