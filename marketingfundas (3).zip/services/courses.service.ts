import { collection, doc, getDoc, getDocs } from 'firebase/firestore';

import { SAMPLE_COURSES } from '@/data/courses';
import { SAMPLE_QUIZZES } from '@/data/quizzes';
import type { Course, Quiz } from '@/types';
import { getDb, isFirebaseConfigured } from './firebase';

/**
 * Reads the catalogue from Firestore when it is configured and falls back to
 * the bundled sample catalogue otherwise (or when the network call fails), so
 * the app is always browsable.
 */
export const coursesService = {
  async listCourses(): Promise<Course[]> {
    const db = getDb();
    if (!isFirebaseConfigured || !db) return SAMPLE_COURSES;
    try {
      const snap = await getDocs(collection(db, 'courses'));
      if (snap.empty) return SAMPLE_COURSES;
      return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Course, 'id'>) }));
    } catch {
      return SAMPLE_COURSES;
    }
  },

  async getCourse(courseId: string): Promise<Course | undefined> {
    const db = getDb();
    if (!isFirebaseConfigured || !db) return SAMPLE_COURSES.find((c) => c.id === courseId);
    try {
      const snap = await getDoc(doc(db, 'courses', courseId));
      if (!snap.exists()) return SAMPLE_COURSES.find((c) => c.id === courseId);
      return { id: snap.id, ...(snap.data() as Omit<Course, 'id'>) };
    } catch {
      return SAMPLE_COURSES.find((c) => c.id === courseId);
    }
  },

  async listQuizzes(): Promise<Quiz[]> {
    const db = getDb();
    if (!isFirebaseConfigured || !db) return SAMPLE_QUIZZES;
    try {
      const snap = await getDocs(collection(db, 'quizzes'));
      if (snap.empty) return SAMPLE_QUIZZES;
      return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Quiz, 'id'>) }));
    } catch {
      return SAMPLE_QUIZZES;
    }
  },
};
