import { collection, getDocs, setDoc, doc } from 'firebase/firestore';

import { STORAGE_KEYS } from '@/constants/config';
import { SAMPLE_NOTIFICATIONS } from '@/data/notifications';
import type { AppNotification } from '@/types';
import { getDb, isFirebaseConfigured } from './firebase';
import { storage, userKey } from './storage';

export const notificationsService = {
  async list(uid: string): Promise<AppNotification[]> {
    const db = isFirebaseConfigured ? getDb() : null;
    if (db) {
      try {
        const snap = await getDocs(collection(db, 'users', uid, 'notifications'));
        if (!snap.empty) {
          return snap.docs
            .map((d) => ({ id: d.id, ...(d.data() as Omit<AppNotification, 'id'>) }))
            .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        }
      } catch {
        // fall through to local
      }
    }
    const stored = await storage.get<AppNotification[] | null>(
      userKey(uid, STORAGE_KEYS.notifications),
      null,
    );
    if (stored) return stored;
    await storage.set(userKey(uid, STORAGE_KEYS.notifications), SAMPLE_NOTIFICATIONS);
    return SAMPLE_NOTIFICATIONS;
  },

  async save(uid: string, notifications: AppNotification[]): Promise<void> {
    await storage.set(userKey(uid, STORAGE_KEYS.notifications), notifications);
    const db = isFirebaseConfigured ? getDb() : null;
    if (!db) return;
    try {
      await Promise.all(
        notifications.map((n) => setDoc(doc(db, 'users', uid, 'notifications', n.id), n)),
      );
    } catch {
      // ignore
    }
  },
};
