import { STORAGE_KEYS } from '@/constants/config';
import type { AppSettings } from '@/types';
import { storage } from './storage';

export const DEFAULT_SETTINGS: AppSettings = {
  themeMode: 'system',
  pushEnabled: true,
  emailEnabled: true,
  learningReminders: true,
  quizReminders: true,
  autoplay: true,
  downloadOverWifiOnly: true,
  profilePublic: false,
};

export const settingsService = {
  async load(): Promise<AppSettings> {
    const stored = await storage.get<Partial<AppSettings>>(STORAGE_KEYS.settings, {});
    return { ...DEFAULT_SETTINGS, ...stored };
  },
  async save(settings: AppSettings): Promise<void> {
    await storage.set(STORAGE_KEYS.settings, settings);
  },
};
