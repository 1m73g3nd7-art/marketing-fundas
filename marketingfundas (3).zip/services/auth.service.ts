import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut as fbSignOut,
  updatePassword as fbUpdatePassword,
  updateProfile as fbUpdateProfile,
  reauthenticateWithCredential,
  EmailAuthProvider,
  GoogleAuthProvider,
  signInWithCredential,
  deleteUser,
  type User,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';

import { STORAGE_KEYS } from '@/constants/config';
import type { UserProfile } from '@/types';
import { createId } from '@/utils/id';
import { getDb, getFirebaseAuth, isFirebaseConfigured } from './firebase';
import { storage } from './storage';

export interface SignUpInput {
  fullName: string;
  email: string;
  phone: string;
  password: string;
}

interface LocalUserRecord extends UserProfile {
  password: string;
}

/* ------------------------------------------------------------------ */
/* Local (demo) auth — used whenever Firebase is not configured        */
/* ------------------------------------------------------------------ */

const readLocalUsers = () => storage.get<LocalUserRecord[]>(STORAGE_KEYS.users, []);
const writeLocalUsers = (users: LocalUserRecord[]) => storage.set(STORAGE_KEYS.users, users);

const stripPassword = ({ password: _password, ...profile }: LocalUserRecord): UserProfile => profile;

const localSignUp = async (input: SignUpInput): Promise<UserProfile> => {
  const users = await readLocalUsers();
  const email = input.email.trim().toLowerCase();
  if (users.some((u) => u.email === email)) {
    throw new Error('An account already exists with this email.');
  }
  const record: LocalUserRecord = {
    uid: createId('user'),
    fullName: input.fullName.trim(),
    email,
    phone: input.phone.trim(),
    password: input.password,
    createdAt: new Date().toISOString(),
    provider: 'demo',
  };
  await writeLocalUsers([...users, record]);
  const profile = stripPassword(record);
  await storage.set(STORAGE_KEYS.session, profile);
  return profile;
};

const localSignIn = async (email: string, password: string): Promise<UserProfile> => {
  const users = await readLocalUsers();
  const record = users.find((u) => u.email === email.trim().toLowerCase());
  if (!record || record.password !== password) {
    throw new Error('Email or password is incorrect.');
  }
  const profile = stripPassword(record);
  await storage.set(STORAGE_KEYS.session, profile);
  return profile;
};

const localGoogleSignIn = async (): Promise<UserProfile> => {
  const users = await readLocalUsers();
  const email = 'demo.learner@marketingfundas.com';
  let record = users.find((u) => u.email === email);
  if (!record) {
    record = {
      uid: 'user_demo_google',
      fullName: 'Demo Learner',
      email,
      phone: '+91 90000 00000',
      password: createId('pwd'),
      photoURL: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=256&q=80',
      createdAt: new Date().toISOString(),
      provider: 'demo',
    };
    await writeLocalUsers([...users, record]);
  }
  const profile = stripPassword(record);
  await storage.set(STORAGE_KEYS.session, profile);
  return profile;
};

const localUpdateProfile = async (uid: string, patch: Partial<UserProfile>) => {
  const users = await readLocalUsers();
  const next = users.map((u) => (u.uid === uid ? { ...u, ...patch } : u));
  await writeLocalUsers(next);
  const updated = next.find((u) => u.uid === uid);
  if (updated) {
    const profile = stripPassword(updated);
    await storage.set(STORAGE_KEYS.session, profile);
    return profile;
  }
  throw new Error('Account not found.');
};

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

const profileFromFirebaseUser = (user: User, extra?: Partial<UserProfile>): UserProfile => ({
  uid: user.uid,
  fullName: user.displayName ?? extra?.fullName ?? 'Learner',
  email: user.email ?? extra?.email ?? '',
  phone: extra?.phone,
  photoURL: user.photoURL ?? extra?.photoURL ?? undefined,
  headline: extra?.headline,
  createdAt: extra?.createdAt ?? new Date().toISOString(),
  provider: extra?.provider ?? (user.providerData[0]?.providerId === 'google.com' ? 'google' : 'password'),
});

const fetchRemoteProfile = async (user: User): Promise<UserProfile> => {
  const db = getDb();
  if (!db) return profileFromFirebaseUser(user);
  const snap = await getDoc(doc(db, 'users', user.uid));
  const extra = snap.exists() ? (snap.data() as Partial<UserProfile>) : undefined;
  return profileFromFirebaseUser(user, extra);
};

export const authService = {
  isRemote: isFirebaseConfigured,

  /** Restores the persisted session on app start. */
  async restoreSession(): Promise<UserProfile | null> {
    if (!isFirebaseConfigured) {
      return storage.get<UserProfile | null>(STORAGE_KEYS.session, null);
    }
    const auth = getFirebaseAuth();
    if (!auth) return null;
    return new Promise((resolve) => {
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        unsubscribe();
        if (!user) return resolve(null);
        try {
          resolve(await fetchRemoteProfile(user));
        } catch {
          resolve(profileFromFirebaseUser(user));
        }
      });
    });
  },

  async signUp(input: SignUpInput): Promise<UserProfile> {
    if (!isFirebaseConfigured) return localSignUp(input);

    const auth = getFirebaseAuth()!;
    const credential = await createUserWithEmailAndPassword(
      auth,
      input.email.trim(),
      input.password,
    );
    await fbUpdateProfile(credential.user, { displayName: input.fullName.trim() });

    const profile: UserProfile = {
      uid: credential.user.uid,
      fullName: input.fullName.trim(),
      email: input.email.trim().toLowerCase(),
      phone: input.phone.trim(),
      createdAt: new Date().toISOString(),
      provider: 'password',
    };

    const db = getDb();
    if (db) await setDoc(doc(db, 'users', profile.uid), profile);
    return profile;
  },

  async signIn(email: string, password: string): Promise<UserProfile> {
    if (!isFirebaseConfigured) return localSignIn(email, password);
    const auth = getFirebaseAuth()!;
    const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
    return fetchRemoteProfile(credential.user);
  },

  /**
   * Completes Google sign-in with an id token obtained from expo-auth-session.
   * When Firebase/Google are not configured the caller falls back to a demo
   * account so the button still leads somewhere sensible.
   */
  async signInWithGoogleIdToken(idToken?: string): Promise<UserProfile> {
    if (!isFirebaseConfigured || !idToken) return localGoogleSignIn();
    const auth = getFirebaseAuth()!;
    const credential = GoogleAuthProvider.credential(idToken);
    const result = await signInWithCredential(auth, credential);
    const profile = profileFromFirebaseUser(result.user, { provider: 'google' });
    const db = getDb();
    if (db) await setDoc(doc(db, 'users', profile.uid), profile, { merge: true });
    return profile;
  },

  async signOut(): Promise<void> {
    if (!isFirebaseConfigured) {
      await storage.remove(STORAGE_KEYS.session);
      return;
    }
    const auth = getFirebaseAuth();
    if (auth) await fbSignOut(auth);
  },

  async resetPassword(email: string): Promise<void> {
    if (!isFirebaseConfigured) {
      const users = await readLocalUsers();
      if (!users.some((u) => u.email === email.trim().toLowerCase())) {
        throw new Error('No account found with that email.');
      }
      return;
    }
    const auth = getFirebaseAuth()!;
    await sendPasswordResetEmail(auth, email.trim());
  },

  async updateProfile(uid: string, patch: Partial<UserProfile>): Promise<UserProfile> {
    if (!isFirebaseConfigured) return localUpdateProfile(uid, patch);

    const auth = getFirebaseAuth()!;
    const user = auth.currentUser;
    if (user) {
      await fbUpdateProfile(user, {
        displayName: patch.fullName ?? user.displayName,
        photoURL: patch.photoURL ?? user.photoURL,
      });
    }
    const db = getDb();
    if (db) await setDoc(doc(db, 'users', uid), patch, { merge: true });
    if (!user) throw new Error('You are signed out. Please sign in again.');
    return fetchRemoteProfile(user);
  },

  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    if (!isFirebaseConfigured) {
      const session = await storage.get<UserProfile | null>(STORAGE_KEYS.session, null);
      if (!session) throw new Error('You are signed out. Please sign in again.');
      const users = await readLocalUsers();
      const record = users.find((u) => u.uid === session.uid);
      if (!record) throw new Error('Account not found.');
      if (record.password !== currentPassword) throw new Error('Current password is incorrect.');
      await writeLocalUsers(
        users.map((u) => (u.uid === session.uid ? { ...u, password: newPassword } : u)),
      );
      return;
    }

    const auth = getFirebaseAuth()!;
    const user = auth.currentUser;
    if (!user?.email) throw new Error('You are signed out. Please sign in again.');
    const credential = EmailAuthProvider.credential(user.email, currentPassword);
    await reauthenticateWithCredential(user, credential);
    await fbUpdatePassword(user, newPassword);
  },

  async deleteAccount(): Promise<void> {
    if (!isFirebaseConfigured) {
      const session = await storage.get<UserProfile | null>(STORAGE_KEYS.session, null);
      if (session) {
        const users = await readLocalUsers();
        await writeLocalUsers(users.filter((u) => u.uid !== session.uid));
      }
      await storage.remove(STORAGE_KEYS.session);
      return;
    }
    const auth = getFirebaseAuth()!;
    const user = auth.currentUser;
    if (!user) throw new Error('You are signed out. Please sign in again.');
    const db = getDb();
    if (db) {
      await updateDoc(doc(db, 'users', user.uid), { deletedAt: new Date().toISOString() }).catch(
        () => undefined,
      );
      await deleteDoc(doc(db, 'users', user.uid)).catch(() => undefined);
    }
    await deleteUser(user);
  },
};
