import { collection, deleteDoc, doc, getDocs, setDoc } from 'firebase/firestore';

import { STORAGE_KEYS } from '@/constants/config';
import type { Certificate, Enrollment, QuizAttempt } from '@/types';
import { getDb, isFirebaseConfigured } from './firebase';
import { storage, userKey } from './storage';

/** Minutes of study recorded per ISO date (YYYY-MM-DD), used for streaks/charts. */
export type ActivityLog = Record<string, number>;

/** Per-lesson notes, keyed by lesson id. */
export type NotesMap = Record<string, string>;

const remote = () => (isFirebaseConfigured ? getDb() : null);

export const learningService = {
  /* ---------------------------- enrollments ---------------------------- */

  async listEnrollments(uid: string): Promise<Record<string, Enrollment>> {
    const db = remote();
    if (db) {
      try {
        const snap = await getDocs(collection(db, 'users', uid, 'enrollments'));
        const map: Record<string, Enrollment> = {};
        snap.docs.forEach((d) => {
          map[d.id] = { courseId: d.id, ...(d.data() as Omit<Enrollment, 'courseId'>) };
        });
        return map;
      } catch {
        // fall through to local cache
      }
    }
    return storage.get<Record<string, Enrollment>>(userKey(uid, STORAGE_KEYS.enrollments), {});
  },

  async saveEnrollment(uid: string, enrollment: Enrollment): Promise<void> {
    const current = await storage.get<Record<string, Enrollment>>(
      userKey(uid, STORAGE_KEYS.enrollments),
      {},
    );
    await storage.set(userKey(uid, STORAGE_KEYS.enrollments), {
      ...current,
      [enrollment.courseId]: enrollment,
    });

    const db = remote();
    if (db) {
      try {
        await setDoc(doc(db, 'users', uid, 'enrollments', enrollment.courseId), enrollment);
      } catch {
        // Local copy already saved; remote will re-sync on the next write.
      }
    }
  },

  async removeEnrollment(uid: string, courseId: string): Promise<void> {
    const current = await storage.get<Record<string, Enrollment>>(
      userKey(uid, STORAGE_KEYS.enrollments),
      {},
    );
    delete current[courseId];
    await storage.set(userKey(uid, STORAGE_KEYS.enrollments), current);

    const db = remote();
    if (db) {
      try {
        await deleteDoc(doc(db, 'users', uid, 'enrollments', courseId));
      } catch {
        // ignore
      }
    }
  },

  /* --------------------------- quiz attempts --------------------------- */

  async listQuizAttempts(uid: string): Promise<QuizAttempt[]> {
    const db = remote();
    if (db) {
      try {
        const snap = await getDocs(collection(db, 'users', uid, 'quizAttempts'));
        if (!snap.empty) {
          return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<QuizAttempt, 'id'>) }));
        }
      } catch {
        // fall through
      }
    }
    return storage.get<QuizAttempt[]>(userKey(uid, STORAGE_KEYS.quizAttempts), []);
  },

  async saveQuizAttempt(uid: string, attempt: QuizAttempt): Promise<void> {
    const current = await storage.get<QuizAttempt[]>(userKey(uid, STORAGE_KEYS.quizAttempts), []);
    await storage.set(userKey(uid, STORAGE_KEYS.quizAttempts), [attempt, ...current]);

    const db = remote();
    if (db) {
      try {
        await setDoc(doc(db, 'users', uid, 'quizAttempts', attempt.id), attempt);
      } catch {
        // ignore
      }
    }
  },

  /* ---------------------------- certificates --------------------------- */

  async listCertificates(uid: string): Promise<Certificate[]> {
    const db = remote();
    if (db) {
      try {
        const snap = await getDocs(collection(db, 'users', uid, 'certificates'));
        if (!snap.empty) {
          return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Certificate, 'id'>) }));
        }
      } catch {
        // fall through
      }
    }
    return storage.get<Certificate[]>(userKey(uid, STORAGE_KEYS.certificates), []);
  },

  async saveCertificate(uid: string, certificate: Certificate): Promise<void> {
    const current = await storage.get<Certificate[]>(userKey(uid, STORAGE_KEYS.certificates), []);
    const next = [certificate, ...current.filter((c) => c.id !== certificate.id)];
    await storage.set(userKey(uid, STORAGE_KEYS.certificates), next);

    const db = remote();
    if (db) {
      try {
        await setDoc(doc(db, 'users', uid, 'certificates', certificate.id), certificate);
      } catch {
        // ignore
      }
    }
  },

  /* -------------------------------- notes ------------------------------ */

  async listNotes(uid: string): Promise<NotesMap> {
    return storage.get<NotesMap>(userKey(uid, STORAGE_KEYS.notes), {});
  },

  async saveNote(uid: string, lessonId: string, text: string): Promise<NotesMap> {
    const notes = await storage.get<NotesMap>(userKey(uid, STORAGE_KEYS.notes), {});
    const next = { ...notes, [lessonId]: text };
    if (!text.trim()) delete next[lessonId];
    await storage.set(userKey(uid, STORAGE_KEYS.notes), next);

    const db = remote();
    if (db) {
      try {
        await setDoc(doc(db, 'users', uid, 'notes', lessonId), {
          text,
          updatedAt: new Date().toISOString(),
        });
      } catch {
        // ignore
      }
    }
    return next;
  },

  /* ------------------------------ activity ----------------------------- */

  async getActivity(uid: string): Promise<ActivityLog> {
    return storage.get<ActivityLog>(userKey(uid, STORAGE_KEYS.activity), {});
  },

  async addActivityMinutes(uid: string, minutes: number): Promise<ActivityLog> {
    const log = await storage.get<ActivityLog>(userKey(uid, STORAGE_KEYS.activity), {});
    const key = new Date().toISOString().slice(0, 10);
    const next = { ...log, [key]: Math.round((log[key] ?? 0) + minutes) };
    await storage.set(userKey(uid, STORAGE_KEYS.activity), next);
    return next;
  },

  /* ------------------------------ wishlist ----------------------------- */

  async getWishlist(uid: string): Promise<string[]> {
    return storage.get<string[]>(userKey(uid, STORAGE_KEYS.wishlist), []);
  },

  async setWishlist(uid: string, ids: string[]): Promise<void> {
    await storage.set(userKey(uid, STORAGE_KEYS.wishlist), ids);
  },

  /** Clears every local record for a user (used by sign-out / delete account). */
  async clearLocal(uid: string): Promise<void> {
    await storage.multiRemove([
      userKey(uid, STORAGE_KEYS.enrollments),
      userKey(uid, STORAGE_KEYS.quizAttempts),
      userKey(uid, STORAGE_KEYS.certificates),
      userKey(uid, STORAGE_KEYS.notes),
      userKey(uid, STORAGE_KEYS.activity),
      userKey(uid, STORAGE_KEYS.notifications),
      userKey(uid, STORAGE_KEYS.wishlist),
    ]);
  },
};
