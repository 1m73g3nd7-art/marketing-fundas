import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform, Share } from 'react-native';

import type { Certificate } from '@/types';
import { certificateHtml } from '@/utils/certificate-html';

export const certificateService = {
  /** Renders the certificate to a PDF and returns its local file URI. */
  async toPdf(certificate: Certificate): Promise<string> {
    const { uri } = await Print.printToFileAsync({
      html: certificateHtml(certificate),
      base64: false,
      width: 1123,
      height: 794,
    });
    return uri;
  },

  /** Opens the platform share sheet with the generated PDF attached. */
  async share(certificate: Certificate): Promise<void> {
    const message = `I completed "${certificate.courseTitle}" on Marketing Fundas. Certificate ID: ${certificate.id}`;

    if (Platform.OS === 'web') {
      await Share.share({ message });
      return;
    }

    const uri = await certificateService.toPdf(certificate);
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Share your certificate',
        UTI: 'com.adobe.pdf',
      });
      return;
    }
    await Share.share({ message, url: uri });
  },

  /** Sends the certificate to the system print / save-as-PDF dialog. */
  async print(certificate: Certificate): Promise<void> {
    await Print.printAsync({ html: certificateHtml(certificate) });
  },
};
