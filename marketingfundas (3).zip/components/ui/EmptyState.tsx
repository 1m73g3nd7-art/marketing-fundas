import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Text, View } from 'react-native';

import { gradients } from '@/constants/theme';
import { Button } from './Button';
import { Icon, type IconName } from './Icon';

interface EmptyStateProps {
  icon?: IconName;
  title: string;
  message?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({
  icon = 'sparkles-outline',
  title,
  message,
  actionLabel,
  onAction,
  className = '',
}: EmptyStateProps) {
  return (
    <View className={`items-center px-8 py-12 ${className}`}>
      <LinearGradient
        colors={gradients.ai}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          width: 84,
          height: 84,
          borderRadius: 28,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Icon name={icon} size={34} color="#FFFFFF" />
      </LinearGradient>

      <Text className="mt-5 text-center text-lg font-extrabold text-ink-900 dark:text-white">
        {title}
      </Text>
      {message ? (
        <Text className="mt-2 text-center text-[14px] leading-5 text-ink-400">{message}</Text>
      ) : null}

      {actionLabel && onAction ? (
        <View className="mt-6 w-full max-w-[240px]">
          <Button title={actionLabel} onPress={onAction} />
        </View>
      ) : null}
    </View>
  );
}
