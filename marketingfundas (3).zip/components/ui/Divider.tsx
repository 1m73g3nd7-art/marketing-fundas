import React from 'react';
import { Text, View } from 'react-native';

export function Divider({ label, className = '' }: { label?: string; className?: string }) {
  if (!label) {
    return <View className={`h-px w-full bg-ink-100 dark:bg-ink-800 ${className}`} />;
  }
  return (
    <View className={`flex-row items-center gap-3 ${className}`}>
      <View className="h-px flex-1 bg-ink-200 dark:bg-ink-800" />
      <Text className="text-xs font-semibold uppercase tracking-wider text-ink-400">{label}</Text>
      <View className="h-px flex-1 bg-ink-200 dark:bg-ink-800" />
    </View>
  );
}
