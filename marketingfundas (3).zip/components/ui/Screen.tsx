import React, { type ReactNode } from 'react';
import { View, type ViewProps } from 'react-native';
import { SafeAreaView, type Edge } from 'react-native-safe-area-context';

interface ScreenProps extends ViewProps {
  children: ReactNode;
  /** Which safe-area edges to pad. Defaults to the top edge only. */
  edges?: Edge[];
  /** Removes the default page background (useful behind gradients). */
  transparent?: boolean;
}

/** Page wrapper that applies safe-area padding and the themed background. */
export function Screen({
  children,
  edges = ['top'],
  transparent = false,
  className = '',
  ...rest
}: ScreenProps) {
  return (
    <SafeAreaView
      edges={edges}
      className={`flex-1 ${transparent ? '' : 'bg-ink-50 dark:bg-ink-950'}`}
    >
      <View className={`flex-1 ${className}`} {...rest}>
        {children}
      </View>
    </SafeAreaView>
  );
}
