import React, { forwardRef, useState } from 'react';
import { Pressable, Text, TextInput, View, type TextInputProps } from 'react-native';

import { palette } from '@/constants/theme';
import { useSettings } from '@/context/SettingsContext';
import { Icon, type IconName } from './Icon';

interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  hint?: string;
  icon?: IconName;
  /** Renders a show/hide toggle and starts masked. */
  secure?: boolean;
  containerClassName?: string;
}

export const Input = forwardRef<TextInput, InputProps>(function Input(
  { label, error, hint, icon, secure, containerClassName = '', onFocus, onBlur, ...rest },
  ref,
) {
  const { isDark } = useSettings();
  const [focused, setFocused] = useState(false);
  const [hidden, setHidden] = useState(Boolean(secure));

  const borderClass = error
    ? 'border-red-400'
    : focused
      ? 'border-brand-500'
      : 'border-ink-200 dark:border-ink-800';

  return (
    <View className={`w-full ${containerClassName}`}>
      {label ? (
        <Text className="mb-2 text-[13px] font-semibold text-ink-700 dark:text-ink-200">
          {label}
        </Text>
      ) : null}

      <View
        className={`h-14 flex-row items-center rounded-2xl border bg-white px-4 dark:bg-ink-900 ${borderClass}`}
      >
        {icon ? (
          <Icon
            name={icon}
            size={19}
            className={focused ? 'text-brand-500' : 'text-ink-400'}
          />
        ) : null}

        <TextInput
          ref={ref}
          className={`h-full flex-1 text-[15px] text-ink-900 dark:text-white ${icon ? 'ml-3' : ''}`}
          placeholderTextColor={isDark ? palette.ink[500] : palette.ink[400]}
          secureTextEntry={hidden}
          onFocus={(event) => {
            setFocused(true);
            onFocus?.(event);
          }}
          onBlur={(event) => {
            setFocused(false);
            onBlur?.(event);
          }}
          {...rest}
        />

        {secure ? (
          <Pressable
            hitSlop={10}
            accessibilityRole="button"
            accessibilityLabel={hidden ? 'Show password' : 'Hide password'}
            onPress={() => setHidden((value) => !value)}
          >
            <Icon
              name={hidden ? 'eye-outline' : 'eye-off-outline'}
              size={19}
              className="text-ink-400"
            />
          </Pressable>
        ) : null}
      </View>

      {error ? (
        <View className="mt-1.5 flex-row items-center gap-1.5">
          <Icon name="alert-circle" size={13} className="text-red-500" />
          <Text className="text-xs font-medium text-red-500">{error}</Text>
        </View>
      ) : hint ? (
        <Text className="mt-1.5 text-xs text-ink-400">{hint}</Text>
      ) : null}
    </View>
  );
});
