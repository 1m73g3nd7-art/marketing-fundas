import React from 'react';
import { Text, View } from 'react-native';

import { Icon, type IconName } from './Icon';

export type BadgeTone = 'brand' | 'accent' | 'gold' | 'neutral' | 'success' | 'danger';

const tones: Record<BadgeTone, { bg: string; text: string }> = {
  brand: { bg: 'bg-brand-50 dark:bg-brand-950', text: 'text-brand-700 dark:text-brand-200' },
  accent: { bg: 'bg-accent-100 dark:bg-accent-900', text: 'text-accent-700 dark:text-accent-200' },
  gold: { bg: 'bg-amber-100 dark:bg-amber-950', text: 'text-amber-700 dark:text-amber-300' },
  neutral: { bg: 'bg-ink-100 dark:bg-ink-800', text: 'text-ink-600 dark:text-ink-200' },
  success: { bg: 'bg-emerald-100 dark:bg-emerald-950', text: 'text-emerald-700 dark:text-emerald-300' },
  danger: { bg: 'bg-red-100 dark:bg-red-950', text: 'text-red-600 dark:text-red-300' },
};

interface BadgeProps {
  label: string;
  tone?: BadgeTone;
  icon?: IconName;
  className?: string;
}

export function Badge({ label, tone = 'brand', icon, className = '' }: BadgeProps) {
  const style = tones[tone];
  return (
    <View className={`flex-row items-center gap-1 rounded-full px-2.5 py-1 ${style.bg} ${className}`}>
      {icon ? <Icon name={icon} size={11} className={style.text} /> : null}
      <Text className={`text-[11px] font-bold ${style.text}`}>{label}</Text>
    </View>
  );
}
