import React, { useEffect } from 'react';
import { Text, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';

import { BrandLogo } from './BrandLogo';

/** Full-page branded loader used while data or the session resolves. */
export function LoadingScreen({ message = 'Loading your learning…' }: { message?: string }) {
  const pulse = useSharedValue(0.9);

  useEffect(() => {
    pulse.value = withRepeat(
      withTiming(1.06, { duration: 900, easing: Easing.inOut(Easing.quad) }),
      -1,
      true,
    );
  }, [pulse]);

  const style = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));

  return (
    <View className="flex-1 items-center justify-center bg-ink-50 dark:bg-ink-950">
      <Animated.View style={style}>
        <BrandLogo size={56} showWordmark={false} />
      </Animated.View>
      <Text className="mt-6 text-[13px] font-medium text-ink-400">{message}</Text>
    </View>
  );
}

/** Shimmering placeholder block. */
export function Skeleton({
  className = '',
  height = 16,
  radius = 10,
}: {
  className?: string;
  height?: number;
  radius?: number;
}) {
  const opacity = useSharedValue(0.5);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(1, { duration: 800 }), -1, true);
  }, [opacity]);

  const style = useAnimatedStyle(() => ({ opacity: opacity.value }));

  return (
    <Animated.View
      style={[style, { height, borderRadius: radius }]}
      className={`bg-ink-100 dark:bg-ink-800 ${className}`}
    />
  );
}

/** Skeleton arrangement matching the course card layout. */
export function CourseCardSkeleton() {
  return (
    <View className="w-[260px] rounded-3xl bg-white p-3 dark:bg-ink-900">
      <Skeleton height={130} radius={18} />
      <Skeleton className="mt-3 w-3/4" height={14} />
      <Skeleton className="mt-2 w-1/2" height={12} />
      <Skeleton className="mt-3 w-full" height={8} />
    </View>
  );
}
