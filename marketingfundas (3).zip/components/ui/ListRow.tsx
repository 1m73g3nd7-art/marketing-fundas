import React, { type ReactNode } from 'react';
import { Pressable, Switch, Text, View } from 'react-native';

import { palette } from '@/constants/theme';
import { Icon, type IconName } from './Icon';

interface ListRowProps {
  icon?: IconName;
  iconTone?: string;
  title: string;
  subtitle?: string;
  onPress?: () => void;
  right?: ReactNode;
  danger?: boolean;
  showChevron?: boolean;
}

/** Settings / profile menu row. */
export function ListRow({
  icon,
  iconTone = 'bg-brand-50 dark:bg-brand-950',
  title,
  subtitle,
  onPress,
  right,
  danger = false,
  showChevron = true,
}: ListRowProps) {
  const body = (
    <View className="flex-row items-center gap-3 px-4 py-3.5">
      {icon ? (
        <View className={`h-10 w-10 items-center justify-center rounded-2xl ${danger ? 'bg-red-50 dark:bg-red-950' : iconTone}`}>
          <Icon
            name={icon}
            size={18}
            className={danger ? 'text-red-500' : 'text-brand-600 dark:text-brand-300'}
          />
        </View>
      ) : null}

      <View className="flex-1">
        <Text
          className={`text-[15px] font-semibold ${
            danger ? 'text-red-500' : 'text-ink-900 dark:text-white'
          }`}
        >
          {title}
        </Text>
        {subtitle ? <Text className="mt-0.5 text-[12px] text-ink-400">{subtitle}</Text> : null}
      </View>

      {right ??
        (onPress && showChevron ? (
          <Icon name="chevron-forward" size={17} className="text-ink-300" />
        ) : null)}
    </View>
  );

  if (!onPress) return body;

  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
    >
      {body}
    </Pressable>
  );
}

interface SwitchRowProps {
  icon?: IconName;
  title: string;
  subtitle?: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}

export function SwitchRow({ icon, title, subtitle, value, onValueChange }: SwitchRowProps) {
  return (
    <ListRow
      icon={icon}
      title={title}
      subtitle={subtitle}
      showChevron={false}
      right={
        <Switch
          value={value}
          onValueChange={onValueChange}
          trackColor={{ false: palette.ink[300], true: palette.brand[400] }}
          thumbColor={palette.white}
          ios_backgroundColor={palette.ink[300]}
        />
      }
    />
  );
}

/** Groups rows into a single rounded card with dividers. */
export function ListGroup({ children, title }: { children: ReactNode; title?: string }) {
  return (
    <View className="mb-5">
      {title ? (
        <Text className="mb-2 px-1 text-[12px] font-bold uppercase tracking-wider text-ink-400">
          {title}
        </Text>
      ) : null}
      <View className="overflow-hidden rounded-3xl border border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900">
        {React.Children.toArray(children).map((child, index) => (
          <View key={index}>
            {index > 0 ? <View className="ml-[68px] h-px bg-ink-100 dark:bg-ink-800" /> : null}
            {child}
          </View>
        ))}
      </View>
    </View>
  );
}
