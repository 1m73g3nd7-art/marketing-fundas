import { Ionicons } from '@expo/vector-icons';
import { cssInterop } from 'nativewind';
import type { ComponentProps } from 'react';

/**
 * Vector icons do not understand `className` on their own, so map the resolved
 * text colour and size across. Registered once, used app-wide.
 */
cssInterop(Ionicons, {
  className: {
    target: 'style',
    nativeStyleToProp: { color: true },
  },
});

export type IconName = ComponentProps<typeof Ionicons>['name'];
export const Icon = Ionicons;
