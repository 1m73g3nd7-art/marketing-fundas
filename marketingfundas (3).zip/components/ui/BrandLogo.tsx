import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Text, View } from 'react-native';

import { gradients } from '@/constants/theme';

interface BrandLogoProps {
  size?: number;
  showWordmark?: boolean;
  /** Use light text — for dark/gradient backgrounds. */
  inverted?: boolean;
  tagline?: string;
}

export function BrandLogo({
  size = 44,
  showWordmark = true,
  inverted = false,
  tagline,
}: BrandLogoProps) {
  return (
    <View className="flex-row items-center gap-3">
      <LinearGradient
        colors={gradients.ai}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          width: size,
          height: size,
          borderRadius: size * 0.32,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text
          style={{ fontSize: size * 0.4, lineHeight: size * 0.5 }}
          className="font-extrabold tracking-tight text-white"
        >
          MF
        </Text>
      </LinearGradient>

      {showWordmark ? (
        <View>
          <Text
            className={`text-lg font-extrabold tracking-tight ${
              inverted ? 'text-white' : 'text-ink-900 dark:text-white'
            }`}
          >
            Marketing Fundas
          </Text>
          <Text
            className={`text-[11px] font-semibold uppercase tracking-[2px] ${
              inverted ? 'text-white/70' : 'text-ink-400'
            }`}
          >
            {tagline ?? 'Digital Marketing + AI'}
          </Text>
        </View>
      ) : null}
    </View>
  );
}
