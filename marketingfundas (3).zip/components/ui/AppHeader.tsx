import { useRouter } from 'expo-router';
import React, { type ReactNode } from 'react';
import { Text, View } from 'react-native';

import { IconButton } from './IconButton';

interface AppHeaderProps {
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  right?: ReactNode;
  onBack?: () => void;
  className?: string;
}

/** Compact page header used on every stack screen. */
export function AppHeader({
  title,
  subtitle,
  showBack = true,
  right,
  onBack,
  className = '',
}: AppHeaderProps) {
  const router = useRouter();

  const handleBack = () => {
    if (onBack) return onBack();
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)');
  };

  return (
    <View className={`flex-row items-center gap-3 px-5 pb-3 pt-2 ${className}`}>
      {showBack ? (
        <IconButton name="chevron-back" accessibilityLabel="Go back" onPress={handleBack} />
      ) : null}

      <View className="flex-1">
        {title ? (
          <Text
            numberOfLines={1}
            className="text-[18px] font-extrabold tracking-tight text-ink-900 dark:text-white"
          >
            {title}
          </Text>
        ) : null}
        {subtitle ? (
          <Text numberOfLines={1} className="text-[12px] text-ink-400">
            {subtitle}
          </Text>
        ) : null}
      </View>

      {right}
    </View>
  );
}
