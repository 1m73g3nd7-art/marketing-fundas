import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Text, View } from 'react-native';

import { gradients } from '@/constants/theme';
import { initials } from '@/utils/format';

interface AvatarProps {
  uri?: string | null;
  name?: string;
  size?: number;
  ring?: boolean;
}

export function Avatar({ uri, name, size = 44, ring = false }: AvatarProps) {
  const radius = size / 2;
  const inner = (
    <View
      style={{ width: size, height: size, borderRadius: radius }}
      className="overflow-hidden bg-ink-100 dark:bg-ink-800"
    >
      {uri ? (
        <Image
          source={{ uri }}
          style={{ width: size, height: size }}
          contentFit="cover"
          transition={200}
        />
      ) : (
        <LinearGradient
          colors={gradients.ai}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
        >
          <Text style={{ fontSize: size * 0.36 }} className="font-bold text-white">
            {initials(name)}
          </Text>
        </LinearGradient>
      )}
    </View>
  );

  if (!ring) return inner;

  return (
    <LinearGradient
      colors={gradients.ai}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{
        padding: 2,
        borderRadius: radius + 2,
      }}
    >
      <View className="rounded-full bg-white p-[2px] dark:bg-ink-950">{inner}</View>
    </LinearGradient>
  );
}
