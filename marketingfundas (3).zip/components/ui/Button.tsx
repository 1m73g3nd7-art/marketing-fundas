import { LinearGradient } from 'expo-linear-gradient';
import React, { type ReactNode } from 'react';
import { ActivityIndicator, Pressable, Text, View, type PressableProps } from 'react-native';
import { gradients } from '@/constants/theme';
import { Icon, type IconName } from './Icon';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'light';
export type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends Omit<PressableProps, 'children' | 'style'> {
  title: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: IconName;
  iconRight?: IconName;
  fullWidth?: boolean;
  className?: string;
}

const sizeStyles: Record<ButtonSize, { container: string; text: string; icon: number }> = {
  sm: { container: 'h-10 px-4 rounded-xl', text: 'text-sm', icon: 16 },
  md: { container: 'h-12 px-5 rounded-2xl', text: 'text-[15px]', icon: 18 },
  lg: { container: 'h-14 px-6 rounded-2xl', text: 'text-base', icon: 20 },
};

const surfaceFor = (variant: ButtonVariant, disabled: boolean) => {
  if (disabled) return 'bg-ink-200 dark:bg-ink-800';
  switch (variant) {
    case 'secondary':
      return 'bg-brand-50 dark:bg-brand-950';
    case 'outline':
      return 'bg-transparent border border-ink-200 dark:border-ink-700';
    case 'ghost':
      return 'bg-transparent';
    case 'danger':
      return 'bg-red-500';
    case 'light':
      return 'bg-white';
    default:
      return '';
  }
};

const labelFor = (variant: ButtonVariant, disabled: boolean) => {
  if (disabled) return 'text-ink-400';
  switch (variant) {
    case 'secondary':
      return 'text-brand-700 dark:text-brand-200';
    case 'outline':
      return 'text-ink-800 dark:text-ink-100';
    case 'ghost':
      return 'text-brand-600 dark:text-brand-300';
    case 'danger':
      return 'text-white';
    case 'light':
      return 'text-brand-700';
    default:
      return 'text-white';
  }
};

/** Primary action button. The `primary` variant renders a brand gradient. */
export function Button({
  title,
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  iconRight,
  fullWidth = true,
  disabled,
  className = '',
  ...rest
}: ButtonProps) {
  const isDisabled = Boolean(disabled) || loading;
  const dimensions = sizeStyles[size];
  const labelClass = labelFor(variant, isDisabled);

  const content: ReactNode = (
    <View className="flex-row items-center justify-center gap-2">
      {loading ? (
        <ActivityIndicator
          size="small"
          color={variant === 'primary' || variant === 'danger' ? '#FFFFFF' : '#6355F0'}
        />
      ) : icon ? (
        <Icon name={icon} size={dimensions.icon} className={labelClass} />
      ) : null}
      <Text className={`font-bold ${dimensions.text} ${labelClass}`} numberOfLines={1}>
        {title}
      </Text>
      {iconRight && !loading ? (
        <Icon name={iconRight} size={dimensions.icon} className={labelClass} />
      ) : null}
    </View>
  );

  const useGradient = variant === 'primary' && !isDisabled;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      disabled={isDisabled}
      className={`overflow-hidden ${fullWidth ? 'w-full' : 'self-start'} ${dimensions.container} ${
        useGradient ? '' : surfaceFor(variant, isDisabled)
      } ${className}`}
      style={({ pressed }) => ({ opacity: pressed && !isDisabled ? 0.85 : 1 })}
      {...rest}
    >
      {useGradient ? (
        <LinearGradient
          colors={gradients.brand}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
          }}
        />
      ) : null}
      <View className="flex-1 items-center justify-center">{content}</View>
    </Pressable>
  );
}
