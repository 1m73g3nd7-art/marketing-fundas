import React, { type ReactNode } from 'react';
import { Pressable, View, type ViewProps } from 'react-native';

interface CardProps extends ViewProps {
  children: ReactNode;
  onPress?: () => void;
  /** Adds the elevated card shadow. */
  elevated?: boolean;
  padded?: boolean;
}

export function Card({
  children,
  onPress,
  elevated = true,
  padded = true,
  className = '',
  ...rest
}: CardProps) {
  const base = `rounded-3xl bg-white dark:bg-ink-900 ${
    elevated ? 'border border-ink-100 dark:border-ink-800' : ''
  } ${padded ? 'p-4' : ''} ${className}`;

  if (onPress) {
    return (
      <Pressable
        accessibilityRole="button"
        onPress={onPress}
        className={base}
        style={({ pressed }) => ({ opacity: pressed ? 0.9 : 1 })}
      >
        {children}
      </Pressable>
    );
  }

  return (
    <View className={base} {...rest}>
      {children}
    </View>
  );
}
