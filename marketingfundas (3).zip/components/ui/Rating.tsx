import React from 'react';
import { Text, View } from 'react-native';

import { formatCount } from '@/utils/format';
import { Icon } from './Icon';

interface RatingProps {
  value: number;
  count?: number;
  size?: number;
  showStars?: boolean;
  className?: string;
}

export function Rating({ value, count, size = 13, showStars = false, className = '' }: RatingProps) {
  return (
    <View className={`flex-row items-center gap-1 ${className}`}>
      {showStars ? (
        [0, 1, 2, 3, 4].map((index) => (
          <Icon
            key={index}
            name={value >= index + 1 ? 'star' : value >= index + 0.5 ? 'star-half' : 'star-outline'}
            size={size}
            className="text-amber-400"
          />
        ))
      ) : (
        <Icon name="star" size={size} className="text-amber-400" />
      )}
      <Text className="text-xs font-bold text-ink-700 dark:text-ink-200">{value.toFixed(1)}</Text>
      {count !== undefined ? (
        <Text className="text-xs text-ink-400">({formatCount(count)})</Text>
      ) : null}
    </View>
  );
}
