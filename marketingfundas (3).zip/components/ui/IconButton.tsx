import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Icon, type IconName } from './Icon';

interface IconButtonProps {
  name: IconName;
  onPress?: () => void;
  size?: number;
  /** Small numeric badge, e.g. unread notifications. */
  badge?: number;
  accessibilityLabel: string;
  variant?: 'surface' | 'ghost' | 'glass';
  className?: string;
  iconClassName?: string;
}

export function IconButton({
  name,
  onPress,
  size = 20,
  badge,
  accessibilityLabel,
  variant = 'surface',
  className = '',
  iconClassName,
}: IconButtonProps) {
  const surface =
    variant === 'surface'
      ? 'bg-white dark:bg-ink-900 border border-ink-100 dark:border-ink-800'
      : variant === 'glass'
        ? 'bg-white/15'
        : '';

  const iconTone =
    iconClassName ?? (variant === 'glass' ? 'text-white' : 'text-ink-700 dark:text-ink-100');

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      onPress={onPress}
      hitSlop={6}
      className={`h-11 w-11 items-center justify-center rounded-2xl ${surface} ${className}`}
      style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
    >
      <Icon name={name} size={size} className={iconTone} />
      {badge && badge > 0 ? (
        <View className="absolute -right-0.5 -top-0.5 h-5 min-w-5 items-center justify-center rounded-full border-2 border-white bg-red-500 px-1 dark:border-ink-950">
          <Text className="text-[9px] font-extrabold text-white">
            {badge > 9 ? '9+' : badge}
          </Text>
        </View>
      ) : null}
    </Pressable>
  );
}
