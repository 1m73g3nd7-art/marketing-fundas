import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';

export interface SegmentOption<T extends string = string> {
  value: T;
  label: string;
  count?: number;
}

interface SegmentedTabsProps<T extends string> {
  options: SegmentOption<T>[];
  value: T;
  onChange: (value: T) => void;
  scrollable?: boolean;
  className?: string;
}

export function SegmentedTabs<T extends string>({
  options,
  value,
  onChange,
  scrollable = false,
  className = '',
}: SegmentedTabsProps<T>) {
  const items = options.map((option) => {
    const active = option.value === value;
    return (
      <Pressable
        key={option.value}
        accessibilityRole="tab"
        accessibilityState={{ selected: active }}
        onPress={() => onChange(option.value)}
        className={`${scrollable ? 'px-4' : 'flex-1'} h-10 flex-row items-center justify-center gap-1.5 rounded-xl ${
          active ? 'bg-white shadow-sm dark:bg-ink-800' : ''
        }`}
      >
        <Text
          className={`text-[13px] font-bold ${
            active ? 'text-brand-700 dark:text-white' : 'text-ink-400'
          }`}
        >
          {option.label}
        </Text>
        {option.count !== undefined ? (
          <View
            className={`rounded-full px-1.5 py-0.5 ${
              active ? 'bg-brand-100 dark:bg-brand-900' : 'bg-ink-200 dark:bg-ink-800'
            }`}
          >
            <Text
              className={`text-[10px] font-bold ${
                active ? 'text-brand-700 dark:text-brand-100' : 'text-ink-500'
              }`}
            >
              {option.count}
            </Text>
          </View>
        ) : null}
      </Pressable>
    );
  });

  const container = `rounded-2xl bg-ink-100 p-1 dark:bg-ink-900 ${className}`;

  if (scrollable) {
    return (
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerClassName="flex-row"
        className={container}
      >
        {items}
      </ScrollView>
    );
  }

  return <View className={`flex-row ${container}`}>{items}</View>;
}
