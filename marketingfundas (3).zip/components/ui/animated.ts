import { cssInterop } from 'nativewind';
import Animated from 'react-native-reanimated';

/**
 * Reanimated wraps its components in `createAnimatedComponent`, which hides
 * them from NativeWind's automatic interop. Registering them here lets
 * `className` work on `Animated.View` / `Animated.Text` app-wide.
 * Import this module once (the root layout does) before rendering.
 */
cssInterop(Animated.View, { className: 'style' });
cssInterop(Animated.Text, { className: 'style' });
cssInterop(Animated.Image, { className: 'style' });
cssInterop(Animated.ScrollView, {
  className: 'style',
  contentContainerClassName: 'contentContainerStyle',
});

export { Animated };
