import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Icon } from './Icon';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function SectionHeader({
  title,
  subtitle,
  actionLabel,
  onAction,
  className = '',
}: SectionHeaderProps) {
  return (
    <View className={`flex-row items-end justify-between ${className}`}>
      <View className="flex-1 pr-3">
        <Text className="text-[17px] font-extrabold tracking-tight text-ink-900 dark:text-white">
          {title}
        </Text>
        {subtitle ? (
          <Text className="mt-0.5 text-[13px] text-ink-400">{subtitle}</Text>
        ) : null}
      </View>

      {actionLabel && onAction ? (
        <Pressable
          accessibilityRole="button"
          onPress={onAction}
          hitSlop={8}
          className="flex-row items-center gap-0.5"
        >
          <Text className="text-[13px] font-bold text-brand-600 dark:text-brand-300">
            {actionLabel}
          </Text>
          <Icon name="chevron-forward" size={14} className="text-brand-600 dark:text-brand-300" />
        </Pressable>
      ) : null}
    </View>
  );
}
