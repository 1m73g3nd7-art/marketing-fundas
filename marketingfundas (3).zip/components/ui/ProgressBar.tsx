import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { View } from 'react-native';

import { gradients } from '@/constants/theme';

interface ProgressBarProps {
  /** 0–100 */
  value: number;
  height?: number;
  className?: string;
  tone?: 'brand' | 'accent' | 'gold';
}

const toneColors = {
  brand: gradients.brand,
  accent: gradients.ai,
  gold: gradients.gold,
} as const;

export function ProgressBar({ value, height = 8, className = '', tone = 'brand' }: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <View
      accessibilityRole="progressbar"
      accessibilityValue={{ now: clamped, min: 0, max: 100 }}
      className={`w-full overflow-hidden rounded-full bg-ink-100 dark:bg-ink-800 ${className}`}
      style={{ height }}
    >
      <LinearGradient
        colors={toneColors[tone]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={{ width: `${clamped}%`, height: '100%', borderRadius: height }}
      />
    </View>
  );
}
