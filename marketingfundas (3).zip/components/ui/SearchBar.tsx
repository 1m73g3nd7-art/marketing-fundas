import React from 'react';
import { Pressable, TextInput, View } from 'react-native';

import { palette } from '@/constants/theme';
import { useSettings } from '@/context/SettingsContext';
import { Icon } from './Icon';

interface SearchBarProps {
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
  onFilterPress?: () => void;
  filterActive?: boolean;
  className?: string;
  autoFocus?: boolean;
}

export function SearchBar({
  value,
  onChangeText,
  placeholder = 'Search courses, topics, instructors',
  onFilterPress,
  filterActive = false,
  className = '',
  autoFocus,
}: SearchBarProps) {
  const { isDark } = useSettings();

  return (
    <View className={`flex-row items-center gap-2 ${className}`}>
      <View className="h-12 flex-1 flex-row items-center rounded-2xl border border-ink-100 bg-white px-4 dark:border-ink-800 dark:bg-ink-900">
        <Icon name="search-outline" size={18} className="text-ink-400" />
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={isDark ? palette.ink[500] : palette.ink[400]}
          autoFocus={autoFocus}
          returnKeyType="search"
          className="ml-2.5 h-full flex-1 text-[14px] text-ink-900 dark:text-white"
        />
        {value.length > 0 ? (
          <Pressable
            hitSlop={10}
            accessibilityRole="button"
            accessibilityLabel="Clear search"
            onPress={() => onChangeText('')}
          >
            <Icon name="close-circle" size={17} className="text-ink-300" />
          </Pressable>
        ) : null}
      </View>

      {onFilterPress ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Filters"
          onPress={onFilterPress}
          className={`h-12 w-12 items-center justify-center rounded-2xl ${
            filterActive
              ? 'bg-brand-600'
              : 'border border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900'
          }`}
        >
          <Icon
            name="options-outline"
            size={20}
            className={filterActive ? 'text-white' : 'text-ink-700 dark:text-ink-100'}
          />
        </Pressable>
      ) : null}
    </View>
  );
}
