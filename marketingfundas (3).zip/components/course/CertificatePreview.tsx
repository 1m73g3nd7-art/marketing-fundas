import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Text, View } from 'react-native';

import { Icon } from '@/components/ui/Icon';
import { gradients } from '@/constants/theme';
import type { Certificate } from '@/types';
import { formatDate } from '@/utils/format';

/** On-screen replica of the printable certificate. */
export function CertificatePreview({ certificate }: { certificate: Certificate }) {
  return (
    <LinearGradient
      colors={gradients.hero}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ borderRadius: 28, padding: 8 }}
    >
      <View className="rounded-[22px] bg-white p-5">
        <View className="flex-row items-center gap-2.5">
          <LinearGradient
            colors={gradients.ai}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{ width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' }}
          >
            <Text className="text-[13px] font-extrabold text-white">MF</Text>
          </LinearGradient>
          <View className="flex-1">
            <Text className="text-[13px] font-extrabold tracking-tight text-ink-900">
              Marketing Fundas
            </Text>
            <Text className="text-[8.5px] font-bold uppercase tracking-[1.6px] text-ink-400">
              Digital Marketing + AI
            </Text>
          </View>
          <View className="h-11 w-11 items-center justify-center rounded-full border-2 border-amber-400/60">
            <Icon name="ribbon" size={17} color="#D97706" />
          </View>
        </View>

        <Text className="mt-5 text-[9.5px] font-extrabold uppercase tracking-[3px] text-brand-600">
          Certificate of Completion
        </Text>

        <Text className="mt-3 text-[10.5px] text-ink-400">Awarded to</Text>
        <Text className="mt-0.5 text-[24px] font-extrabold leading-8 tracking-tight text-ink-900">
          {certificate.studentName}
        </Text>
        <View className="mt-1.5 h-px w-4/5 bg-ink-200" />

        <Text className="mt-3.5 text-[12px] leading-[18px] text-ink-600">
          has successfully completed all lessons and passed the final assessment for{' '}
          <Text className="font-extrabold text-ink-900">{certificate.courseTitle}</Text> with a score
          of <Text className="font-extrabold text-ink-900">{certificate.score}%</Text>.
        </Text>

        <View className="mt-6 flex-row items-end justify-between">
          <View>
            <Text className="text-[8px] font-bold uppercase tracking-[1.4px] text-ink-400">
              Certificate ID
            </Text>
            <Text className="mt-0.5 text-[11px] font-extrabold text-ink-900">{certificate.id}</Text>
          </View>
          <View>
            <Text className="text-[8px] font-bold uppercase tracking-[1.4px] text-ink-400">
              Completed
            </Text>
            <Text className="mt-0.5 text-[11px] font-extrabold text-ink-900">
              {formatDate(certificate.issuedAt)}
            </Text>
          </View>
          <View className="items-end">
            <View className="mb-1 h-px w-20 bg-ink-300" />
            <Text className="text-[10.5px] font-extrabold text-ink-900">
              {certificate.instructorName}
            </Text>
            <Text className="text-[8px] font-bold uppercase tracking-[1.4px] text-ink-400">
              Instructor
            </Text>
          </View>
        </View>
      </View>
    </LinearGradient>
  );
}
