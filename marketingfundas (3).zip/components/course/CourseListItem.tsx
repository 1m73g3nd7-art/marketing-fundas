import { Image } from 'expo-image';
import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Badge } from '@/components/ui/Badge';
import { Icon } from '@/components/ui/Icon';
import { Rating } from '@/components/ui/Rating';
import { categoryById } from '@/constants/categories';
import type { Course } from '@/types';
import { formatDuration, formatPrice } from '@/utils/format';
import { lessonTotal } from '@/utils/progress';

interface CourseListItemProps {
  course: Course;
  onPress: () => void;
  onEnroll?: () => void;
  enrolled?: boolean;
  saved?: boolean;
  onToggleSave?: () => void;
}

/** Full-width catalogue row with an enrol action. */
export function CourseListItem({
  course,
  onPress,
  onEnroll,
  enrolled = false,
  saved = false,
  onToggleSave,
}: CourseListItemProps) {
  const category = categoryById(course.category);

  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      className="mb-3 flex-row gap-3 rounded-3xl border border-ink-100 bg-white p-3 dark:border-ink-800 dark:bg-ink-900"
      style={({ pressed }) => ({ opacity: pressed ? 0.92 : 1 })}
    >
      <View className="h-[104px] w-[104px] overflow-hidden rounded-2xl bg-ink-100 dark:bg-ink-800">
        <Image
          source={{ uri: course.image }}
          style={{ width: '100%', height: '100%' }}
          contentFit="cover"
          transition={250}
        />
      </View>

      <View className="flex-1">
        <View className="flex-row items-start justify-between gap-2">
          <Badge label={category.short} tone="brand" />
          {onToggleSave ? (
            <Pressable
              hitSlop={8}
              accessibilityRole="button"
              accessibilityLabel={saved ? 'Remove from saved' : 'Save course'}
              onPress={onToggleSave}
            >
              <Icon
                name={saved ? 'bookmark' : 'bookmark-outline'}
                size={17}
                className={saved ? 'text-brand-500' : 'text-ink-300'}
              />
            </Pressable>
          ) : null}
        </View>

        <Text
          numberOfLines={2}
          className="mt-1.5 text-[14.5px] font-extrabold leading-5 tracking-tight text-ink-900 dark:text-white"
        >
          {course.title}
        </Text>
        <Text numberOfLines={1} className="mt-0.5 text-[12px] text-ink-400">
          {course.instructor.name}
        </Text>

        <View className="mt-1.5 flex-row items-center gap-3">
          <Rating value={course.rating} count={course.ratingCount} />
          <View className="flex-row items-center gap-1">
            <Icon name="play-circle-outline" size={12} className="text-ink-400" />
            <Text className="text-[11px] text-ink-400">{lessonTotal(course)}</Text>
          </View>
          <View className="flex-row items-center gap-1">
            <Icon name="time-outline" size={12} className="text-ink-400" />
            <Text className="text-[11px] text-ink-400">
              {formatDuration(course.durationMinutes)}
            </Text>
          </View>
        </View>

        <View className="mt-2 flex-row items-center justify-between">
          <View className="flex-row items-baseline gap-1.5">
            <Text className="text-[15px] font-extrabold text-brand-600 dark:text-brand-300">
              {formatPrice(course.price)}
            </Text>
            {course.originalPrice ? (
              <Text className="text-[11px] text-ink-300 line-through">
                {formatPrice(course.originalPrice)}
              </Text>
            ) : null}
          </View>

          {onEnroll ? (
            <Pressable
              accessibilityRole="button"
              onPress={onEnroll}
              className={`h-8 flex-row items-center gap-1 rounded-xl px-3 ${
                enrolled ? 'bg-emerald-50 dark:bg-emerald-950' : 'bg-brand-600'
              }`}
            >
              <Icon
                name={enrolled ? 'checkmark-circle' : 'add'}
                size={14}
                className={enrolled ? 'text-emerald-600 dark:text-emerald-400' : 'text-white'}
              />
              <Text
                className={`text-[12px] font-bold ${
                  enrolled ? 'text-emerald-700 dark:text-emerald-300' : 'text-white'
                }`}
              >
                {enrolled ? 'Enrolled' : 'Enroll'}
              </Text>
            </Pressable>
          ) : null}
        </View>
      </View>
    </Pressable>
  );
}
