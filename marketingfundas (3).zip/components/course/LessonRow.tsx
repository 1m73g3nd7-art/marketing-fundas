import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Icon } from '@/components/ui/Icon';
import type { Lesson } from '@/types';
import { formatDuration } from '@/utils/format';

interface LessonRowProps {
  lesson: Lesson;
  index: number;
  completed?: boolean;
  active?: boolean;
  locked?: boolean;
  onPress?: () => void;
}

export function LessonRow({
  lesson,
  index,
  completed = false,
  active = false,
  locked = false,
  onPress,
}: LessonRowProps) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: active, disabled: locked }}
      onPress={locked ? undefined : onPress}
      className={`flex-row items-center gap-3 rounded-2xl px-3 py-3 ${
        active ? 'bg-brand-50 dark:bg-brand-950' : ''
      }`}
      style={({ pressed }) => ({ opacity: locked ? 0.55 : pressed ? 0.75 : 1 })}
    >
      <View
        className={`h-9 w-9 items-center justify-center rounded-full ${
          completed
            ? 'bg-emerald-100 dark:bg-emerald-950'
            : active
              ? 'bg-brand-600'
              : 'bg-ink-100 dark:bg-ink-800'
        }`}
      >
        {completed ? (
          <Icon name="checkmark" size={16} className="text-emerald-600 dark:text-emerald-400" />
        ) : locked ? (
          <Icon name="lock-closed" size={14} className="text-ink-400" />
        ) : active ? (
          <Icon name="play" size={14} className="text-white" />
        ) : (
          <Text className="text-[12px] font-bold text-ink-500 dark:text-ink-300">{index + 1}</Text>
        )}
      </View>

      <View className="flex-1">
        <Text
          numberOfLines={2}
          className={`text-[13.5px] font-semibold leading-[19px] ${
            active ? 'text-brand-700 dark:text-brand-200' : 'text-ink-900 dark:text-white'
          }`}
        >
          {lesson.title}
        </Text>
        <View className="mt-0.5 flex-row items-center gap-2">
          <Text className="text-[11.5px] text-ink-400">
            {formatDuration(lesson.durationMinutes)}
          </Text>
          {lesson.isPreview ? (
            <Text className="text-[11px] font-bold text-accent-600 dark:text-accent-300">
              Free preview
            </Text>
          ) : null}
        </View>
      </View>

      {lesson.resources?.length ? (
        <Icon name="document-attach-outline" size={15} className="text-ink-300" />
      ) : null}
    </Pressable>
  );
}
