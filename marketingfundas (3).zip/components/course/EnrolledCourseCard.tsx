import { Image } from 'expo-image';
import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Badge } from '@/components/ui/Badge';
import { Icon } from '@/components/ui/Icon';
import { ProgressBar } from '@/components/ui/ProgressBar';
import type { EnrolledCourse } from '@/context/LearningContext';

interface EnrolledCourseCardProps {
  item: EnrolledCourse;
  onPress: () => void;
  onContinue: () => void;
}

/** My Learning row: progress, lesson counter and a continue action. */
export function EnrolledCourseCard({ item, onPress, onContinue }: EnrolledCourseCardProps) {
  const { course, percent, completedLessons, totalLessons, completed } = item;

  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      className="mb-3 overflow-hidden rounded-3xl border border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900"
      style={({ pressed }) => ({ opacity: pressed ? 0.92 : 1 })}
    >
      <View className="flex-row gap-3 p-3">
        <View className="h-[92px] w-[92px] overflow-hidden rounded-2xl bg-ink-100 dark:bg-ink-800">
          <Image
            source={{ uri: course.image }}
            style={{ width: '100%', height: '100%' }}
            contentFit="cover"
            transition={250}
          />
        </View>

        <View className="flex-1">
          <View className="flex-row items-start justify-between gap-2">
            <Text
              numberOfLines={2}
              className="flex-1 text-[14.5px] font-extrabold leading-5 tracking-tight text-ink-900 dark:text-white"
            >
              {course.title}
            </Text>
            {completed ? <Badge label="Completed" tone="success" icon="checkmark-circle" /> : null}
          </View>

          <Text numberOfLines={1} className="mt-0.5 text-[12px] text-ink-400">
            {course.instructor.name}
          </Text>

          <View className="mt-2.5">
            <View className="mb-1.5 flex-row items-center justify-between">
              <Text className="text-[11px] font-bold text-ink-500 dark:text-ink-300">
                {completedLessons} of {totalLessons} lessons
              </Text>
              <Text className="text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
                {percent}%
              </Text>
            </View>
            <ProgressBar value={percent} height={6} tone={completed ? 'accent' : 'brand'} />
          </View>
        </View>
      </View>

      <Pressable
        accessibilityRole="button"
        onPress={onContinue}
        className="flex-row items-center justify-center gap-1.5 border-t border-ink-100 py-3 dark:border-ink-800"
      >
        <Icon
          name={completed ? 'refresh' : 'play-circle'}
          size={16}
          className="text-brand-600 dark:text-brand-300"
        />
        <Text className="text-[13px] font-bold text-brand-600 dark:text-brand-300">
          {completed ? 'Review course' : percent > 0 ? 'Continue learning' : 'Start learning'}
        </Text>
      </Pressable>
    </Pressable>
  );
}
