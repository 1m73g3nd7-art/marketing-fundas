import React from 'react';
import { Text, View } from 'react-native';

import { Avatar } from '@/components/ui/Avatar';
import { Rating } from '@/components/ui/Rating';
import type { Review } from '@/types';
import { formatDate } from '@/utils/format';

export function ReviewCard({ review }: { review: Review }) {
  return (
    <View className="mb-3 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
      <View className="flex-row items-center gap-3">
        <Avatar uri={review.avatar} name={review.userName} size={40} />
        <View className="flex-1">
          <Text className="text-[14px] font-bold text-ink-900 dark:text-white">
            {review.userName}
          </Text>
          <Text className="text-[11.5px] text-ink-400">{formatDate(review.date)}</Text>
        </View>
        <Rating value={review.rating} showStars size={12} />
      </View>
      <Text className="mt-3 text-[13.5px] leading-[20px] text-ink-600 dark:text-ink-300">
        {review.comment}
      </Text>
    </View>
  );
}
