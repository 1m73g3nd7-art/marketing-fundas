import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Badge } from '@/components/ui/Badge';
import { Icon } from '@/components/ui/Icon';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { Rating } from '@/components/ui/Rating';
import { categoryById } from '@/constants/categories';
import type { Course } from '@/types';
import { formatDuration, formatPrice } from '@/utils/format';
import { lessonTotal } from '@/utils/progress';

interface CourseCardProps {
  course: Course;
  onPress: () => void;
  /** Shows a progress bar instead of the price row. */
  progress?: number;
  width?: number;
  className?: string;
}

/** Horizontal-rail course card. */
export function CourseCard({ course, onPress, progress, width = 268, className = '' }: CourseCardProps) {
  const category = categoryById(course.category);

  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={{ width }}
      className={`overflow-hidden rounded-3xl border border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900 ${className}`}
    >
      <View className="h-[142px] w-full bg-ink-100 dark:bg-ink-800">
        <Image
          source={{ uri: course.image }}
          style={{ width: '100%', height: '100%' }}
          contentFit="cover"
          transition={250}
        />
        <LinearGradient
          colors={['transparent', 'rgba(10,12,19,0.72)']}
          style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 68 }}
        />

        <View className="absolute left-3 top-3 flex-row gap-1.5">
          {course.bestseller ? <Badge label="Bestseller" tone="gold" /> : null}
          {course.isNew ? <Badge label="New" tone="accent" /> : null}
        </View>

        <View className="absolute bottom-3 left-3 right-3 flex-row items-center justify-between">
          <View className="flex-row items-center gap-1 rounded-full bg-white/20 px-2 py-1">
            <Icon name={category.icon} size={11} color="#FFFFFF" />
            <Text className="text-[10px] font-bold text-white">{category.short}</Text>
          </View>
          <View className="flex-row items-center gap-1 rounded-full bg-white/20 px-2 py-1">
            <Icon name="time-outline" size={11} color="#FFFFFF" />
            <Text className="text-[10px] font-bold text-white">
              {formatDuration(course.durationMinutes)}
            </Text>
          </View>
        </View>
      </View>

      <View className="p-3.5">
        <Text
          numberOfLines={2}
          className="text-[15px] font-extrabold leading-5 tracking-tight text-ink-900 dark:text-white"
        >
          {course.title}
        </Text>
        <Text numberOfLines={1} className="mt-1 text-[12px] text-ink-400">
          {course.instructor.name} · {lessonTotal(course)} lessons
        </Text>

        {progress === undefined ? (
          <View className="mt-3 flex-row items-center justify-between">
            <Rating value={course.rating} count={course.ratingCount} />
            <View className="flex-row items-baseline gap-1.5">
              <Text className="text-[15px] font-extrabold text-brand-600 dark:text-brand-300">
                {formatPrice(course.price)}
              </Text>
              {course.originalPrice ? (
                <Text className="text-[11px] text-ink-300 line-through">
                  {formatPrice(course.originalPrice)}
                </Text>
              ) : null}
            </View>
          </View>
        ) : (
          <View className="mt-3">
            <View className="mb-1.5 flex-row items-center justify-between">
              <Text className="text-[11px] font-bold text-ink-500 dark:text-ink-300">
                {progress}% complete
              </Text>
              <Rating value={course.rating} />
            </View>
            <ProgressBar value={progress} height={6} />
          </View>
        )}
      </View>
    </Pressable>
  );
}
