import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';

import { Icon } from '@/components/ui/Icon';
import { CATEGORIES } from '@/constants/categories';
import type { CategoryId } from '@/types';

interface CategoryChipsProps {
  value: CategoryId | 'all';
  onChange: (value: CategoryId | 'all') => void;
  className?: string;
}

export function CategoryChips({ value, onChange, className = '' }: CategoryChipsProps) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerClassName="gap-2 px-5"
      className={className}
    >
      <Chip label="All" active={value === 'all'} onPress={() => onChange('all')} />
      {CATEGORIES.map((category) => (
        <Chip
          key={category.id}
          label={category.short}
          icon={category.icon}
          active={value === category.id}
          onPress={() => onChange(category.id)}
        />
      ))}
    </ScrollView>
  );
}

function Chip({
  label,
  icon,
  active,
  onPress,
}: {
  label: string;
  icon?: (typeof CATEGORIES)[number]['icon'];
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      onPress={onPress}
      className={`h-9 flex-row items-center gap-1.5 rounded-full px-4 ${
        active
          ? 'bg-brand-600'
          : 'border border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900'
      }`}
    >
      {icon ? (
        <Icon
          name={icon}
          size={13}
          className={active ? 'text-white' : 'text-ink-500 dark:text-ink-300'}
        />
      ) : null}
      <Text
        className={`text-[13px] font-bold ${
          active ? 'text-white' : 'text-ink-600 dark:text-ink-200'
        }`}
      >
        {label}
      </Text>
    </Pressable>
  );
}

/** Grid of category tiles used on the courses landing state. */
export function CategoryGrid({ onSelect }: { onSelect: (id: CategoryId) => void }) {
  return (
    <View className="flex-row flex-wrap gap-3">
      {CATEGORIES.map((category) => (
        <Pressable
          key={category.id}
          accessibilityRole="button"
          onPress={() => onSelect(category.id)}
          className="w-[47%] flex-1 basis-[47%] rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900"
        >
          <View
            className="h-10 w-10 items-center justify-center rounded-2xl"
            style={{ backgroundColor: `${category.color}1A` }}
          >
            <Icon name={category.icon} size={19} color={category.color} />
          </View>
          <Text className="mt-3 text-[13.5px] font-bold text-ink-900 dark:text-white">
            {category.label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
