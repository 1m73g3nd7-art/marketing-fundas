import React from 'react';
import { Text, View } from 'react-native';

import { Avatar } from '@/components/ui/Avatar';
import { Icon } from '@/components/ui/Icon';
import type { Instructor } from '@/types';
import { formatCount } from '@/utils/format';

export function InstructorCard({ instructor }: { instructor: Instructor }) {
  return (
    <View className="rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
      <View className="flex-row items-center gap-3">
        <Avatar uri={instructor.avatar} name={instructor.name} size={56} ring />
        <View className="flex-1">
          <Text className="text-[15px] font-extrabold text-ink-900 dark:text-white">
            {instructor.name}
          </Text>
          <Text numberOfLines={2} className="mt-0.5 text-[12px] leading-4 text-ink-400">
            {instructor.title}
          </Text>
        </View>
      </View>

      <View className="mt-4 flex-row gap-4">
        <Metric icon="star" value={instructor.rating.toFixed(1)} label="Rating" />
        <Metric icon="people-outline" value={formatCount(instructor.students)} label="Students" />
        <Metric icon="albums-outline" value={`${instructor.courses}`} label="Courses" />
      </View>

      <Text className="mt-4 text-[13px] leading-[20px] text-ink-600 dark:text-ink-300">
        {instructor.bio}
      </Text>
    </View>
  );
}

function Metric({
  icon,
  value,
  label,
}: {
  icon: React.ComponentProps<typeof Icon>['name'];
  value: string;
  label: string;
}) {
  return (
    <View className="flex-1 flex-row items-center gap-2">
      <Icon name={icon} size={15} className="text-brand-500" />
      <View>
        <Text className="text-[13px] font-extrabold text-ink-900 dark:text-white">{value}</Text>
        <Text className="text-[10.5px] text-ink-400">{label}</Text>
      </View>
    </View>
  );
}
