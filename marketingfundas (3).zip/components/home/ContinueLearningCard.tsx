import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Icon } from '@/components/ui/Icon';
import { gradients } from '@/constants/theme';
import type { EnrolledCourse } from '@/context/LearningContext';
import type { Lesson } from '@/types';
import { formatDuration } from '@/utils/format';

interface ContinueLearningCardProps {
  item: EnrolledCourse;
  nextLesson?: Lesson;
  onPress: () => void;
}

/** Hero card on the dashboard that resumes the learner's current lesson. */
export function ContinueLearningCard({ item, nextLesson, onPress }: ContinueLearningCardProps) {
  const { course, percent, completedLessons, totalLessons, completed } = item;

  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      className="overflow-hidden rounded-[28px]"
      style={({ pressed }) => ({ opacity: pressed ? 0.94 : 1 })}
    >
      <LinearGradient colors={gradients.hero} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
        <View className="p-4">
          <View className="flex-row items-center gap-3">
            <View className="h-[68px] w-[68px] overflow-hidden rounded-2xl border border-white/25">
              <Image
                source={{ uri: course.image }}
                style={{ width: '100%', height: '100%' }}
                contentFit="cover"
                transition={250}
              />
            </View>

            <View className="flex-1">
              <Text className="text-[10.5px] font-bold uppercase tracking-[1.5px] text-white/70">
                {completed ? 'Course complete' : 'Continue learning'}
              </Text>
              <Text numberOfLines={2} className="mt-1 text-[15px] font-extrabold leading-5 text-white">
                {completed ? course.title : (nextLesson?.title ?? course.title)}
              </Text>
              <Text numberOfLines={1} className="mt-0.5 text-[11.5px] text-white/70">
                {completed ? course.instructor.name : course.title}
              </Text>
            </View>
          </View>

          <View className="mt-4">
            <View className="mb-2 flex-row items-center justify-between">
              <Text className="text-[11.5px] font-semibold text-white/80">
                {completedLessons}/{totalLessons} lessons
                {!completed && nextLesson
                  ? ` · ${formatDuration(nextLesson.durationMinutes)} next`
                  : ''}
              </Text>
              <Text className="text-[12px] font-extrabold text-white">{percent}%</Text>
            </View>
            <View className="h-2 w-full overflow-hidden rounded-full bg-white/25">
              <View
                className="h-full rounded-full bg-white"
                style={{ width: `${Math.max(4, percent)}%` }}
              />
            </View>
          </View>

          <View className="mt-4 flex-row items-center justify-between">
            <View className="flex-1 flex-row items-center gap-1.5 pr-3">
              <Icon name={completed ? 'ribbon' : 'flame'} size={15} color="#FBBF24" />
              <Text numberOfLines={1} className="flex-1 text-[12px] font-semibold text-white/80">
                {completed ? 'Certificate unlocked' : 'Pick up right where you stopped'}
              </Text>
            </View>
            <View className="h-9 flex-row items-center gap-1.5 rounded-full bg-white px-4">
              <Icon name={completed ? 'refresh' : 'play'} size={13} color="#412FBA" />
              <Text className="text-[12.5px] font-extrabold text-brand-700">
                {completed ? 'Review' : 'Resume'}
              </Text>
            </View>
          </View>
        </View>
      </LinearGradient>
    </Pressable>
  );
}
