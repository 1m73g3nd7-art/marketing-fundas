import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Icon } from '@/components/ui/Icon';
import type { AiTool } from '@/constants/ai-tools';

export function AiToolCard({ tool, onPress }: { tool: AiTool; onPress: () => void }) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={{ width: 190 }}
      className="rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900"
    >
      <View
        className="h-10 w-10 items-center justify-center rounded-2xl"
        style={{ backgroundColor: `${tool.color}1A` }}
      >
        <Icon name={tool.icon} size={19} color={tool.color} />
      </View>

      <Text className="mt-3 text-[14px] font-extrabold text-ink-900 dark:text-white">
        {tool.name}
      </Text>
      <Text numberOfLines={2} className="mt-1 text-[12px] leading-4 text-ink-400">
        {tool.tagline}
      </Text>

      <View className="mt-3 flex-row items-center gap-1">
        <Text className="text-[11px] font-bold text-brand-600 dark:text-brand-300">Open tool</Text>
        <Icon name="open-outline" size={11} className="text-brand-600 dark:text-brand-300" />
      </View>
    </Pressable>
  );
}
