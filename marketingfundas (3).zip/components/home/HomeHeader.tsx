import React from 'react';
import { Pressable, Text, View } from 'react-native';

import { Avatar } from '@/components/ui/Avatar';
import { IconButton } from '@/components/ui/IconButton';
import { firstName, greetingForNow } from '@/utils/format';

interface HomeHeaderProps {
  name?: string;
  photoURL?: string | null;
  unreadCount?: number;
  onProfilePress: () => void;
  onNotificationsPress: () => void;
}

export function HomeHeader({
  name,
  photoURL,
  unreadCount = 0,
  onProfilePress,
  onNotificationsPress,
}: HomeHeaderProps) {
  return (
    <View className="flex-row items-center gap-3 px-5 pb-4 pt-2">
      <Pressable accessibilityRole="button" accessibilityLabel="Open profile" onPress={onProfilePress}>
        <Avatar uri={photoURL} name={name} size={46} ring />
      </Pressable>

      <View className="flex-1">
        <Text className="text-[12.5px] font-medium text-ink-400">{greetingForNow()}</Text>
        <Text
          numberOfLines={1}
          className="text-[19px] font-extrabold tracking-tight text-ink-900 dark:text-white"
        >
          Hello, {firstName(name)} 👋
        </Text>
      </View>

      <IconButton
        name="notifications-outline"
        accessibilityLabel="Notifications"
        badge={unreadCount}
        onPress={onNotificationsPress}
      />
    </View>
  );
}
