import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Text, View } from 'react-native';

import { gradients } from '@/constants/theme';

interface WeeklyBarsProps {
  /** Seven values, oldest first. */
  data: number[];
  height?: number;
  unit?: string;
}

const DAY_LABELS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

/** Seven-day study-time bar chart. */
export function WeeklyBars({ data, height = 120, unit = 'm' }: WeeklyBarsProps) {
  const today = new Date().getDay();
  const labels = Array.from({ length: 7 }, (_, index) => DAY_LABELS[(today - 6 + index + 7) % 7]);
  const max = Math.max(...data, 1);

  return (
    <View className="flex-row items-end justify-between" style={{ height: height + 34 }}>
      {data.map((value, index) => {
        const barHeight = Math.max(6, (value / max) * height);
        const isToday = index === data.length - 1;
        return (
          <View key={index} className="flex-1 items-center">
            <Text className="mb-1.5 text-[10px] font-bold text-ink-400">
              {value > 0 ? `${value}${unit}` : ''}
            </Text>
            <View
              className="w-[22px] overflow-hidden rounded-full bg-ink-100 dark:bg-ink-800"
              style={{ height }}
            >
              <View className="flex-1 justify-end">
                <LinearGradient
                  colors={isToday ? gradients.ai : gradients.brand}
                  start={{ x: 0, y: 1 }}
                  end={{ x: 0, y: 0 }}
                  style={{ height: barHeight, borderRadius: 11 }}
                />
              </View>
            </View>
            <Text
              className={`mt-2 text-[11px] font-bold ${
                isToday ? 'text-brand-600 dark:text-brand-300' : 'text-ink-400'
              }`}
            >
              {labels[index]}
            </Text>
          </View>
        );
      })}
    </View>
  );
}
