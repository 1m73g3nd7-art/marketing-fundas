import React from 'react';
import { Text, View } from 'react-native';

import { Icon, type IconName } from '@/components/ui/Icon';

interface StatTileProps {
  icon: IconName;
  value: string;
  label: string;
  tone?: 'brand' | 'accent' | 'gold' | 'success';
  className?: string;
}

const tones = {
  brand: { bg: 'bg-brand-50 dark:bg-brand-950', icon: 'text-brand-600 dark:text-brand-300' },
  accent: { bg: 'bg-accent-100 dark:bg-accent-900', icon: 'text-accent-600 dark:text-accent-300' },
  gold: { bg: 'bg-amber-100 dark:bg-amber-950', icon: 'text-amber-600 dark:text-amber-400' },
  success: { bg: 'bg-emerald-100 dark:bg-emerald-950', icon: 'text-emerald-600 dark:text-emerald-400' },
} as const;

export function StatTile({ icon, value, label, tone = 'brand', className = '' }: StatTileProps) {
  const style = tones[tone];
  return (
    <View
      className={`flex-1 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900 ${className}`}
    >
      <View className={`h-9 w-9 items-center justify-center rounded-xl ${style.bg}`}>
        <Icon name={icon} size={17} className={style.icon} />
      </View>
      <Text className="mt-3 text-xl font-extrabold tracking-tight text-ink-900 dark:text-white">
        {value}
      </Text>
      <Text className="mt-0.5 text-[12px] font-medium text-ink-400">{label}</Text>
    </View>
  );
}
