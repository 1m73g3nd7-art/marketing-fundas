import React from 'react';
import { Text, View } from 'react-native';
import Svg, { Circle, Defs, LinearGradient as SvgGradient, Stop } from 'react-native-svg';

import { palette } from '@/constants/theme';
import { useSettings } from '@/context/SettingsContext';

interface RingProgressProps {
  /** 0–100 */
  value: number;
  size?: number;
  strokeWidth?: number;
  label?: string;
  caption?: string;
  colors?: [string, string];
}

/** Circular completion indicator with a brand gradient stroke. */
export function RingProgress({
  value,
  size = 132,
  strokeWidth = 12,
  label,
  caption,
  colors = [palette.brand[500], palette.accent[400]],
}: RingProgressProps) {
  const { isDark } = useSettings();
  const clamped = Math.max(0, Math.min(100, value));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const dash = (clamped / 100) * circumference;
  const gradientId = `ring-${Math.round(size)}-${colors[0].replace('#', '')}`;

  return (
    <View style={{ width: size, height: size }} className="items-center justify-center">
      <Svg width={size} height={size}>
        <Defs>
          <SvgGradient id={gradientId} x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor={colors[0]} />
            <Stop offset="1" stopColor={colors[1]} />
          </SvgGradient>
        </Defs>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={isDark ? palette.ink[800] : palette.ink[100]}
          strokeWidth={strokeWidth}
          fill="none"
        />
        {clamped > 0 ? (
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={`url(#${gradientId})`}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={`${dash} ${circumference}`}
            fill="none"
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
        ) : null}
      </Svg>

      <View className="absolute items-center">
        <Text
          style={{ fontSize: size * 0.24 }}
          className="font-extrabold tracking-tight text-ink-900 dark:text-white"
        >
          {label ?? `${Math.round(clamped)}%`}
        </Text>
        {caption ? (
          <Text className="mt-0.5 text-[11px] font-semibold uppercase tracking-wider text-ink-400">
            {caption}
          </Text>
        ) : null}
      </View>
    </View>
  );
}
