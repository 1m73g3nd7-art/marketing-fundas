# Marketing Fundas

A premium, mobile-first e-learning app for **Digital Marketing + AI** education, built with
Expo (React Native), Expo Router, NativeWind and Firebase.

Learners can explore courses, enrol, watch lessons, take notes, track progress and streaks,
pass a final assessment and download a shareable certificate — in light or dark mode, on
Android, iOS and the web.

---

## Quick start

```bash
npm install
npm start          # then press a (Android), i (iOS) or w (web)
```

The app runs immediately with **no configuration**. Without Firebase credentials it starts in
demo mode: the bundled catalogue of 10 courses and 10 assessments is used, and accounts,
enrolments, progress, notes, quiz results and certificates are stored on the device.

To connect a real backend, copy `.env.example` to `.env`, fill in your Firebase values and
restart. Nothing else changes — every service falls back to the local source only when
Firebase is absent or unreachable.

```bash
cp .env.example .env
```

---

## Features

| Area | What is included |
| --- | --- |
| **Splash** | Animated brand mark with an orbiting AI-inspired ring, then automatic routing |
| **Onboarding** | Three illustrated slides with skip, next, get-started and page indicators |
| **Auth** | Email/password login and sign up, forgot password, Google Sign-In, full form validation |
| **Home** | Greeting header, continue-learning hero, progress ring, popular and new course rails, AI tools, categories |
| **Courses** | Search, eight categories, sort and level filters, price/rating/duration on every card |
| **Course details** | Banner, stats, outcomes, full curriculum, requirements, instructor, reviews, Enroll → Start Learning |
| **Lesson player** | Video player, prev/next, mark complete, Overview / Notes / Resources / Discussion tabs, live curriculum, auto-saved progress |
| **My Learning** | In Progress / Completed / All filters, progress bars, lesson counters |
| **Progress** | Overall ring, streak, time spent, seven-day chart, per-course breakdown |
| **Quiz** | Multiple choice, per-question progress, prev/next, submit, scored result, answer review, retry |
| **Certificate** | On-screen certificate, PDF download, native share, print preview, verifiable ID |
| **Notifications** | New courses, new lessons, updates, quiz and learning reminders, unread badges |
| **Profile & settings** | Edit profile with photo picker, certificates, dark mode, notification toggles, change password, privacy, delete account |

---

## Project structure

```
app/                    Expo Router routes (thin wrappers around screens)
  (auth)/               login, signup, forgot-password
  (tabs)/               home, courses, my learning, profile
  course/[id]           course details
  learn/[courseId]      lesson player
  quiz/[courseId]       assessment
  certificate/[courseId]
components/
  ui/                   Button, Input, Card, Badge, ProgressBar, Avatar, ListRow, …
  course/               course cards, lesson rows, reviews, certificate preview
  home/                 dashboard header, continue-learning hero, AI tool cards
  charts/               ring progress, weekly bars, stat tiles
screens/                All screen implementations, grouped by area
services/               firebase, auth, courses, learning, notifications, certificates
context/                Auth, Settings (theme + onboarding), Learning
hooks/                  useOnboarding, useGoogleAuth, useDebounce, useThemeColors
utils/                  formatting, validation, progress maths, certificate HTML
constants/              theme tokens, categories, AI tools, config
data/                   sample courses, quizzes, instructors, notifications
types/                  shared domain types
```

Routes stay thin on purpose: every screen lives in `screens/` and can be reused or tested
independently of the router.

---

## Firebase

### Setup

1. Create a Firebase project and add a **Web** app.
2. Enable **Authentication → Email/Password** (and Google, if you want that button live).
3. Create a **Firestore** database.
4. Copy the web config values into `.env`.
5. Deploy the included rules: `firebase deploy --only firestore:rules`.

### Data model

The app reads and writes exactly this shape, which is also what an admin console should
manage:

```
courses/{courseId}                        Course (sections + lessons embedded)
quizzes/{quizId}                          Quiz
instructors/{instructorId}                Instructor
notifications/{notificationId}            Broadcast notification

users/{uid}                               UserProfile
users/{uid}/enrollments/{courseId}        Enrollment (per-lesson progress)
users/{uid}/quizAttempts/{attemptId}      QuizAttempt
users/{uid}/certificates/{certificateId}  Certificate
users/{uid}/notifications/{id}            AppNotification
users/{uid}/notes/{lessonId}              { text, updatedAt }
```

`firestore.rules` grants learners access to their own subtree only, keeps the catalogue
read-only from the app, and reserves catalogue writes for the `admin` custom claim.

### Seeding the catalogue

```bash
npm run export:sample-data                # writes scripts/sample-data.json
npm i -D firebase-admin
GOOGLE_APPLICATION_CREDENTIALS=./service-account.json \
FIREBASE_PROJECT_ID=your-project-id \
npm run seed:firestore
```

### Google Sign-In

Create OAuth client IDs in the Google Cloud console and add them to `.env`. Until then the
button signs in a sample learner so the flow is never a dead end.

---

## Public download page

`docs/download.html` is a self-contained landing page for distributing the APK outside the
Play Store. Screenshots and the app icon are embedded, so it is a single file with no assets
to upload alongside it.

1. Build the APK (see above). If you used the GitHub Actions release flow, the APK already
   has a public URL.
2. Open `docs/download.html` and set **either** `GITHUB_REPO` to your `owner/repo` — the page
   then always links to your latest release, so it never needs editing again — **or**
   `APK_URL` to any direct link, which takes priority.
3. Host `download.html` and share its URL.

Until one of them is set the button reads "Download link not set yet" rather than linking
nowhere. The page covers the "unknown sources" prompt Android shows for sideloaded apps,
which is the step most people get stuck on.


---

## Design system

Tailwind classes are the styling API throughout; `constants/theme.ts` holds the raw values
for gradients, SVG charts and navigation chrome.

- **Brand** `brand-600 #4F3BDE` — primary actions, active states
- **AI accent** `accent-400 #2DD4C4` — AI features, completion, gradients
- **Gold** `gold-500 #F59E0B` — ratings, bestseller, certificates
- **Ink** — neutral scale from `ink-50` (light background) to `ink-950` (dark background)

Dark mode uses NativeWind's class strategy. The resolved scheme lives in `SettingsContext`,
so a manual Light/Dark choice and "follow system" both work on every platform.

---

## Building an Android APK

The native Android project is already generated in `android/`, with the app name,
branded launcher icons, splash screen and package id (`com.marketingfundas.app`) in place.
Pick whichever path suits you.

### Option A — GitHub Actions (nothing to install)

`.github/workflows/build-apk.yml` builds the APK on GitHub's runners, which already have the
Android SDK. Push this project to a GitHub repository and the build starts on its own; the
APK appears under **Actions → the run → Artifacts**.

To get a permanent public download URL, push a version tag:

```bash
git tag v1.0.0
git push origin v1.0.0
```

That publishes a Release with the APK attached, always reachable at:

```
https://github.com/<owner>/<repo>/releases/latest/download/marketing-fundas-v1.0.0.apk
```

which is exactly the link `docs/download.html` builds once you set `GITHUB_REPO` in it.

### Option B — EAS cloud build (no Android SDK needed)

```bash
npm install -g eas-cli
eas login                                  # free Expo account
eas build --platform android --profile preview
```

`eas.json` defines the profiles. `preview` and `development` produce an **APK**;
`production` produces an AAB for the Play Store, and `production-apk` produces a signed
APK instead. EAS gives you a download link when the build finishes.

### Option C — Local Gradle build

Requires JDK 17+ and the Android SDK (easiest via Android Studio, which also sets
`ANDROID_HOME`).

```bash
npm install
npm run apk          # → android/app/build/outputs/apk/release/app-release.apk
```

`npm run apk:debug` builds a debug APK instead. If you change anything in `app.json`
(icons, name, permissions, plugins), regenerate the native project first:

```bash
npm run prebuild     # expo prebuild --platform android --clean
```

### Signing

The generated `release` build type is signed with the bundled **debug keystore**, so the
APK installs and runs immediately for testing and sideloading. Before publishing to the
Play Store, generate your own keystore and point `signingConfigs.release` in
`android/app/build.gradle` at it — see
<https://reactnative.dev/docs/signed-apk-android>.


---

## Scripts

| Command | Purpose |
| --- | --- |
| `npm start` | Start the Expo dev server |
| `npm run android` / `ios` / `web` | Run on a specific platform |
| `npm run prebuild` | Regenerate the native `android/` project from `app.json` |
| `npm run apk` | Build a release APK with Gradle |
| `npm run apk:debug` | Build a debug APK with Gradle |
| `npm run typecheck` | TypeScript, no emit |
| `npm run lint` | ESLint via `expo lint` |
| `npm run format` | Prettier with Tailwind class sorting |
| `npm run export:sample-data` | Emit `scripts/sample-data.json` for seeding |
| `npm run seed:firestore` | Upload the sample catalogue to Firestore |

---

## Notes

- Lesson videos point at public sample MP4s (`data/videos.ts`). Replace them with your own
  CDN or Firebase Storage URLs, or set `videoUrl` per lesson in Firestore.
- Course imagery uses Unsplash URLs; swap them for your own assets before shipping.
- Certificates are rendered from HTML (`utils/certificate-html.ts`) and exported as a PDF by
  `expo-print`, so the printed document matches the in-app preview.
