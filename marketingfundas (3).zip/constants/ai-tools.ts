import type { Ionicons } from '@expo/vector-icons';
import type { ComponentProps } from 'react';

export interface AiTool {
  id: string;
  name: string;
  tagline: string;
  category: string;
  icon: ComponentProps<typeof Ionicons>['name'];
  color: string;
  url: string;
}

/** Curated AI tools surfaced on the dashboard "AI Tools for Marketers" rail. */
export const AI_TOOLS: AiTool[] = [
  {
    id: 'claude',
    name: 'Claude',
    tagline: 'Campaign copy, briefs & strategy drafts',
    category: 'Writing',
    icon: 'chatbubbles-outline',
    color: '#D97706',
    url: 'https://claude.ai',
  },
  {
    id: 'gpt',
    name: 'ChatGPT',
    tagline: 'Ad variations and audience research',
    category: 'Writing',
    icon: 'sparkles-outline',
    color: '#14B8AA',
    url: 'https://chat.openai.com',
  },
  {
    id: 'midjourney',
    name: 'Midjourney',
    tagline: 'Creative assets for social & display ads',
    category: 'Design',
    icon: 'image-outline',
    color: '#8B5CF6',
    url: 'https://www.midjourney.com',
  },
  {
    id: 'surfer',
    name: 'Surfer SEO',
    tagline: 'AI-assisted content briefs that rank',
    category: 'SEO',
    icon: 'trending-up-outline',
    color: '#0EA5E9',
    url: 'https://surferseo.com',
  },
  {
    id: 'canva',
    name: 'Canva Magic Studio',
    tagline: 'On-brand creatives in minutes',
    category: 'Design',
    icon: 'color-palette-outline',
    color: '#EC4899',
    url: 'https://www.canva.com/magic-studio/',
  },
  {
    id: 'ga4',
    name: 'GA4 + AI Insights',
    tagline: 'Predictive audiences and anomaly alerts',
    category: 'Analytics',
    icon: 'analytics-outline',
    color: '#4F3BDE',
    url: 'https://analytics.google.com',
  },
];
