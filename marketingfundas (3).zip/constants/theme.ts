/**
 * Design tokens. Tailwind classes stay the primary styling API — these values
 * exist for the places React Native needs a raw colour (gradients, SVG charts,
 * status bar, navigation themes).
 */

export const palette = {
  brand: {
    50: '#EEF0FF',
    100: '#E0E3FF',
    200: '#C6CBFF',
    300: '#A3A9FF',
    400: '#807EFB',
    500: '#6355F0',
    600: '#4F3BDE',
    700: '#412FBA',
    800: '#362A96',
    900: '#2F2778',
    950: '#1C1746',
  },
  accent: {
    100: '#CFFAF3',
    300: '#66E8DA',
    400: '#2DD4C4',
    500: '#14B8AA',
    600: '#0B948B',
  },
  gold: { 400: '#FBBF24', 500: '#F59E0B', 600: '#D97706' },
  ink: {
    50: '#F6F7FB',
    100: '#ECEEF5',
    200: '#DCE0EC',
    300: '#B9C0D4',
    400: '#8992AC',
    500: '#646D89',
    600: '#4B5470',
    700: '#3A4258',
    800: '#232838',
    850: '#191D2A',
    900: '#12151F',
    950: '#0A0C13',
  },
  success: '#22C55E',
  danger: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
} as const;

export const gradients = {
  brand: [palette.brand[600], palette.brand[400]] as const,
  hero: ['#2F2778', '#4F3BDE', '#2DD4C4'] as const,
  ai: ['#4F3BDE', '#14B8AA'] as const,
  gold: ['#F59E0B', '#FBBF24'] as const,
  night: ['#1C1746', '#0A0C13'] as const,
  glass: ['rgba(255,255,255,0.18)', 'rgba(255,255,255,0.04)'] as const,
};

export const themeColors = {
  light: {
    background: palette.ink[50],
    surface: palette.white,
    surfaceAlt: palette.ink[100],
    border: palette.ink[200],
    text: palette.ink[900],
    textMuted: palette.ink[500],
    primary: palette.brand[600],
    tabBar: palette.white,
    card: palette.white,
  },
  dark: {
    background: palette.ink[950],
    surface: palette.ink[900],
    surfaceAlt: palette.ink[850],
    border: palette.ink[800],
    text: palette.ink[50],
    textMuted: palette.ink[400],
    primary: palette.brand[400],
    tabBar: palette.ink[900],
    card: palette.ink[900],
  },
} as const;

export const radius = { sm: 8, md: 12, lg: 16, xl: 20, xxl: 28 };

export const shadow = {
  card: {
    shadowColor: '#1C1746',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 4,
  },
  floating: {
    shadowColor: '#1C1746',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.18,
    shadowRadius: 28,
    elevation: 10,
  },
};
