export const APP_NAME = 'Marketing Fundas';
export const APP_TAGLINE = 'Digital Marketing + AI, made practical.';
export const SUPPORT_EMAIL = 'support@marketingfundas.com';
export const SUPPORT_PHONE = '+91 90000 00000';
export const WEBSITE = 'https://marketingfundas.com';

/** Storage keys used by the local (offline / demo) data source. */
export const STORAGE_KEYS = {
  onboarded: 'mf:onboarded',
  session: 'mf:session',
  users: 'mf:users',
  enrollments: 'mf:enrollments',
  quizAttempts: 'mf:quiz-attempts',
  certificates: 'mf:certificates',
  notifications: 'mf:notifications',
  notes: 'mf:notes',
  settings: 'mf:settings',
  activity: 'mf:activity',
  wishlist: 'mf:wishlist',
} as const;

export const QUIZ_PASSING_SCORE = 70;
