import type { Ionicons } from '@expo/vector-icons';
import type { ComponentProps } from 'react';

import type { CategoryId } from '@/types';

type IoniconName = ComponentProps<typeof Ionicons>['name'];

export interface CategoryMeta {
  id: CategoryId;
  label: string;
  short: string;
  icon: IoniconName;
  color: string;
}

export const CATEGORIES: CategoryMeta[] = [
  { id: 'digital-marketing', label: 'Digital Marketing', short: 'Digital', icon: 'rocket-outline', color: '#4F3BDE' },
  { id: 'ai-marketing', label: 'AI Marketing', short: 'AI', icon: 'sparkles-outline', color: '#14B8AA' },
  { id: 'seo', label: 'SEO', short: 'SEO', icon: 'search-outline', color: '#F59E0B' },
  { id: 'social-media', label: 'Social Media Marketing', short: 'Social', icon: 'share-social-outline', color: '#EC4899' },
  { id: 'google-ads', label: 'Google Ads', short: 'Google Ads', icon: 'logo-google', color: '#EA4335' },
  { id: 'meta-ads', label: 'Meta Ads', short: 'Meta Ads', icon: 'logo-facebook', color: '#1877F2' },
  { id: 'content-marketing', label: 'Content Marketing', short: 'Content', icon: 'create-outline', color: '#8B5CF6' },
  { id: 'analytics', label: 'Analytics', short: 'Analytics', icon: 'bar-chart-outline', color: '#0EA5E9' },
];

export const categoryById = (id: CategoryId): CategoryMeta =>
  CATEGORIES.find((c) => c.id === id) ?? CATEGORIES[0];
