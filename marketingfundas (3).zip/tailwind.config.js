/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    './app/**/*.{js,jsx,ts,tsx}',
    './components/**/*.{js,jsx,ts,tsx}',
    './screens/**/*.{js,jsx,ts,tsx}',
  ],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#EEF0FF',
          100: '#E0E3FF',
          200: '#C6CBFF',
          300: '#A3A9FF',
          400: '#807EFB',
          500: '#6355F0',
          600: '#4F3BDE',
          700: '#412FBA',
          800: '#362A96',
          900: '#2F2778',
          950: '#1C1746',
        },
        accent: {
          50: '#ECFEFB',
          100: '#CFFAF3',
          200: '#A2F4E9',
          300: '#66E8DA',
          400: '#2DD4C4',
          500: '#14B8AA',
          600: '#0B948B',
          700: '#0E766F',
          800: '#115E5A',
          900: '#134E4A',
        },
        gold: {
          400: '#FBBF24',
          500: '#F59E0B',
          600: '#D97706',
        },
        ink: {
          50: '#F6F7FB',
          100: '#ECEEF5',
          200: '#DCE0EC',
          300: '#B9C0D4',
          400: '#8992AC',
          500: '#646D89',
          600: '#4B5470',
          700: '#3A4258',
          800: '#232838',
          850: '#191D2A',
          900: '#12151F',
          950: '#0A0C13',
        },
      },
      borderRadius: {
        '4xl': '32px',
      },
    },
  },
  plugins: [],
};
