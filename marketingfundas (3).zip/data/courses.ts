import type { Course, Lesson, LessonResource, Review, Section } from '@/types';
import { INSTRUCTORS } from './instructors';
import { nextVideo } from './videos';

type LessonSeed = [title: string, description: string, minutes: number, resources?: LessonResource[]];

const res = (
  courseId: string,
  index: number,
  title: string,
  type: LessonResource['type'],
  size?: string,
): LessonResource => ({
  id: `${courseId}-r${index}`,
  title,
  type,
  size,
  url: 'https://marketingfundas.com/resources',
});

const buildSections = (
  courseId: string,
  seeds: [sectionTitle: string, lessons: LessonSeed[]][],
): Section[] =>
  seeds.map(([sectionTitle, lessons], si) => ({
    id: `${courseId}-s${si + 1}`,
    title: sectionTitle,
    lessons: lessons.map<Lesson>(([title, description, durationMinutes, resources], li) => ({
      id: `${courseId}-s${si + 1}-l${li + 1}`,
      title,
      description,
      durationMinutes,
      videoUrl: nextVideo(),
      isPreview: si === 0 && li === 0,
      resources,
    })),
  }));

const reviews = (courseId: string, seeds: [string, string, number, string, string][]): Review[] =>
  seeds.map(([userName, avatar, rating, date, comment], i) => ({
    id: `${courseId}-rev${i + 1}`,
    userName,
    avatar,
    rating,
    date,
    comment,
  }));

const AVATARS = [
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&q=80',
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=128&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=128&q=80',
  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=128&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=128&q=80',
];

const totalMinutes = (sections: Section[]) =>
  sections.reduce((sum, s) => sum + s.lessons.reduce((ls, l) => ls + l.durationMinutes, 0), 0);

const make = (
  course: Omit<Course, 'durationMinutes'> & { durationMinutes?: number },
): Course => ({
  ...course,
  durationMinutes: course.durationMinutes ?? totalMinutes(course.sections),
});

/* ------------------------------------------------------------------ */
/* Courses                                                             */
/* ------------------------------------------------------------------ */

const c1 = 'dm-mastery';
const c2 = 'ai-marketing';
const c3 = 'seo-2026';
const c4 = 'social-growth';
const c5 = 'google-ads';
const c6 = 'meta-ads';
const c7 = 'content-engine';
const c8 = 'ga4-analytics';
const c9 = 'ai-content-studio';
const c10 = 'brand-storytelling';

export const SAMPLE_COURSES: Course[] = [
  make({
    id: c1,
    title: 'Digital Marketing Mastery 2026',
    subtitle: 'From fundamentals to a full-funnel growth plan',
    description:
      'A complete, practical path through modern digital marketing. You will build a real campaign plan as you go — audience research, channel strategy, landing pages, paid and organic acquisition, email lifecycle and reporting — and finish with a portfolio-ready growth plan you can show to any employer or client.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80',
    category: 'digital-marketing',
    tags: ['Strategy', 'Funnels', 'Career'],
    instructor: INSTRUCTORS.aarav,
    level: 'Beginner',
    language: 'English + Hindi subtitles',
    rating: 4.9,
    ratingCount: 3241,
    studentCount: 18420,
    price: 2999,
    originalPrice: 7999,
    updatedAt: '2026-06-14',
    featured: true,
    bestseller: true,
    outcomes: [
      'Plan a full-funnel digital marketing strategy from scratch',
      'Research audiences and write positioning that converts',
      'Choose the right channel mix for any budget',
      'Build landing pages and offers that turn clicks into leads',
      'Set up tracking so every rupee is measurable',
      'Present results to clients and stakeholders with confidence',
    ],
    requirements: [
      'No prior marketing experience needed',
      'A laptop with an internet connection',
      'A free Google account for the hands-on exercises',
    ],
    sections: buildSections(c1, [
      [
        'Foundations',
        [
          ['Welcome & how to use this course', 'Meet your instructor and set up your workspace, templates and course tracker.', 6],
          ['The modern marketing funnel', 'Awareness, consideration, conversion and retention — and the metric that matters at each stage.', 14],
          ['Audience research that actually helps', 'Interviews, review mining and search data: how to find the words your customers use.', 18, [res(c1, 1, 'Audience research template', 'template', '240 KB')]],
          ['Positioning & messaging', 'Write a positioning statement and three message angles you can test.', 16],
        ],
      ],
      [
        'Channels & Campaigns',
        [
          ['Choosing your channel mix', 'A simple scoring model for picking channels based on budget, audience and speed to learn.', 15],
          ['Landing pages that convert', 'Structure, proof, friction and the five sections every high-converting page has.', 20, [res(c1, 2, 'Landing page checklist', 'checklist', '120 KB')]],
          ['Paid acquisition basics', 'How auctions, bidding and creative testing work across Google and Meta.', 22],
          ['Email & lifecycle marketing', 'Welcome flows, nurture sequences and win-backs that add revenue without extra spend.', 19],
          ['Organic and content compounding', 'How SEO, social and community reduce your cost of acquisition over time.', 17],
        ],
      ],
      [
        'Measure & Grow',
        [
          ['Tracking setup essentials', 'UTMs, conversions and the difference between platform and analytics numbers.', 18],
          ['Reading a marketing dashboard', 'The eight numbers that tell you whether growth is real.', 16],
          ['Your growth plan project', 'Assemble everything into a one-page growth plan and present it.', 21, [res(c1, 3, 'Growth plan one-pager', 'template', '310 KB')]],
        ],
      ],
    ]),
    reviews: reviews(c1, [
      ['Priya S.', AVATARS[0], 5, '2026-05-28', 'Exactly what I needed as a career switcher. The growth plan project got me two interviews.'],
      ['Manish R.', AVATARS[1], 5, '2026-05-11', 'Aarav explains paid media without the jargon. The channel scoring model alone was worth it.'],
      ['Fatima K.', AVATARS[2], 4, '2026-04-30', 'Very practical. I would have liked one more case study on B2B, but the templates are excellent.'],
    ]),
  }),

  make({
    id: c2,
    title: 'AI-Powered Marketing: Tools, Prompts & Workflows',
    subtitle: 'Ship campaigns faster with AI as your teammate',
    description:
      'Learn to use AI where it genuinely helps: research, briefs, creative variations, audience analysis and reporting. You will build a reusable prompt library and three AI workflows that cut hours out of your week — while keeping brand voice, accuracy and judgement firmly in human hands.',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80',
    category: 'ai-marketing',
    tags: ['AI', 'Prompting', 'Automation'],
    instructor: INSTRUCTORS.neha,
    level: 'All Levels',
    language: 'English',
    rating: 4.8,
    ratingCount: 2178,
    studentCount: 14330,
    price: 3499,
    originalPrice: 8999,
    updatedAt: '2026-07-02',
    featured: true,
    isNew: true,
    outcomes: [
      'Write prompts that produce usable marketing output on the first try',
      'Build an AI-assisted content workflow end to end',
      'Use AI for audience research, ad variations and creative briefs',
      'Keep brand voice consistent with a reusable style guide prompt',
      'Spot and correct AI mistakes before they reach customers',
      'Automate reporting summaries for weekly stakeholder updates',
    ],
    requirements: [
      'Basic familiarity with marketing concepts helps but is not required',
      'Access to any modern AI assistant (free tiers work)',
    ],
    sections: buildSections(c2, [
      [
        'AI Foundations for Marketers',
        [
          ['What AI is good and bad at', 'A realistic map of where AI adds value in a marketing team — and where it costs you.', 12],
          ['Prompt anatomy', 'Role, context, constraints, examples and format: the five parts of a reliable prompt.', 17, [res(c2, 1, 'Prompt anatomy cheat sheet', 'pdf', '180 KB')]],
          ['Building your brand voice prompt', 'Turn your tone-of-voice doc into a prompt block you reuse everywhere.', 15],
        ],
      ],
      [
        'AI Workflows That Save Hours',
        [
          ['Research workflow', 'From a blank page to an audience brief with sources you can verify.', 19],
          ['Content workflow', 'Outline, draft, edit and repurpose — with quality gates at each step.', 23, [res(c2, 2, 'Content workflow map', 'template', '260 KB')]],
          ['Ad creative workflow', 'Generate, cluster and prioritise ad variations for testing.', 18],
          ['Reporting workflow', 'Turn raw numbers into a stakeholder-ready narrative in minutes.', 16],
        ],
      ],
      [
        'Quality, Ethics & Scale',
        [
          ['Fact-checking and hallucinations', 'A practical review checklist before anything goes live.', 14, [res(c2, 3, 'AI review checklist', 'checklist', '90 KB')]],
          ['Disclosure, copyright and brand safety', 'What to disclose, what to avoid, and how to document decisions.', 16],
          ['Building your team prompt library', 'Structure, naming and versioning so prompts stay useful.', 15],
        ],
      ],
    ]),
    reviews: reviews(c2, [
      ['Arjun M.', AVATARS[3], 5, '2026-06-20', 'The workflows are the real value here. My weekly reporting went from 3 hours to 25 minutes.'],
      ['Divya P.', AVATARS[4], 5, '2026-06-02', 'Neha is honest about what AI gets wrong. The review checklist saved me from a bad launch.'],
      ['Kabir N.', AVATARS[1], 4, '2026-05-19', 'Great course. Would love a deeper section on automation tooling.'],
    ]),
  }),

  make({
    id: c3,
    title: 'SEO That Ranks in 2026',
    subtitle: 'Technical, on-page and content SEO in one practical path',
    description:
      'Search has changed — AI answers, entity understanding and stricter quality signals. This course teaches SEO the way it works now: solid technical foundations, content built around real intent, internal linking that compounds, and a measurement setup that shows what your work is worth.',
    image: 'https://images.unsplash.com/photo-1562577309-4932fdd64cd1?w=800&q=80',
    category: 'seo',
    tags: ['SEO', 'Technical', 'Content'],
    instructor: INSTRUCTORS.rahul,
    level: 'Intermediate',
    language: 'English',
    rating: 4.8,
    ratingCount: 1544,
    studentCount: 9870,
    price: 2499,
    originalPrice: 6499,
    updatedAt: '2026-05-22',
    bestseller: true,
    outcomes: [
      'Run a full technical SEO audit and prioritise fixes by impact',
      'Map keywords to search intent and page types',
      'Write content briefs that writers can execute without guesswork',
      'Build internal linking that lifts whole clusters',
      'Recover from traffic drops with a systematic diagnosis',
    ],
    requirements: [
      'A website you can access (yours or a practice site)',
      'Google Search Console access is helpful',
    ],
    sections: buildSections(c3, [
      [
        'Technical Foundations',
        [
          ['How search engines work today', 'Crawling, rendering, indexing and how AI answers changed the click landscape.', 16],
          ['Crawl and index audit', 'Find and fix the issues that quietly cap your growth.', 22, [res(c3, 1, 'Technical audit spreadsheet', 'template', '420 KB')]],
          ['Core Web Vitals in practice', 'What to fix first when speed scores are poor.', 18],
          ['Structured data that matters', 'The schema types worth implementing and how to validate them.', 15],
        ],
      ],
      [
        'Content & Intent',
        [
          ['Keyword research by intent', 'Group queries by what the searcher actually wants.', 20],
          ['Content briefs that rank', 'The brief format that keeps writers on-target.', 18, [res(c3, 2, 'Content brief template', 'template', '190 KB')]],
          ['On-page optimisation', 'Titles, headings, entities and the details people still get wrong.', 17],
          ['Topical authority and clusters', 'Plan a cluster that lifts every page in it.', 19],
        ],
      ],
      [
        'Authority & Measurement',
        [
          ['Digital PR and link earning', 'Repeatable link acquisition without spam.', 18],
          ['Diagnosing traffic drops', 'A decision tree for algorithm updates, technical faults and cannibalisation.', 21],
          ['SEO reporting that proves value', 'Reporting on revenue, not just rankings.', 16],
        ],
      ],
    ]),
    reviews: reviews(c3, [
      ['Sanjay T.', AVATARS[1], 5, '2026-05-15', 'The diagnosis decision tree helped me recover a client site in six weeks.'],
      ['Ritika A.', AVATARS[0], 5, '2026-04-27', 'Best explanation of intent mapping I have seen. Practical, no fluff.'],
      ['Owen D.', AVATARS[3], 4, '2026-04-08', 'Solid intermediate course. Assumes some familiarity with Search Console.'],
    ]),
  }),

  make({
    id: c4,
    title: 'Social Media Growth Systems',
    subtitle: 'Build an audience with repeatable content systems',
    description:
      'Stop guessing what to post. Build a content system — pillars, formats, hooks and a calendar — that works across Instagram, LinkedIn and YouTube Shorts. Includes community management, creator collaborations and a reporting setup that tells you what to make more of.',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&q=80',
    category: 'social-media',
    tags: ['Instagram', 'LinkedIn', 'Shorts'],
    instructor: INSTRUCTORS.sara,
    level: 'Beginner',
    language: 'English + Hindi subtitles',
    rating: 4.7,
    ratingCount: 2890,
    studentCount: 21140,
    price: 1999,
    originalPrice: 4999,
    updatedAt: '2026-06-30',
    outcomes: [
      'Define content pillars that match business goals',
      'Write hooks that stop the scroll',
      'Run a 30-day content calendar without burning out',
      'Grow with collaborations instead of paid boosts',
      'Report on social performance in business terms',
    ],
    requirements: ['A phone and at least one social account', 'No design experience needed'],
    sections: buildSections(c4, [
      [
        'Strategy & Positioning',
        [
          ['Pick your platform and promise', 'Where to focus first and what you will be known for.', 14],
          ['Content pillars', 'Four pillars that keep ideas flowing all year.', 16, [res(c4, 1, 'Content pillar worksheet', 'template', '150 KB')]],
          ['Competitive teardown', 'Learn from what already works in your niche.', 15],
        ],
      ],
      [
        'Creation Systems',
        [
          ['Hooks, retention and payoffs', 'The three-second rule and how to keep viewers watching.', 19],
          ['Batch production workflow', 'Film a month of content in one afternoon.', 21],
          ['Editing and captions on mobile', 'A fast, repeatable edit that looks professional.', 18],
          ['The 30-day calendar', 'Slot your pillars and formats into a schedule you can keep.', 16, [res(c4, 2, '30-day calendar', 'template', '210 KB')]],
        ],
      ],
      [
        'Growth & Community',
        [
          ['Collaborations and creator partnerships', 'Outreach that gets replies.', 17],
          ['Community management', 'Comments, DMs and turning followers into customers.', 15],
          ['Social analytics that matter', 'Reach, saves, shares and what each one tells you.', 16],
        ],
      ],
    ]),
    reviews: reviews(c4, [
      ['Ishita B.', AVATARS[4], 5, '2026-06-18', 'Batch production changed everything. I actually post consistently now.'],
      ['Vikram J.', AVATARS[3], 4, '2026-05-25', 'Great for beginners. Hooks module is gold.'],
      ['Ananya G.', AVATARS[2], 5, '2026-05-02', 'Went from 900 to 14k followers in four months using this system.'],
    ]),
  }),

  make({
    id: c5,
    title: 'Google Ads: Search, Performance Max & Beyond',
    subtitle: 'Run profitable campaigns, not expensive experiments',
    description:
      'A hands-on Google Ads course built around profitability. Account structure, keyword and match-type strategy, conversion tracking you can trust, Performance Max done properly, and a weekly optimisation routine that keeps cost per acquisition falling.',
    image: 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=800&q=80',
    category: 'google-ads',
    tags: ['PPC', 'Search', 'PMax'],
    instructor: INSTRUCTORS.aarav,
    level: 'Intermediate',
    language: 'English',
    rating: 4.9,
    ratingCount: 1320,
    studentCount: 8420,
    price: 3299,
    originalPrice: 7499,
    updatedAt: '2026-06-08',
    outcomes: [
      'Structure accounts for control and clean data',
      'Set up conversion tracking that matches your business reality',
      'Write ads and assets that lift quality signals',
      'Run Performance Max without losing visibility',
      'Follow a weekly optimisation routine that compounds',
    ],
    requirements: ['A Google Ads account (free to create)', 'Basic marketing knowledge'],
    sections: buildSections(c5, [
      [
        'Account Foundations',
        [
          ['How the auction really works', 'Quality signals, ad rank and why the highest bid does not always win.', 16],
          ['Account structure', 'Campaign and ad group structure that keeps data clean.', 18],
          ['Conversion tracking you can trust', 'Primary vs secondary conversions and value assignment.', 20, [res(c5, 1, 'Tracking setup checklist', 'checklist', '130 KB')]],
        ],
      ],
      [
        'Campaign Craft',
        [
          ['Keywords and match types in 2026', 'Where broad match helps and where it burns budget.', 19],
          ['Writing responsive search ads', 'Asset variety, pinning and testing discipline.', 17],
          ['Landing page alignment', 'Message match that lifts conversion rate and quality score.', 15],
          ['Performance Max, properly', 'Asset groups, signals, exclusions and reporting workarounds.', 24, [res(c5, 2, 'PMax launch checklist', 'checklist', '160 KB')]],
        ],
      ],
      [
        'Optimisation',
        [
          ['Bidding strategies explained', 'When to use tCPA, tROAS and manual control.', 18],
          ['The weekly optimisation routine', 'A 45-minute checklist that keeps accounts healthy.', 20],
          ['Scaling without breaking performance', 'Budget increases, geo expansion and creative refresh.', 17],
        ],
      ],
    ]),
    reviews: reviews(c5, [
      ['Nikhil C.', AVATARS[1], 5, '2026-06-01', 'PMax module is the clearest I have found anywhere. Cut our CPA by a third.'],
      ['Meera V.', AVATARS[0], 5, '2026-05-14', 'The weekly routine is now printed on my desk.'],
      ['Tom H.', AVATARS[3], 4, '2026-04-21', 'Very good, though you will want some account access to follow along.'],
    ]),
  }),

  make({
    id: c6,
    title: 'Meta Ads for Growth',
    subtitle: 'Creative-led performance on Facebook & Instagram',
    description:
      'Meta rewards creative volume and clean signals. Learn account structure that suits the algorithm, creative testing that produces winners consistently, event tracking with the Conversions API, and reporting that survives attribution noise.',
    image: 'https://images.unsplash.com/photo-1633675254053-d96c7668c3b8?w=800&q=80',
    category: 'meta-ads',
    tags: ['Meta', 'Creative Testing', 'CAPI'],
    instructor: INSTRUCTORS.aarav,
    level: 'Intermediate',
    language: 'English',
    rating: 4.7,
    ratingCount: 980,
    studentCount: 7310,
    price: 2999,
    originalPrice: 6999,
    updatedAt: '2026-05-30',
    outcomes: [
      'Structure campaigns for stable learning and clean tests',
      'Produce and test creative at the volume Meta needs',
      'Implement pixel plus Conversions API tracking',
      'Read results correctly despite attribution gaps',
      'Scale winners without resetting performance',
    ],
    requirements: ['A Meta Business account', 'Some paid media experience recommended'],
    sections: buildSections(c6, [
      [
        'Setup & Signals',
        [
          ['Business Manager setup', 'Assets, permissions and the mistakes that cost you later.', 15],
          ['Pixel and Conversions API', 'Event quality, deduplication and match rates.', 22, [res(c6, 1, 'CAPI setup guide', 'pdf', '340 KB')]],
          ['Campaign structure', 'Consolidation, budgets and giving the algorithm room to learn.', 18],
        ],
      ],
      [
        'Creative Engine',
        [
          ['Creative strategy', 'Angles, formats and the creative brief that produces winners.', 20],
          ['Testing framework', 'How many creatives, how much budget and how long.', 19, [res(c6, 2, 'Creative testing tracker', 'template', '200 KB')]],
          ['UGC and iteration', 'Turning one winner into ten variations.', 17],
        ],
      ],
      [
        'Scale & Measure',
        [
          ['Reading Meta reporting honestly', 'Attribution windows, incrementality and blended metrics.', 19],
          ['Scaling playbook', 'Vertical and horizontal scaling without volatility.', 18],
          ['Retention and retargeting', 'Warm audiences that stay profitable.', 16],
        ],
      ],
    ]),
    reviews: reviews(c6, [
      ['Rohit K.', AVATARS[3], 5, '2026-05-20', 'Creative testing framework is worth the price by itself.'],
      ['Sneha L.', AVATARS[2], 4, '2026-04-29', 'Clear and current. CAPI section took me two watches but it works.'],
      ['Aditya S.', AVATARS[1], 5, '2026-04-12', 'Finally understand blended reporting. Our decisions are much better now.'],
    ]),
  }),

  make({
    id: c7,
    title: 'Content Marketing Engine',
    subtitle: 'Plan, produce and distribute content that compounds',
    description:
      'Build a content operation instead of a publishing habit. Strategy, editorial calendar, production workflow, distribution loops and a measurement model that connects content to pipeline and revenue.',
    image: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&q=80',
    category: 'content-marketing',
    tags: ['Editorial', 'Distribution', 'Repurposing'],
    instructor: INSTRUCTORS.sara,
    level: 'All Levels',
    language: 'English',
    rating: 4.6,
    ratingCount: 760,
    studentCount: 6120,
    price: 1799,
    originalPrice: 4499,
    updatedAt: '2026-04-18',
    outcomes: [
      'Build a content strategy tied to business goals',
      'Run an editorial calendar that ships on time',
      'Repurpose one asset into a week of content',
      'Design distribution loops instead of one-off launches',
      'Attribute content to pipeline and revenue',
    ],
    requirements: ['No prerequisites'],
    sections: buildSections(c7, [
      [
        'Strategy',
        [
          ['Content strategy on one page', 'Audience, promise, pillars and proof.', 16, [res(c7, 1, 'Strategy one-pager', 'template', '170 KB')]],
          ['Editorial calendar design', 'Cadence, formats and capacity planning.', 15],
        ],
      ],
      [
        'Production',
        [
          ['Research and outlining', 'Fast, credible research that avoids the generic middle.', 18],
          ['Writing for skimmers', 'Structure, subheads and the first 100 words.', 17],
          ['Repurposing engine', 'One long asset into ten distributable pieces.', 20, [res(c7, 2, 'Repurposing map', 'template', '180 KB')]],
        ],
      ],
      [
        'Distribution & Proof',
        [
          ['Distribution loops', 'Email, social, communities and partnerships working together.', 19],
          ['Content measurement', 'Leading indicators, assisted conversions and revenue attribution.', 17],
        ],
      ],
    ]),
    reviews: reviews(c7, [
      ['Lara M.', AVATARS[0], 5, '2026-04-10', 'The repurposing map doubled our output with the same team.'],
      ['Harsh D.', AVATARS[1], 4, '2026-03-22', 'Good structure. I wanted more B2B examples.'],
    ]),
  }),

  make({
    id: c8,
    title: 'Marketing Analytics with GA4',
    subtitle: 'Measure what matters and report with confidence',
    description:
      'Set up GA4 properly, build the reports your team actually needs, and connect marketing activity to business outcomes. Includes events and conversions, explorations, Looker Studio dashboards and a practical attribution model.',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
    category: 'analytics',
    tags: ['GA4', 'Looker Studio', 'Attribution'],
    instructor: INSTRUCTORS.dev,
    level: 'Intermediate',
    language: 'English',
    rating: 4.9,
    ratingCount: 640,
    studentCount: 5240,
    price: 2799,
    originalPrice: 6299,
    updatedAt: '2026-07-01',
    isNew: true,
    outcomes: [
      'Design a measurement plan before touching a tag',
      'Implement events and conversions correctly in GA4',
      'Build explorations that answer real questions',
      'Create a Looker Studio dashboard stakeholders read',
      'Explain attribution differences without losing trust',
    ],
    requirements: ['A website with GA4 access', 'Comfort with spreadsheets'],
    sections: buildSections(c8, [
      [
        'Measurement Foundations',
        [
          ['The measurement plan', 'Questions first, tags second.', 16, [res(c8, 1, 'Measurement plan template', 'template', '220 KB')]],
          ['GA4 data model', 'Events, parameters, users and sessions explained clearly.', 18],
          ['Implementation with Tag Manager', 'A clean setup you can maintain.', 22],
        ],
      ],
      [
        'Analysis',
        [
          ['Standard reports and where they fall short', 'Getting quick answers and knowing the limits.', 15],
          ['Explorations deep dive', 'Funnels, path and segment overlap for real diagnosis.', 21],
          ['Audiences and predictive metrics', 'Using GA4 audiences in ad platforms.', 17],
        ],
      ],
      [
        'Reporting',
        [
          ['Looker Studio dashboards', 'A dashboard template that answers the weekly questions.', 20, [res(c8, 2, 'Dashboard template', 'link')]],
          ['Attribution in practice', 'Model comparison, blended CAC and honest reporting.', 19],
        ],
      ],
    ]),
    reviews: reviews(c8, [
      ['Kunal B.', AVATARS[3], 5, '2026-06-25', 'Dev makes GA4 make sense. The measurement plan step changed how I work.'],
      ['Emily R.', AVATARS[4], 5, '2026-06-05', 'Our exec dashboard finally gets opened. Great course.'],
    ]),
  }),

  make({
    id: c9,
    title: 'AI Content Studio: Video, Image & Copy',
    subtitle: 'Produce a week of creative in an afternoon',
    description:
      'A production-focused companion to AI marketing. Generate images and short video, write scripts and ad copy, keep everything on-brand, and assemble a publishing pipeline that runs weekly without heroics.',
    image: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80',
    category: 'ai-marketing',
    tags: ['Generative AI', 'Creative', 'Production'],
    instructor: INSTRUCTORS.neha,
    level: 'Beginner',
    language: 'English',
    rating: 4.7,
    ratingCount: 410,
    studentCount: 3980,
    price: 2299,
    originalPrice: 5499,
    updatedAt: '2026-07-05',
    isNew: true,
    outcomes: [
      'Generate on-brand images for ads and social',
      'Script and assemble short-form video with AI assistance',
      'Write ad copy variations that pass brand review',
      'Build a weekly creative production pipeline',
    ],
    requirements: ['No design or video experience required'],
    sections: buildSections(c9, [
      [
        'Visual Generation',
        [
          ['Image prompting fundamentals', 'Subject, style, composition and lighting.', 17],
          ['On-brand image systems', 'Reference images, palettes and consistency tricks.', 18],
        ],
      ],
      [
        'Video & Copy',
        [
          ['Short-form video scripting', 'Hook, value, payoff in under 45 seconds.', 16],
          ['AI-assisted editing workflow', 'Captions, b-roll and voiceover.', 19],
          ['Ad copy at volume', 'Generate, filter and brief-check dozens of variants.', 15],
        ],
      ],
      [
        'Pipeline',
        [
          ['Weekly production pipeline', 'Roles, tools and a schedule that holds.', 18, [res(c9, 1, 'Production pipeline board', 'template', '200 KB')]],
        ],
      ],
    ]),
    reviews: reviews(c9, [
      ['Zara F.', AVATARS[2], 5, '2026-07-08', 'Our small team now ships daily creative. Unreal difference.'],
      ['Pranav I.', AVATARS[1], 4, '2026-06-28', 'Excellent practical course, tools move fast so check for updates.'],
    ]),
  }),

  make({
    id: c10,
    title: 'Brand Storytelling for Marketers',
    subtitle: 'Messaging that people remember and repeat',
    description:
      'Great performance marketing fails on weak messaging. Learn narrative structure, customer research, message testing and how to keep a brand story consistent across every channel and campaign.',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&q=80',
    category: 'digital-marketing',
    tags: ['Brand', 'Messaging', 'Copywriting'],
    instructor: INSTRUCTORS.sara,
    level: 'All Levels',
    language: 'English',
    rating: 4.6,
    ratingCount: 520,
    studentCount: 4610,
    price: 1699,
    originalPrice: 3999,
    updatedAt: '2026-03-27',
    outcomes: [
      'Build a brand narrative from customer research',
      'Write messaging hierarchies for every channel',
      'Test messages before spending on media',
      'Keep story consistent across a growing team',
    ],
    requirements: ['No prerequisites'],
    sections: buildSections(c10, [
      [
        'Finding the Story',
        [
          ['Customer research for messaging', 'Interviews and review mining for the exact words that convert.', 18],
          ['Narrative structures that work', 'Problem-agitate-solve, before-after-bridge and when to use each.', 16],
        ],
      ],
      [
        'Building the System',
        [
          ['Messaging hierarchy', 'One story, many surfaces.', 17, [res(c10, 1, 'Messaging hierarchy doc', 'template', '160 KB')]],
          ['Message testing', 'Cheap tests before expensive campaigns.', 15],
          ['Brand voice guidelines', 'Rules a team can follow without you.', 16],
        ],
      ],
    ]),
    reviews: reviews(c10, [
      ['Nisha W.', AVATARS[0], 5, '2026-03-19', 'Our ads improved before we changed a single targeting setting.'],
      ['Gaurav P.', AVATARS[3], 4, '2026-02-28', 'Short but dense. Message testing module is the highlight.'],
    ]),
  }),
];

export const courseById = (id?: string | null) =>
  SAMPLE_COURSES.find((c) => c.id === id);

export const allLessons = (course: Course): Lesson[] =>
  course.sections.flatMap((s) => s.lessons);

export const lessonCount = (course: Course) =>
  course.sections.reduce((n, s) => n + s.lessons.length, 0);
