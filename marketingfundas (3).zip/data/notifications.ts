import type { AppNotification } from '@/types';

const hoursAgo = (h: number) => new Date(Date.now() - h * 3600_000).toISOString();

export const SAMPLE_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'n1',
    type: 'new-course',
    title: 'New course: AI Content Studio',
    body: 'Produce a week of video, image and copy in an afternoon. Now live with launch pricing.',
    createdAt: hoursAgo(2),
    read: false,
    courseId: 'ai-content-studio',
  },
  {
    id: 'n2',
    type: 'learning-reminder',
    title: 'Keep your streak alive 🔥',
    body: 'Ten minutes today keeps your streak going. Continue where you left off.',
    createdAt: hoursAgo(9),
    read: false,
  },
  {
    id: 'n3',
    type: 'new-lesson',
    title: 'New lesson added',
    body: '"Performance Max, properly" was expanded with 2026 asset group guidance.',
    createdAt: hoursAgo(26),
    read: false,
    courseId: 'google-ads',
  },
  {
    id: 'n4',
    type: 'quiz-reminder',
    title: 'Final assessment waiting',
    body: 'You have finished the lessons in Digital Marketing Mastery. Pass the quiz to unlock your certificate.',
    createdAt: hoursAgo(50),
    read: true,
    courseId: 'dm-mastery',
  },
  {
    id: 'n5',
    type: 'course-update',
    title: 'Course updated',
    body: 'SEO That Ranks in 2026 now covers AI answer engines and entity optimisation.',
    createdAt: hoursAgo(74),
    read: true,
    courseId: 'seo-2026',
  },
  {
    id: 'n6',
    type: 'achievement',
    title: 'Milestone unlocked',
    body: 'You completed 10 lessons this month. That is a real habit forming.',
    createdAt: hoursAgo(120),
    read: true,
  },
];
