import '../global.css';

import { Stack, useRouter, useSegments } from 'expo-router';
import * as NativeSplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import '@/components/ui/animated';

import { AuthProvider, useAuth } from '@/context/AuthContext';
import { LearningProvider } from '@/context/LearningContext';
import { SettingsProvider, useSettings } from '@/context/SettingsContext';
import { useOnboarding } from '@/hooks/useOnboarding';
import { SplashScreen } from '@/screens/SplashScreen';

NativeSplashScreen.preventAutoHideAsync().catch(() => undefined);

export default function RootLayout() {
  useEffect(() => {
    NativeSplashScreen.hideAsync().catch(() => undefined);
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <SettingsProvider>
          <AuthProvider>
            <LearningProvider>
              <RootNavigator />
            </LearningProvider>
          </AuthProvider>
        </SettingsProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

/**
 * Decides where the learner lands: onboarding → auth → app, and keeps the
 * branded splash on screen until that decision can be made.
 */
function RootNavigator() {
  const router = useRouter();
  const segments = useSegments();
  const { user, initializing } = useAuth();
  const { ready: settingsReady, isDark } = useSettings();
  const { seen: onboarded, loading: onboardingLoading } = useOnboarding();

  // Keep the splash up briefly so the animation does not flash past.
  const [minimumElapsed, setMinimumElapsed] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setMinimumElapsed(true), 1600);
    return () => clearTimeout(timer);
  }, []);

  const booting = initializing || onboardingLoading || !settingsReady || !minimumElapsed;

  useEffect(() => {
    if (booting) return;

    const group = segments[0];
    const inAuthGroup = group === '(auth)';
    const onOnboarding = group === 'onboarding';

    if (!onboarded && !onOnboarding) {
      router.replace('/onboarding');
      return;
    }
    if (onboarded && !user && !inAuthGroup) {
      router.replace('/(auth)/login');
      return;
    }
    if (user && (inAuthGroup || onOnboarding)) {
      router.replace('/(tabs)');
    }
  }, [booting, onboarded, router, segments, user]);

  return (
    <>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      {booting ? (
        <SplashScreen />
      ) : (
        <Stack screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="onboarding" options={{ animation: 'fade' }} />
          <Stack.Screen name="(auth)" options={{ animation: 'fade' }} />
          <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
          <Stack.Screen name="learn/[courseId]" options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="quiz/[courseId]" options={{ animation: 'slide_from_bottom' }} />
        </Stack>
      )}
    </>
  );
}
