import { ProgressScreen } from '@/screens/main/ProgressScreen';

export default ProgressScreen;
