import { CourseDetailsScreen } from '@/screens/course/CourseDetailsScreen';

export default CourseDetailsScreen;
