import { useRouter } from 'expo-router';
import React from 'react';

import { Screen } from '@/components/ui/Screen';
import { EmptyState } from '@/components/ui/EmptyState';

export default function NotFound() {
  const router = useRouter();
  return (
    <Screen>
      <EmptyState
        icon="compass-outline"
        title="Page not found"
        message="That screen does not exist. Let's get you back to your learning."
        actionLabel="Go home"
        onAction={() => router.replace('/(tabs)')}
        className="flex-1 justify-center"
      />
    </Screen>
  );
}
