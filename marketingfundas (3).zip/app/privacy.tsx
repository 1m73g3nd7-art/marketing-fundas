import { PrivacyScreen } from '@/screens/profile/PrivacyScreen';

export default PrivacyScreen;
