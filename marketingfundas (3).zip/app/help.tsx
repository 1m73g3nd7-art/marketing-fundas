import { HelpScreen } from '@/screens/profile/HelpScreen';

export default HelpScreen;
