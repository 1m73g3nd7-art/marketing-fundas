import { Tabs } from 'expo-router';
import React from 'react';
import { Platform, Text, View } from 'react-native';

import { Icon, type IconName } from '@/components/ui/Icon';
import { palette } from '@/constants/theme';
import { useLearning } from '@/context/LearningContext';
import { useSettings } from '@/context/SettingsContext';

interface TabConfig {
  name: string;
  title: string;
  icon: IconName;
  iconActive: IconName;
}

const TABS: TabConfig[] = [
  { name: 'index', title: 'Home', icon: 'home-outline', iconActive: 'home' },
  { name: 'courses', title: 'Courses', icon: 'compass-outline', iconActive: 'compass' },
  { name: 'learning', title: 'My Learning', icon: 'library-outline', iconActive: 'library' },
  { name: 'profile', title: 'Profile', icon: 'person-outline', iconActive: 'person' },
];

export default function TabsLayout() {
  const { isDark } = useSettings();
  const { enrolledCourses } = useLearning();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: isDark ? palette.brand[300] : palette.brand[600],
        tabBarInactiveTintColor: isDark ? palette.ink[500] : palette.ink[400],
        tabBarStyle: {
          backgroundColor: isDark ? palette.ink[900] : palette.white,
          borderTopColor: isDark ? palette.ink[800] : palette.ink[100],
          borderTopWidth: 1,
          height: Platform.OS === 'ios' ? 86 : 72,
          paddingTop: 8,
          paddingBottom: Platform.OS === 'ios' ? 28 : 12,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
      }}
    >
      {TABS.map((tab) => (
        <Tabs.Screen
          key={tab.name}
          name={tab.name}
          options={{
            title: tab.title,
            tabBarIcon: ({ color, focused }) => (
              <View className="items-center">
                <Icon name={focused ? tab.iconActive : tab.icon} size={22} color={color} />
                {tab.name === 'learning' && enrolledCourses.length > 0 ? (
                  <View className="absolute -right-3 -top-1 h-4 min-w-4 items-center justify-center rounded-full bg-brand-500 px-1">
                    <Text className="text-[9px] font-extrabold text-white">
                      {enrolledCourses.length}
                    </Text>
                  </View>
                ) : null}
              </View>
            ),
          }}
        />
      ))}
    </Tabs>
  );
}
