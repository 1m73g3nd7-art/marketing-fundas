import { MyLearningScreen } from '@/screens/main/MyLearningScreen';

export default MyLearningScreen;
