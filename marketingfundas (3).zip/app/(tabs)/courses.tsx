import { CoursesScreen } from '@/screens/main/CoursesScreen';

export default CoursesScreen;
