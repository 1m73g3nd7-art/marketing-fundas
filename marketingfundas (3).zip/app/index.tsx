import { Redirect } from 'expo-router';

import { useAuth } from '@/context/AuthContext';
import { useOnboarding } from '@/hooks/useOnboarding';
import { SplashScreen } from '@/screens/SplashScreen';

/** Entry route: sends the learner to onboarding, auth or the dashboard. */
export default function Index() {
  const { user, initializing } = useAuth();
  const { seen, loading } = useOnboarding();

  if (initializing || loading) return <SplashScreen />;
  if (!seen) return <Redirect href="/onboarding" />;
  if (!user) return <Redirect href="/(auth)/login" />;
  return <Redirect href="/(tabs)" />;
}
