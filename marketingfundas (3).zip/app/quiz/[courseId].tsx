import { QuizScreen } from '@/screens/course/QuizScreen';

export default QuizScreen;
