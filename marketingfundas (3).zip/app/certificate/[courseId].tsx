import { CertificateScreen } from '@/screens/course/CertificateScreen';

export default CertificateScreen;
