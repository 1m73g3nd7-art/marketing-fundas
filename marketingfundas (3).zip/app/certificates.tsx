import { CertificatesScreen } from '@/screens/profile/CertificatesScreen';

export default CertificatesScreen;
