import { LearningScreen } from '@/screens/course/LearningScreen';

export default LearningScreen;
