/** Small, dependency-free id generator good enough for local records. */
export const createId = (prefix = 'id') =>
  `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

/** Deterministic, human-readable certificate id. */
export const certificateId = (uid: string, courseId: string) => {
  const seed = `${uid}:${courseId}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const code = Math.abs(hash).toString(36).toUpperCase().padStart(6, '0').slice(0, 6);
  const year = new Date().getFullYear();
  return `MF-${year}-${code}`;
};
