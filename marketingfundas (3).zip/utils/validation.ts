export const isEmail = (value: string) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim());

export const isPhone = (value: string) =>
  /^[+]?[\d][\d\s-]{7,16}$/.test(value.trim());

export interface PasswordStrength {
  score: 0 | 1 | 2 | 3 | 4;
  label: string;
  color: string;
}

export const passwordStrength = (value: string): PasswordStrength => {
  let score = 0;
  if (value.length >= 8) score++;
  if (/[A-Z]/.test(value)) score++;
  if (/\d/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;
  const map: PasswordStrength[] = [
    { score: 0, label: 'Too short', color: '#EF4444' },
    { score: 1, label: 'Weak', color: '#EF4444' },
    { score: 2, label: 'Fair', color: '#F59E0B' },
    { score: 3, label: 'Good', color: '#2DD4C4' },
    { score: 4, label: 'Strong', color: '#22C55E' },
  ];
  return map[Math.min(score, 4)];
};

export type Errors<T> = Partial<Record<keyof T, string>>;

export const validateLogin = (values: { email: string; password: string }) => {
  const errors: Errors<typeof values> = {};
  if (!values.email.trim()) errors.email = 'Email is required';
  else if (!isEmail(values.email)) errors.email = 'Enter a valid email address';
  if (!values.password) errors.password = 'Password is required';
  else if (values.password.length < 6) errors.password = 'Password must be at least 6 characters';
  return errors;
};

export const validateSignup = (values: {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
}) => {
  const errors: Errors<typeof values> = {};
  if (!values.fullName.trim()) errors.fullName = 'Full name is required';
  else if (values.fullName.trim().length < 3) errors.fullName = 'Please enter your full name';
  if (!values.email.trim()) errors.email = 'Email is required';
  else if (!isEmail(values.email)) errors.email = 'Enter a valid email address';
  if (!values.phone.trim()) errors.phone = 'Phone number is required';
  else if (!isPhone(values.phone)) errors.phone = 'Enter a valid phone number';
  if (!values.password) errors.password = 'Password is required';
  else if (values.password.length < 8) errors.password = 'Use at least 8 characters';
  if (!values.confirmPassword) errors.confirmPassword = 'Please confirm your password';
  else if (values.confirmPassword !== values.password) errors.confirmPassword = 'Passwords do not match';
  return errors;
};

export const hasErrors = (errors: Record<string, string | undefined>) =>
  Object.values(errors).some(Boolean);
