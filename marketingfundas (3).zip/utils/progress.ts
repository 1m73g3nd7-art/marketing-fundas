import type { Course, Enrollment, Lesson } from '@/types';

export const flattenLessons = (course: Course): Lesson[] =>
  course.sections.flatMap((section) => section.lessons);

export const lessonTotal = (course: Course) =>
  course.sections.reduce((total, section) => total + section.lessons.length, 0);

export const completedLessonIds = (enrollment?: Enrollment) =>
  Object.values(enrollment?.lessons ?? {})
    .filter((lesson) => lesson.completed)
    .map((lesson) => lesson.lessonId);

export const completedCount = (enrollment?: Enrollment) => completedLessonIds(enrollment).length;

export const progressPercent = (course: Course, enrollment?: Enrollment) => {
  const total = lessonTotal(course);
  if (!total || !enrollment) return 0;
  return Math.round((completedCount(enrollment) / total) * 100);
};

export const isCourseComplete = (course: Course, enrollment?: Enrollment) =>
  lessonTotal(course) > 0 && completedCount(enrollment) >= lessonTotal(course);

/** The lesson the learner should land on when they tap "Continue". */
export const nextLessonFor = (course: Course, enrollment?: Enrollment): Lesson | undefined => {
  const lessons = flattenLessons(course);
  if (!lessons.length) return undefined;
  if (!enrollment) return lessons[0];

  if (enrollment.lastLessonId) {
    const last = lessons.find((lesson) => lesson.id === enrollment.lastLessonId);
    const lastDone = last ? enrollment.lessons[last.id]?.completed : false;
    if (last && !lastDone) return last;
  }
  const firstIncomplete = lessons.find((lesson) => !enrollment.lessons[lesson.id]?.completed);
  return firstIncomplete ?? lessons[lessons.length - 1];
};

export const minutesCompleted = (course: Course, enrollment?: Enrollment) => {
  if (!enrollment) return 0;
  return flattenLessons(course)
    .filter((lesson) => enrollment.lessons[lesson.id]?.completed)
    .reduce((total, lesson) => total + lesson.durationMinutes, 0);
};

/** Consecutive days (ending today or yesterday) with recorded study time. */
export const streakFromActivity = (activity: Record<string, number>) => {
  const days = Object.keys(activity)
    .filter((day) => (activity[day] ?? 0) > 0)
    .sort()
    .reverse();
  if (!days.length) return 0;

  const dayKey = (offset: number) => {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    return date.toISOString().slice(0, 10);
  };

  let offset = days[0] === dayKey(0) ? 0 : days[0] === dayKey(1) ? 1 : -1;
  if (offset === -1) return 0;

  let streak = 0;
  while (days.includes(dayKey(offset))) {
    streak += 1;
    offset += 1;
  }
  return streak;
};

/** Minutes per day for the last seven days, oldest first. */
export const weeklyMinutes = (activity: Record<string, number>) => {
  const result: number[] = [];
  for (let offset = 6; offset >= 0; offset--) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    result.push(activity[date.toISOString().slice(0, 10)] ?? 0);
  }
  return result;
};
