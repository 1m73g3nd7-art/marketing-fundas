import type { Certificate } from '@/types';
import { formatDate } from './format';

/** Print-ready certificate markup used for PDF export and sharing. */
export const certificateHtml = (certificate: Certificate) => `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      @page { size: A4 landscape; margin: 0; }
      * { box-sizing: border-box; }
      body {
        margin: 0;
        font-family: Georgia, 'Times New Roman', serif;
        background: #0A0C13;
        color: #12151F;
      }
      .sheet {
        width: 1123px;
        height: 794px;
        padding: 28px;
        background: linear-gradient(135deg, #1C1746 0%, #412FBA 45%, #0B948B 100%);
      }
      .inner {
        position: relative;
        height: 100%;
        background: #FFFFFF;
        border-radius: 18px;
        padding: 56px 72px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .inner::after {
        content: '';
        position: absolute;
        right: -120px;
        bottom: -160px;
        width: 420px;
        height: 420px;
        border-radius: 50%;
        background: rgba(79, 59, 222, 0.07);
      }
      .brand { display: flex; align-items: center; gap: 14px; }
      .mark {
        width: 46px; height: 46px; border-radius: 14px;
        background: linear-gradient(135deg, #4F3BDE, #14B8AA);
        color: #fff; font-family: Helvetica, Arial, sans-serif; font-weight: 700;
        display: flex; align-items: center; justify-content: center; font-size: 20px;
      }
      .brand-name {
        font-family: Helvetica, Arial, sans-serif;
        font-weight: 700; font-size: 20px; letter-spacing: 0.02em; color: #1C1746;
      }
      .brand-sub {
        font-family: Helvetica, Arial, sans-serif;
        font-size: 11px; letter-spacing: 0.16em; text-transform: uppercase; color: #646D89;
      }
      .title {
        margin-top: 44px;
        font-size: 15px; letter-spacing: 0.42em; text-transform: uppercase;
        color: #4F3BDE; font-family: Helvetica, Arial, sans-serif; font-weight: 700;
      }
      .headline { margin-top: 10px; font-size: 46px; color: #12151F; }
      .presented { margin-top: 34px; font-size: 15px; color: #646D89; font-family: Helvetica, Arial, sans-serif; }
      .student {
        margin-top: 8px; font-size: 54px; color: #1C1746; font-weight: 400;
        border-bottom: 2px solid rgba(28, 23, 70, 0.12); display: inline-block; padding-bottom: 10px;
      }
      .course { margin-top: 26px; font-size: 17px; color: #3A4258; line-height: 1.6; max-width: 760px; }
      .course strong { color: #12151F; }
      .footer {
        margin-top: auto; display: flex; justify-content: space-between; align-items: flex-end;
        font-family: Helvetica, Arial, sans-serif;
      }
      .field-label { font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase; color: #8992AC; }
      .field-value { font-size: 15px; color: #12151F; margin-top: 6px; font-weight: 600; }
      .sig { text-align: right; }
      .sig-line { width: 210px; border-top: 1px solid #B9C0D4; margin-bottom: 8px; }
      .seal {
        position: absolute; right: 72px; top: 132px;
        width: 118px; height: 118px; border-radius: 50%;
        border: 3px solid rgba(245, 158, 11, 0.5);
        display: flex; align-items: center; justify-content: center; text-align: center;
        font-family: Helvetica, Arial, sans-serif; font-size: 10px; letter-spacing: 0.12em;
        text-transform: uppercase; color: #D97706; line-height: 1.5;
      }
    </style>
  </head>
  <body>
    <div class="sheet">
      <div class="inner">
        <div class="brand">
          <div class="mark">MF</div>
          <div>
            <div class="brand-name">Marketing Fundas</div>
            <div class="brand-sub">Digital Marketing + AI</div>
          </div>
        </div>

        <div class="seal">Verified<br />Completion</div>

        <div class="title">Certificate of Completion</div>
        <div class="headline">This certifies that</div>

        <div class="presented">Awarded to</div>
        <div class="student">${escapeHtml(certificate.studentName)}</div>

        <div class="course">
          has successfully completed all lessons and passed the final assessment for
          <strong>${escapeHtml(certificate.courseTitle)}</strong>
          with a score of <strong>${certificate.score}%</strong>.
        </div>

        <div class="footer">
          <div>
            <div class="field-label">Certificate ID</div>
            <div class="field-value">${escapeHtml(certificate.id)}</div>
          </div>
          <div>
            <div class="field-label">Date of completion</div>
            <div class="field-value">${formatDate(certificate.issuedAt)}</div>
          </div>
          <div class="sig">
            <div class="sig-line"></div>
            <div class="field-value">${escapeHtml(certificate.instructorName)}</div>
            <div class="field-label" style="margin-top:4px">Course Instructor</div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>`;

const escapeHtml = (value: string) =>
  value.replace(/[&<>"']/g, (char) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char] ?? char,
  );
