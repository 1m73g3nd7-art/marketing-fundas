/**
 * Seeds a Firebase project with the bundled sample catalogue so an admin
 * console has real documents to manage.
 *
 * Usage:
 *   1. Create a service account key in the Firebase console and save it.
 *   2. GOOGLE_APPLICATION_CREDENTIALS=./service-account.json \
 *      FIREBASE_PROJECT_ID=your-project-id \
 *      node scripts/seed-firestore.mjs
 *
 * Requires firebase-admin:  npm i -D firebase-admin
 */
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const here = dirname(fileURLToPath(import.meta.url));

let admin;
try {
  admin = require('firebase-admin');
} catch {
  console.error('firebase-admin is not installed. Run: npm i -D firebase-admin');
  process.exit(1);
}

const projectId = process.env.FIREBASE_PROJECT_ID;
if (!projectId) {
  console.error('Set FIREBASE_PROJECT_ID before running this script.');
  process.exit(1);
}

admin.initializeApp({ credential: admin.credential.applicationDefault(), projectId });
const db = admin.firestore();

/**
 * The sample data lives in TypeScript, so it is read through the compiled
 * JSON snapshot produced by `npm run export:sample-data`. Falling back to a
 * direct require keeps the script usable when that snapshot is absent.
 */
const dataPath = resolve(here, 'sample-data.json');
let payload;
try {
  payload = JSON.parse(readFileSync(dataPath, 'utf8'));
} catch {
  console.error(
    `Could not read ${dataPath}. Run "npm run export:sample-data" first to generate it.`,
  );
  process.exit(1);
}

const writeAll = async (collection, documents) => {
  const batch = db.batch();
  documents.forEach((document) => {
    batch.set(db.collection(collection).doc(document.id), document, { merge: true });
  });
  await batch.commit();
  console.log(`seeded ${documents.length} → ${collection}`);
};

await writeAll('courses', payload.courses);
await writeAll('quizzes', payload.quizzes);
await writeAll('notifications', payload.notifications);
console.log('Done.');
process.exit(0);
