/**
 * Writes the bundled sample catalogue to scripts/sample-data.json so
 * seed-firestore.mjs (plain Node, no bundler) can upload it.
 *
 * Usage: npm run export:sample-data
 *
 * The data modules are plain TypeScript with type-only cross-imports, so the
 * TypeScript compiler that already ships with the project is enough — no
 * extra tooling required.
 */
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const require = createRequire(import.meta.url);
const ts = require('typescript');

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const tmp = resolve(here, '.tmp-data');

const MODULES = ['videos', 'instructors', 'courses', 'quizzes', 'notifications'];

rmSync(tmp, { recursive: true, force: true });
mkdirSync(tmp, { recursive: true });

for (const name of MODULES) {
  const source = readFileSync(resolve(root, 'data', `${name}.ts`), 'utf8');
  const { outputText } = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 },
  });
  // Relative imports need explicit extensions once they are plain ESM.
  writeFileSync(
    resolve(tmp, `${name}.mjs`),
    outputText.replace(/from '\.\/([a-z-]+)'/g, "from './$1.mjs'"),
  );
}

const { SAMPLE_COURSES } = await import(pathToFileURL(resolve(tmp, 'courses.mjs')).href);
const { SAMPLE_QUIZZES } = await import(pathToFileURL(resolve(tmp, 'quizzes.mjs')).href);
const { SAMPLE_NOTIFICATIONS } = await import(pathToFileURL(resolve(tmp, 'notifications.mjs')).href);

writeFileSync(
  resolve(here, 'sample-data.json'),
  JSON.stringify(
    { courses: SAMPLE_COURSES, quizzes: SAMPLE_QUIZZES, notifications: SAMPLE_NOTIFICATIONS },
    null,
    2,
  ),
);

rmSync(tmp, { recursive: true, force: true });
console.log(
  `Wrote scripts/sample-data.json (${SAMPLE_COURSES.length} courses, ${SAMPLE_QUIZZES.length} quizzes, ${SAMPLE_NOTIFICATIONS.length} notifications)`,
);
