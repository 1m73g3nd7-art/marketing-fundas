import { useSettings } from '@/context/SettingsContext';
import { themeColors } from '@/constants/theme';

/** Raw colour values for the places Tailwind classes cannot reach. */
export function useThemeColors() {
  const { isDark } = useSettings();
  return { ...themeColors[isDark ? 'dark' : 'light'], isDark };
}
