import * as Google from 'expo-auth-session/providers/google';
import * as WebBrowser from 'expo-web-browser';
import { useCallback, useEffect, useRef } from 'react';

import { useAuth } from '@/context/AuthContext';
import { googleClientIds, isGoogleConfigured } from '@/services/firebase';

WebBrowser.maybeCompleteAuthSession();

/**
 * Google Sign-In. When OAuth client ids are present in the environment this
 * runs the real expo-auth-session flow and exchanges the id token with
 * Firebase; otherwise it signs the learner into the demo account so the
 * button is never a dead end.
 */
export function useGoogleAuth(onError?: (message: string) => void) {
  const { signInWithGoogle } = useAuth();
  const handled = useRef(false);

  const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
    clientId: googleClientIds.expo ?? googleClientIds.web ?? 'unconfigured',
    iosClientId: googleClientIds.ios,
    androidClientId: googleClientIds.android,
    webClientId: googleClientIds.web,
  });

  useEffect(() => {
    if (!response || handled.current) return;
    if (response.type === 'success') {
      handled.current = true;
      const idToken = response.params?.id_token;
      signInWithGoogle(idToken).catch((error: Error) => {
        handled.current = false;
        onError?.(error.message);
      });
    } else if (response.type === 'error') {
      onError?.('Google sign-in was cancelled or failed. Please try again.');
    }
  }, [response, signInWithGoogle, onError]);

  const signIn = useCallback(async () => {
    if (!isGoogleConfigured) {
      // Demo mode: no OAuth client configured, so sign in the sample learner.
      await signInWithGoogle(undefined);
      return;
    }
    await promptAsync();
  }, [promptAsync, signInWithGoogle]);

  return { signIn, disabled: isGoogleConfigured && !request, configured: isGoogleConfigured };
}
