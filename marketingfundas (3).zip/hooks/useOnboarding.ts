import { useSettings } from '@/context/SettingsContext';

/**
 * Whether the learner has already seen the onboarding carousel. Backed by the
 * settings context so every consumer shares one source of truth — the root
 * navigator and the carousel itself must agree, or they fight over the route.
 */
export function useOnboarding() {
  const { onboarded, ready, completeOnboarding, resetOnboarding } = useSettings();
  return {
    seen: onboarded,
    loading: !ready,
    complete: completeOnboarding,
    reset: resetOnboarding,
  };
}
