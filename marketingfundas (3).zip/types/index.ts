/**
 * Shared domain types for Marketing Fundas.
 * These mirror the Firestore collection shapes documented in services/firebase.ts
 * so the same models work with either the remote or the local data source.
 */

export type CategoryId =
  | 'digital-marketing'
  | 'ai-marketing'
  | 'seo'
  | 'social-media'
  | 'google-ads'
  | 'meta-ads'
  | 'content-marketing'
  | 'analytics';

export type CourseLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';

export interface Instructor {
  id: string;
  name: string;
  title: string;
  avatar: string;
  bio: string;
  rating: number;
  students: number;
  courses: number;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  durationMinutes: number;
  videoUrl: string;
  thumbnail?: string;
  isPreview?: boolean;
  resources?: LessonResource[];
}

export interface LessonResource {
  id: string;
  title: string;
  type: 'pdf' | 'link' | 'template' | 'checklist';
  url: string;
  size?: string;
}

export interface Section {
  id: string;
  title: string;
  lessons: Lesson[];
}

export interface Review {
  id: string;
  userName: string;
  avatar: string;
  rating: number;
  date: string;
  comment: string;
}

export interface QuizOption {
  id: string;
  text: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: QuizOption[];
  correctOptionId: string;
  explanation: string;
}

export interface Quiz {
  id: string;
  courseId: string;
  title: string;
  passingScore: number;
  questions: QuizQuestion[];
}

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  category: CategoryId;
  tags: string[];
  instructor: Instructor;
  level: CourseLevel;
  language: string;
  rating: number;
  ratingCount: number;
  studentCount: number;
  price: number;
  originalPrice?: number;
  durationMinutes: number;
  updatedAt: string;
  outcomes: string[];
  requirements: string[];
  sections: Section[];
  reviews: Review[];
  featured?: boolean;
  isNew?: boolean;
  bestseller?: boolean;
}

export interface UserProfile {
  uid: string;
  fullName: string;
  email: string;
  phone?: string;
  photoURL?: string;
  headline?: string;
  createdAt: string;
  provider: 'password' | 'google' | 'demo';
}

export interface LessonProgress {
  lessonId: string;
  completed: boolean;
  positionSeconds: number;
  completedAt?: string;
}

export interface Enrollment {
  courseId: string;
  enrolledAt: string;
  lastLessonId?: string;
  lastOpenedAt?: string;
  lessons: Record<string, LessonProgress>;
  completedAt?: string;
}

export interface QuizAttempt {
  id: string;
  courseId: string;
  quizId: string;
  score: number;
  total: number;
  percentage: number;
  passed: boolean;
  answers: Record<string, string>;
  takenAt: string;
}

export interface Certificate {
  id: string;
  courseId: string;
  courseTitle: string;
  studentName: string;
  instructorName: string;
  issuedAt: string;
  score: number;
}

export type NotificationType =
  | 'new-course'
  | 'new-lesson'
  | 'course-update'
  | 'quiz-reminder'
  | 'learning-reminder'
  | 'achievement';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  createdAt: string;
  read: boolean;
  courseId?: string;
}

export interface LearningStats {
  totalCourses: number;
  completedCourses: number;
  inProgressCourses: number;
  totalLessons: number;
  completedLessons: number;
  overallPercent: number;
  minutesLearned: number;
  streakDays: number;
  weeklyMinutes: number[];
  certificates: number;
}

export interface AppSettings {
  themeMode: 'light' | 'dark' | 'system';
  pushEnabled: boolean;
  emailEnabled: boolean;
  learningReminders: boolean;
  quizReminders: boolean;
  autoplay: boolean;
  downloadOverWifiOnly: boolean;
  profilePublic: boolean;
}
