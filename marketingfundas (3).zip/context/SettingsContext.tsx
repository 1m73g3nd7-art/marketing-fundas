import { colorScheme as nwColorScheme } from 'nativewind';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { useColorScheme as useSystemColorScheme } from 'react-native';

import { STORAGE_KEYS } from '@/constants/config';
import { DEFAULT_SETTINGS, settingsService } from '@/services/settings.service';
import { storage } from '@/services/storage';
import type { AppSettings } from '@/types';

interface SettingsContextValue {
  settings: AppSettings;
  ready: boolean;
  /** Whether the learner has finished the onboarding carousel. */
  onboarded: boolean;
  completeOnboarding: () => Promise<void>;
  resetOnboarding: () => Promise<void>;
  scheme: 'light' | 'dark';
  isDark: boolean;
  update: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  setThemeMode: (mode: AppSettings['themeMode']) => void;
  toggleDarkMode: () => void;
}

const SettingsContext = createContext<SettingsContextValue | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [onboarded, setOnboarded] = useState(false);
  const [ready, setReady] = useState(false);
  const systemScheme = useSystemColorScheme();

  useEffect(() => {
    Promise.all([settingsService.load(), storage.get<boolean>(STORAGE_KEYS.onboarded, false)])
      .then(([stored, seen]) => {
        setSettings(stored);
        setOnboarded(seen);
      })
      .catch(() => undefined)
      .finally(() => setReady(true));
  }, []);

  const completeOnboarding = useCallback(async () => {
    setOnboarded(true);
    await storage.set(STORAGE_KEYS.onboarded, true);
  }, []);

  const resetOnboarding = useCallback(async () => {
    setOnboarded(false);
    await storage.set(STORAGE_KEYS.onboarded, false);
  }, []);

  const scheme: 'light' | 'dark' =
    settings.themeMode === 'system'
      ? ((systemScheme ?? 'light') as 'light' | 'dark')
      : settings.themeMode;

  // Keep NativeWind's `dark:` variant in sync. The class strategy needs a
  // resolved value, so 'system' is resolved here rather than passed through.
  useEffect(() => {
    if (!ready) return;
    nwColorScheme.set(scheme);
  }, [ready, scheme]);

  const update = useCallback(
    <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
      setSettings((prev) => {
        const next = { ...prev, [key]: value };
        void settingsService.save(next);
        return next;
      });
    },
    [],
  );

  const setThemeMode = useCallback(
    (mode: AppSettings['themeMode']) => update('themeMode', mode),
    [update],
  );

  const toggleDarkMode = useCallback(() => {
    setThemeMode(scheme === 'dark' ? 'light' : 'dark');
  }, [scheme, setThemeMode]);

  const value = useMemo<SettingsContextValue>(
    () => ({
      settings,
      ready,
      onboarded,
      completeOnboarding,
      resetOnboarding,
      scheme,
      isDark: scheme === 'dark',
      update,
      setThemeMode,
      toggleDarkMode,
    }),
    [
      settings,
      ready,
      onboarded,
      completeOnboarding,
      resetOnboarding,
      scheme,
      update,
      setThemeMode,
      toggleDarkMode,
    ],
  );

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) throw new Error('useSettings must be used inside a SettingsProvider');
  return context;
}
