import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

import { QUIZ_PASSING_SCORE } from '@/constants/config';
import { certificateService } from '@/services/certificate.service';
import { coursesService } from '@/services/courses.service';
import { learningService, type ActivityLog, type NotesMap } from '@/services/learning.service';
import { notificationsService } from '@/services/notifications.service';
import type {
  AppNotification,
  Certificate,
  Course,
  Enrollment,
  LearningStats,
  Quiz,
  QuizAttempt,
} from '@/types';
import { certificateId, createId } from '@/utils/id';
import {
  completedCount,
  isCourseComplete,
  lessonTotal,
  minutesCompleted,
  progressPercent,
  streakFromActivity,
  weeklyMinutes,
} from '@/utils/progress';
import { useAuth } from './AuthContext';

export interface EnrolledCourse {
  course: Course;
  enrollment: Enrollment;
  percent: number;
  completedLessons: number;
  totalLessons: number;
  completed: boolean;
}

interface LearningContextValue {
  loading: boolean;
  courses: Course[];
  quizzes: Quiz[];
  enrollments: Record<string, Enrollment>;
  attempts: QuizAttempt[];
  certificates: Certificate[];
  notifications: AppNotification[];
  notes: NotesMap;
  activity: ActivityLog;
  wishlist: string[];
  unreadCount: number;
  enrolledCourses: EnrolledCourse[];
  stats: LearningStats;
  getCourse: (courseId?: string | null) => Course | undefined;
  getQuiz: (courseId: string) => Quiz | undefined;
  getEnrollment: (courseId: string) => Enrollment | undefined;
  isEnrolled: (courseId: string) => boolean;
  courseProgress: (courseId: string) => number;
  bestAttempt: (courseId: string) => QuizAttempt | undefined;
  certificateFor: (courseId: string) => Certificate | undefined;
  enroll: (courseId: string) => Promise<void>;
  unenroll: (courseId: string) => Promise<void>;
  setLastLesson: (courseId: string, lessonId: string) => Promise<void>;
  setLessonComplete: (courseId: string, lessonId: string, completed: boolean) => Promise<void>;
  saveLessonPosition: (courseId: string, lessonId: string, seconds: number) => Promise<void>;
  saveNote: (lessonId: string, text: string) => Promise<void>;
  submitQuiz: (courseId: string, answers: Record<string, string>) => Promise<QuizAttempt>;
  issueCertificate: (courseId: string) => Promise<Certificate | undefined>;
  shareCertificate: (certificate: Certificate) => Promise<void>;
  downloadCertificate: (certificate: Certificate) => Promise<string>;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  toggleWishlist: (courseId: string) => Promise<void>;
  refresh: () => Promise<void>;
}

const emptyStats: LearningStats = {
  totalCourses: 0,
  completedCourses: 0,
  inProgressCourses: 0,
  totalLessons: 0,
  completedLessons: 0,
  overallPercent: 0,
  minutesLearned: 0,
  streakDays: 0,
  weeklyMinutes: [0, 0, 0, 0, 0, 0, 0],
  certificates: 0,
};

const LearningContext = createContext<LearningContextValue | undefined>(undefined);

export function LearningProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const uid = user?.uid;

  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState<Course[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [enrollments, setEnrollments] = useState<Record<string, Enrollment>>({});
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [notes, setNotes] = useState<NotesMap>({});
  const [activity, setActivity] = useState<ActivityLog>({});
  const [wishlist, setWishlist] = useState<string[]>([]);

  /* ------------------------------ loading ----------------------------- */

  const loadCatalogue = useCallback(async () => {
    const [catalogue, quizList] = await Promise.all([
      coursesService.listCourses(),
      coursesService.listQuizzes(),
    ]);
    setCourses(catalogue);
    setQuizzes(quizList);
  }, []);

  const loadUserData = useCallback(async (userId: string) => {
    const [enrollmentMap, attemptList, certificateList, notificationList, noteMap, activityLog, wish] =
      await Promise.all([
        learningService.listEnrollments(userId),
        learningService.listQuizAttempts(userId),
        learningService.listCertificates(userId),
        notificationsService.list(userId),
        learningService.listNotes(userId),
        learningService.getActivity(userId),
        learningService.getWishlist(userId),
      ]);
    setEnrollments(enrollmentMap);
    setAttempts(attemptList);
    setCertificates(certificateList);
    setNotifications(notificationList);
    setNotes(noteMap);
    setActivity(activityLog);
    setWishlist(wish);
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      await loadCatalogue();
      if (uid) await loadUserData(uid);
    } finally {
      setLoading(false);
    }
  }, [loadCatalogue, loadUserData, uid]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      await loadCatalogue();
      if (uid) {
        await loadUserData(uid);
      } else {
        setEnrollments({});
        setAttempts([]);
        setCertificates([]);
        setNotifications([]);
        setNotes({});
        setActivity({});
        setWishlist([]);
      }
    })()
      .catch(() => undefined)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [loadCatalogue, loadUserData, uid]);

  /* ----------------------------- selectors ---------------------------- */

  const getCourse = useCallback(
    (courseId?: string | null) => courses.find((course) => course.id === courseId),
    [courses],
  );

  const getQuiz = useCallback(
    (courseId: string) => quizzes.find((quiz) => quiz.courseId === courseId),
    [quizzes],
  );

  const getEnrollment = useCallback((courseId: string) => enrollments[courseId], [enrollments]);

  const isEnrolled = useCallback((courseId: string) => Boolean(enrollments[courseId]), [enrollments]);

  const courseProgress = useCallback(
    (courseId: string) => {
      const course = getCourse(courseId);
      if (!course) return 0;
      return progressPercent(course, enrollments[courseId]);
    },
    [enrollments, getCourse],
  );

  const bestAttempt = useCallback(
    (courseId: string) =>
      attempts
        .filter((attempt) => attempt.courseId === courseId)
        .sort((a, b) => b.percentage - a.percentage)[0],
    [attempts],
  );

  const certificateFor = useCallback(
    (courseId: string) => certificates.find((certificate) => certificate.courseId === courseId),
    [certificates],
  );

  const enrolledCourses = useMemo<EnrolledCourse[]>(
    () =>
      Object.values(enrollments)
        .map((enrollment) => {
          const course = courses.find((item) => item.id === enrollment.courseId);
          if (!course) return null;
          return {
            course,
            enrollment,
            percent: progressPercent(course, enrollment),
            completedLessons: completedCount(enrollment),
            totalLessons: lessonTotal(course),
            completed: isCourseComplete(course, enrollment),
          };
        })
        .filter((item): item is EnrolledCourse => item !== null)
        .sort((a, b) =>
          (b.enrollment.lastOpenedAt ?? b.enrollment.enrolledAt).localeCompare(
            a.enrollment.lastOpenedAt ?? a.enrollment.enrolledAt,
          ),
        ),
    [courses, enrollments],
  );

  const stats = useMemo<LearningStats>(() => {
    if (!enrolledCourses.length) {
      return { ...emptyStats, streakDays: streakFromActivity(activity), weeklyMinutes: weeklyMinutes(activity), certificates: certificates.length };
    }
    const totalLessons = enrolledCourses.reduce((sum, item) => sum + item.totalLessons, 0);
    const completedLessons = enrolledCourses.reduce((sum, item) => sum + item.completedLessons, 0);
    const minutesLearned = enrolledCourses.reduce(
      (sum, item) => sum + minutesCompleted(item.course, item.enrollment),
      0,
    );
    return {
      totalCourses: enrolledCourses.length,
      completedCourses: enrolledCourses.filter((item) => item.completed).length,
      inProgressCourses: enrolledCourses.filter((item) => !item.completed).length,
      totalLessons,
      completedLessons,
      overallPercent: totalLessons ? Math.round((completedLessons / totalLessons) * 100) : 0,
      minutesLearned,
      streakDays: streakFromActivity(activity),
      weeklyMinutes: weeklyMinutes(activity),
      certificates: certificates.length,
    };
  }, [activity, certificates.length, enrolledCourses]);

  const unreadCount = useMemo(
    () => notifications.filter((notification) => !notification.read).length,
    [notifications],
  );

  /* ------------------------------ actions ----------------------------- */

  const persistEnrollment = useCallback(
    async (enrollment: Enrollment) => {
      setEnrollments((prev) => ({ ...prev, [enrollment.courseId]: enrollment }));
      if (uid) await learningService.saveEnrollment(uid, enrollment);
    },
    [uid],
  );

  const enroll = useCallback(
    async (courseId: string) => {
      if (enrollments[courseId]) return;
      const now = new Date().toISOString();
      await persistEnrollment({
        courseId,
        enrolledAt: now,
        lastOpenedAt: now,
        lessons: {},
      });
    },
    [enrollments, persistEnrollment],
  );

  const unenroll = useCallback(
    async (courseId: string) => {
      setEnrollments((prev) => {
        const next = { ...prev };
        delete next[courseId];
        return next;
      });
      if (uid) await learningService.removeEnrollment(uid, courseId);
    },
    [uid],
  );

  const setLastLesson = useCallback(
    async (courseId: string, lessonId: string) => {
      const current = enrollments[courseId];
      if (!current) return;
      await persistEnrollment({
        ...current,
        lastLessonId: lessonId,
        lastOpenedAt: new Date().toISOString(),
      });
    },
    [enrollments, persistEnrollment],
  );

  const setLessonComplete = useCallback(
    async (courseId: string, lessonId: string, completed: boolean) => {
      const current = enrollments[courseId];
      if (!current) return;
      const course = getCourse(courseId);
      const previous = current.lessons[lessonId];
      const next: Enrollment = {
        ...current,
        lastLessonId: lessonId,
        lastOpenedAt: new Date().toISOString(),
        lessons: {
          ...current.lessons,
          [lessonId]: {
            lessonId,
            completed,
            positionSeconds: previous?.positionSeconds ?? 0,
            completedAt: completed ? new Date().toISOString() : undefined,
          },
        },
      };
      if (course) {
        const total = lessonTotal(course);
        const done = Object.values(next.lessons).filter((lesson) => lesson.completed).length;
        next.completedAt = total > 0 && done >= total ? new Date().toISOString() : undefined;
      }
      await persistEnrollment(next);

      // Record study time so the streak and charts reflect real activity.
      if (completed && !previous?.completed && uid && course) {
        const lesson = course.sections
          .flatMap((section) => section.lessons)
          .find((item) => item.id === lessonId);
        if (lesson) setActivity(await learningService.addActivityMinutes(uid, lesson.durationMinutes));
      }
    },
    [enrollments, getCourse, persistEnrollment, uid],
  );

  const saveLessonPosition = useCallback(
    async (courseId: string, lessonId: string, seconds: number) => {
      const current = enrollments[courseId];
      if (!current) return;
      const previous = current.lessons[lessonId];
      if (previous && Math.abs(previous.positionSeconds - seconds) < 5) return;
      await persistEnrollment({
        ...current,
        lessons: {
          ...current.lessons,
          [lessonId]: {
            lessonId,
            completed: previous?.completed ?? false,
            completedAt: previous?.completedAt,
            positionSeconds: seconds,
          },
        },
      });
    },
    [enrollments, persistEnrollment],
  );

  const saveNote = useCallback(
    async (lessonId: string, text: string) => {
      if (!uid) return;
      setNotes(await learningService.saveNote(uid, lessonId, text));
    },
    [uid],
  );

  const submitQuiz = useCallback(
    async (courseId: string, answers: Record<string, string>) => {
      const quiz = getQuiz(courseId);
      if (!quiz) throw new Error('This course does not have an assessment yet.');
      const score = quiz.questions.filter(
        (question) => answers[question.id] === question.correctOptionId,
      ).length;
      const total = quiz.questions.length;
      const percentage = total ? Math.round((score / total) * 100) : 0;
      const attempt: QuizAttempt = {
        id: createId('attempt'),
        courseId,
        quizId: quiz.id,
        score,
        total,
        percentage,
        passed: percentage >= (quiz.passingScore ?? QUIZ_PASSING_SCORE),
        answers,
        takenAt: new Date().toISOString(),
      };
      setAttempts((prev) => [attempt, ...prev]);
      if (uid) await learningService.saveQuizAttempt(uid, attempt);
      return attempt;
    },
    [getQuiz, uid],
  );

  const issueCertificate = useCallback(
    async (courseId: string) => {
      if (!user) return undefined;
      const course = getCourse(courseId);
      if (!course) return undefined;

      const existing = certificates.find((item) => item.courseId === courseId);
      if (existing) return existing;

      const best = attempts
        .filter((attempt) => attempt.courseId === courseId)
        .sort((a, b) => b.percentage - a.percentage)[0];

      const certificate: Certificate = {
        id: certificateId(user.uid, courseId),
        courseId,
        courseTitle: course.title,
        studentName: user.fullName,
        instructorName: course.instructor.name,
        issuedAt: new Date().toISOString(),
        score: best?.percentage ?? 100,
      };
      setCertificates((prev) => [certificate, ...prev.filter((item) => item.id !== certificate.id)]);
      await learningService.saveCertificate(user.uid, certificate);
      return certificate;
    },
    [attempts, certificates, getCourse, user],
  );

  const shareCertificate = useCallback(
    (certificate: Certificate) => certificateService.share(certificate),
    [],
  );

  const downloadCertificate = useCallback(
    (certificate: Certificate) => certificateService.toPdf(certificate),
    [],
  );

  const markNotificationRead = useCallback(
    async (id: string) => {
      const next = notifications.map((notification) =>
        notification.id === id ? { ...notification, read: true } : notification,
      );
      setNotifications(next);
      if (uid) await notificationsService.save(uid, next);
    },
    [notifications, uid],
  );

  const markAllNotificationsRead = useCallback(async () => {
    const next = notifications.map((notification) => ({ ...notification, read: true }));
    setNotifications(next);
    if (uid) await notificationsService.save(uid, next);
  }, [notifications, uid]);

  const toggleWishlist = useCallback(
    async (courseId: string) => {
      const next = wishlist.includes(courseId)
        ? wishlist.filter((id) => id !== courseId)
        : [...wishlist, courseId];
      setWishlist(next);
      if (uid) await learningService.setWishlist(uid, next);
    },
    [uid, wishlist],
  );

  const value = useMemo<LearningContextValue>(
    () => ({
      loading,
      courses,
      quizzes,
      enrollments,
      attempts,
      certificates,
      notifications,
      notes,
      activity,
      wishlist,
      unreadCount,
      enrolledCourses,
      stats,
      getCourse,
      getQuiz,
      getEnrollment,
      isEnrolled,
      courseProgress,
      bestAttempt,
      certificateFor,
      enroll,
      unenroll,
      setLastLesson,
      setLessonComplete,
      saveLessonPosition,
      saveNote,
      submitQuiz,
      issueCertificate,
      shareCertificate,
      downloadCertificate,
      markNotificationRead,
      markAllNotificationsRead,
      toggleWishlist,
      refresh,
    }),
    [
      loading,
      courses,
      quizzes,
      enrollments,
      attempts,
      certificates,
      notifications,
      notes,
      activity,
      wishlist,
      unreadCount,
      enrolledCourses,
      stats,
      getCourse,
      getQuiz,
      getEnrollment,
      isEnrolled,
      courseProgress,
      bestAttempt,
      certificateFor,
      enroll,
      unenroll,
      setLastLesson,
      setLessonComplete,
      saveLessonPosition,
      saveNote,
      submitQuiz,
      issueCertificate,
      shareCertificate,
      downloadCertificate,
      markNotificationRead,
      markAllNotificationsRead,
      toggleWishlist,
      refresh,
    ],
  );

  return <LearningContext.Provider value={value}>{children}</LearningContext.Provider>;
}

export function useLearning() {
  const context = useContext(LearningContext);
  if (!context) throw new Error('useLearning must be used inside a LearningProvider');
  return context;
}
