import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

import { authService, type SignUpInput } from '@/services/auth.service';
import { firebaseErrorMessage, isFirebaseConfigured } from '@/services/firebase';
import { learningService } from '@/services/learning.service';
import type { UserProfile } from '@/types';

interface AuthContextValue {
  user: UserProfile | null;
  initializing: boolean;
  busy: boolean;
  isDemoMode: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (input: SignUpInput) => Promise<void>;
  signInWithGoogle: (idToken?: string) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateProfile: (patch: Partial<UserProfile>) => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  deleteAccount: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    authService
      .restoreSession()
      .then((profile) => {
        if (!cancelled) setUser(profile);
      })
      .catch(() => undefined)
      .finally(() => {
        if (!cancelled) setInitializing(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  /** Wraps an auth call with busy state and friendly error messages. */
  const run = useCallback(async <T,>(action: () => Promise<T>): Promise<T> => {
    setBusy(true);
    try {
      return await action();
    } catch (error) {
      throw new Error(firebaseErrorMessage(error));
    } finally {
      setBusy(false);
    }
  }, []);

  const signIn = useCallback(
    async (email: string, password: string) => {
      const profile = await run(() => authService.signIn(email, password));
      setUser(profile);
    },
    [run],
  );

  const signUp = useCallback(
    async (input: SignUpInput) => {
      const profile = await run(() => authService.signUp(input));
      setUser(profile);
    },
    [run],
  );

  const signInWithGoogle = useCallback(
    async (idToken?: string) => {
      const profile = await run(() => authService.signInWithGoogleIdToken(idToken));
      setUser(profile);
    },
    [run],
  );

  const signOut = useCallback(async () => {
    await run(() => authService.signOut());
    setUser(null);
  }, [run]);

  const resetPassword = useCallback(
    async (email: string) => {
      await run(() => authService.resetPassword(email));
    },
    [run],
  );

  const updateProfile = useCallback(
    async (patch: Partial<UserProfile>) => {
      if (!user) throw new Error('You are signed out. Please sign in again.');
      const profile = await run(() => authService.updateProfile(user.uid, patch));
      setUser(profile);
    },
    [run, user],
  );

  const changePassword = useCallback(
    async (currentPassword: string, newPassword: string) => {
      await run(() => authService.changePassword(currentPassword, newPassword));
    },
    [run],
  );

  const deleteAccount = useCallback(async () => {
    const uid = user?.uid;
    await run(() => authService.deleteAccount());
    if (uid) await learningService.clearLocal(uid);
    setUser(null);
  }, [run, user?.uid]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      initializing,
      busy,
      isDemoMode: !isFirebaseConfigured,
      signIn,
      signUp,
      signInWithGoogle,
      signOut,
      resetPassword,
      updateProfile,
      changePassword,
      deleteAccount,
    }),
    [
      user,
      initializing,
      busy,
      signIn,
      signUp,
      signInWithGoogle,
      signOut,
      resetPassword,
      updateProfile,
      changePassword,
      deleteAccount,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside an AuthProvider');
  return context;
}
