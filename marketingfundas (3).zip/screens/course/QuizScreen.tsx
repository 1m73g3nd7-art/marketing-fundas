import * as Haptics from 'expo-haptics';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useCallback, useMemo, useState } from 'react';
import { Platform, Pressable, ScrollView, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';

import { RingProgress } from '@/components/charts/RingProgress';
import { AppHeader } from '@/components/ui/AppHeader';
import { Button } from '@/components/ui/Button';
import { Icon } from '@/components/ui/Icon';
import { LoadingScreen } from '@/components/ui/Loading';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { Screen } from '@/components/ui/Screen';
import { useLearning } from '@/context/LearningContext';
import type { QuizAttempt } from '@/types';

export function QuizScreen() {
  const router = useRouter();
  const { courseId } = useLocalSearchParams<{ courseId: string }>();
  const { loading, getCourse, getQuiz, submitQuiz, issueCertificate } = useLearning();

  const course = getCourse(courseId);
  const quiz = course ? getQuiz(course.id) : undefined;

  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [result, setResult] = useState<QuizAttempt | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [reviewing, setReviewing] = useState(false);

  const question = quiz?.questions[index];
  const answeredCount = useMemo(() => Object.keys(answers).length, [answers]);

  const select = useCallback(
    (questionId: string, optionId: string) => {
      if (Platform.OS !== 'web') void Haptics.selectionAsync();
      setAnswers((prev) => ({ ...prev, [questionId]: optionId }));
    },
    [],
  );

  const submit = useCallback(async () => {
    if (!course || !quiz) return;
    setSubmitting(true);
    try {
      const attempt = await submitQuiz(course.id, answers);
      setResult(attempt);
      if (attempt.passed) await issueCertificate(course.id);
      if (Platform.OS !== 'web') {
        void Haptics.notificationAsync(
          attempt.passed
            ? Haptics.NotificationFeedbackType.Success
            : Haptics.NotificationFeedbackType.Warning,
        );
      }
    } finally {
      setSubmitting(false);
    }
  }, [answers, course, issueCertificate, quiz, submitQuiz]);

  const retry = () => {
    setAnswers({});
    setIndex(0);
    setResult(null);
    setReviewing(false);
  };

  if (loading && !course) return <LoadingScreen message="Loading assessment…" />;

  if (!course || !quiz) {
    return (
      <Screen>
        <AppHeader title="Assessment" />
        <View className="flex-1 items-center justify-center px-8">
          <Icon name="help-circle-outline" size={44} className="text-ink-300" />
          <Text className="mt-4 text-center text-[15px] font-bold text-ink-900 dark:text-white">
            This course does not have an assessment yet
          </Text>
          <View className="mt-6 w-full max-w-[220px]">
            <Button title="Go back" onPress={() => router.back()} />
          </View>
        </View>
      </Screen>
    );
  }

  /* ----------------------------- results ---------------------------- */

  if (result && !reviewing) {
    return (
      <Screen>
        <AppHeader title="Your result" subtitle={quiz.title} showBack={false} />
        <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-10">
          <Animated.View
            entering={FadeInDown.duration(420)}
            className="items-center rounded-[28px] border border-ink-100 bg-white p-7 dark:border-ink-800 dark:bg-ink-900"
          >
            <RingProgress
              value={result.percentage}
              size={168}
              strokeWidth={15}
              caption={result.passed ? 'Passed' : 'Score'}
              colors={result.passed ? ['#14B8AA', '#6355F0'] : ['#F59E0B', '#EF4444']}
            />

            <Text className="mt-5 text-[20px] font-extrabold tracking-tight text-ink-900 dark:text-white">
              {result.passed ? 'Congratulations! 🎉' : 'Almost there'}
            </Text>
            <Text className="mt-1.5 text-center text-[13.5px] leading-5 text-ink-500 dark:text-ink-300">
              You answered {result.score} of {result.total} questions correctly.
              {result.passed
                ? ' Your certificate is ready.'
                : ` You need ${quiz.passingScore}% to pass — review the answers and try again.`}
            </Text>

            <View className="mt-6 w-full flex-row gap-3">
              <ScoreChip
                icon="checkmark-circle"
                tone="text-emerald-600 dark:text-emerald-400"
                value={`${result.score}`}
                label="Correct"
              />
              <ScoreChip
                icon="close-circle"
                tone="text-red-500"
                value={`${result.total - result.score}`}
                label="Incorrect"
              />
              <ScoreChip
                icon="flag"
                tone="text-brand-500"
                value={`${quiz.passingScore}%`}
                label="To pass"
              />
            </View>
          </Animated.View>

          <View className="mt-5 gap-3">
            <Button
              title="Review answers"
              variant="secondary"
              icon="eye-outline"
              onPress={() => {
                setReviewing(true);
                setIndex(0);
              }}
            />

            {result.passed ? (
              <Button
                title="View Certificate"
                icon="ribbon-outline"
                onPress={() =>
                  router.replace({
                    pathname: '/certificate/[courseId]',
                    params: { courseId: course.id },
                  })
                }
              />
            ) : (
              <Button title="Retry Quiz" icon="refresh" onPress={retry} />
            )}

            <Button
              title="Back to course"
              variant="ghost"
              onPress={() =>
                router.replace({ pathname: '/course/[id]', params: { id: course.id } })
              }
            />
          </View>
        </ScrollView>
      </Screen>
    );
  }

  /* ------------------------------ review ----------------------------- */

  if (result && reviewing) {
    return (
      <Screen>
        <AppHeader
          title="Answer review"
          subtitle={`${result.score}/${result.total} correct`}
          onBack={() => setReviewing(false)}
        />
        <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-10">
          {quiz.questions.map((item, questionIndex) => {
            const chosen = result.answers[item.id];
            const correct = chosen === item.correctOptionId;
            return (
              <View
                key={item.id}
                className="mb-3 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900"
              >
                <View className="flex-row items-start gap-2.5">
                  <Icon
                    name={correct ? 'checkmark-circle' : 'close-circle'}
                    size={19}
                    className={correct ? 'text-emerald-500' : 'text-red-500'}
                  />
                  <Text className="flex-1 text-[14px] font-bold leading-5 text-ink-900 dark:text-white">
                    {questionIndex + 1}. {item.question}
                  </Text>
                </View>

                <View className="mt-3 gap-2">
                  {item.options.map((option) => {
                    const isCorrect = option.id === item.correctOptionId;
                    const isChosen = option.id === chosen;
                    return (
                      <View
                        key={option.id}
                        className={`flex-row items-center gap-2 rounded-2xl border px-3 py-2.5 ${
                          isCorrect
                            ? 'border-emerald-300 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950'
                            : isChosen
                              ? 'border-red-300 bg-red-50 dark:border-red-900 dark:bg-red-950'
                              : 'border-ink-100 dark:border-ink-800'
                        }`}
                      >
                        <Icon
                          name={isCorrect ? 'checkmark' : isChosen ? 'close' : 'ellipse-outline'}
                          size={14}
                          className={
                            isCorrect
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : isChosen
                                ? 'text-red-500'
                                : 'text-ink-300'
                          }
                        />
                        <Text className="flex-1 text-[13px] text-ink-700 dark:text-ink-200">
                          {option.text}
                        </Text>
                      </View>
                    );
                  })}
                </View>

                <View className="mt-3 rounded-2xl bg-ink-50 p-3 dark:bg-ink-950">
                  <Text className="text-[12.5px] leading-[18px] text-ink-500 dark:text-ink-300">
                    {item.explanation}
                  </Text>
                </View>
              </View>
            );
          })}

          <Button title="Back to result" variant="secondary" onPress={() => setReviewing(false)} />
        </ScrollView>
      </Screen>
    );
  }

  /* ------------------------------- quiz ------------------------------ */

  if (!question) return <LoadingScreen />;

  const selected = answers[question.id];
  const isLast = index === quiz.questions.length - 1;

  return (
    <Screen>
      <AppHeader
        title={quiz.title}
        subtitle={course.title}
        onBack={() => router.back()}
        right={
          <View className="rounded-full bg-brand-50 px-3 py-1.5 dark:bg-brand-950">
            <Text className="text-[12px] font-extrabold text-brand-600 dark:text-brand-300">
              {index + 1}/{quiz.questions.length}
            </Text>
          </View>
        }
      />

      <View className="px-5">
        <ProgressBar value={((index + 1) / quiz.questions.length) * 100} height={6} />
        <Text className="mt-2 text-[11.5px] text-ink-400">
          {answeredCount} of {quiz.questions.length} answered
        </Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-32 pt-5">
        <Animated.View key={question.id} entering={FadeIn.duration(280)}>
          <Text className="text-[11px] font-bold uppercase tracking-wider text-brand-500">
            Question {index + 1}
          </Text>
          <Text className="mt-2 text-[19px] font-extrabold leading-[26px] tracking-tight text-ink-900 dark:text-white">
            {question.question}
          </Text>

          <View className="mt-6 gap-3">
            {question.options.map((option, optionIndex) => {
              const active = selected === option.id;
              return (
                <Pressable
                  key={option.id}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: active }}
                  onPress={() => select(question.id, option.id)}
                  className={`flex-row items-center gap-3 rounded-3xl border p-4 ${
                    active
                      ? 'border-brand-500 bg-brand-50 dark:bg-brand-950'
                      : 'border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900'
                  }`}
                >
                  <View
                    className={`h-8 w-8 items-center justify-center rounded-full ${
                      active ? 'bg-brand-600' : 'bg-ink-100 dark:bg-ink-800'
                    }`}
                  >
                    <Text
                      className={`text-[12.5px] font-extrabold ${
                        active ? 'text-white' : 'text-ink-500 dark:text-ink-300'
                      }`}
                    >
                      {String.fromCharCode(65 + optionIndex)}
                    </Text>
                  </View>
                  <Text
                    className={`flex-1 text-[14px] leading-[20px] ${
                      active
                        ? 'font-semibold text-brand-800 dark:text-brand-100'
                        : 'text-ink-700 dark:text-ink-200'
                    }`}
                  >
                    {option.text}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </Animated.View>
      </ScrollView>

      <View className="absolute bottom-0 left-0 right-0 flex-row items-center gap-3 border-t border-ink-100 bg-white px-5 pb-8 pt-3 dark:border-ink-800 dark:bg-ink-900">
        <View className="w-[110px]">
          <Button
            title="Previous"
            variant="outline"
            icon="chevron-back"
            disabled={index === 0}
            onPress={() => setIndex((value) => Math.max(0, value - 1))}
          />
        </View>

        <View className="flex-1">
          {isLast ? (
            <Button
              title="Submit Quiz"
              icon="checkmark-done"
              loading={submitting}
              disabled={answeredCount < quiz.questions.length}
              onPress={submit}
            />
          ) : (
            <Button
              title="Next"
              iconRight="chevron-forward"
              disabled={!selected}
              onPress={() => setIndex((value) => Math.min(quiz.questions.length - 1, value + 1))}
            />
          )}
        </View>
      </View>
    </Screen>
  );
}

function ScoreChip({
  icon,
  tone,
  value,
  label,
}: {
  icon: React.ComponentProps<typeof Icon>['name'];
  tone: string;
  value: string;
  label: string;
}) {
  return (
    <View className="flex-1 items-center rounded-2xl bg-ink-50 py-3 dark:bg-ink-950">
      <Icon name={icon} size={17} className={tone} />
      <Text className="mt-1 text-[15px] font-extrabold text-ink-900 dark:text-white">{value}</Text>
      <Text className="text-[10.5px] text-ink-400">{label}</Text>
    </View>
  );
}
