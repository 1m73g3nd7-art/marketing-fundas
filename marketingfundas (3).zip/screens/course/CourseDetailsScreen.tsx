import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { InstructorCard } from '@/components/course/InstructorCard';
import { LessonRow } from '@/components/course/LessonRow';
import { ReviewCard } from '@/components/course/ReviewCard';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Icon, type IconName } from '@/components/ui/Icon';
import { LoadingScreen } from '@/components/ui/Loading';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { Rating } from '@/components/ui/Rating';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { categoryById } from '@/constants/categories';
import { useLearning } from '@/context/LearningContext';
import { formatCount, formatDate, formatDuration, formatPrice } from '@/utils/format';
import { lessonTotal, nextLessonFor, progressPercent } from '@/utils/progress';

export function CourseDetailsScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const {
    loading,
    getCourse,
    getEnrollment,
    isEnrolled,
    enroll,
    wishlist,
    toggleWishlist,
    getQuiz,
  } = useLearning();

  const [enrolling, setEnrolling] = useState(false);
  const [showAllReviews, setShowAllReviews] = useState(false);

  const course = getCourse(id);
  const enrollment = course ? getEnrollment(course.id) : undefined;
  const enrolled = course ? isEnrolled(course.id) : false;
  const percent = course ? progressPercent(course, enrollment) : 0;
  const nextLesson = course ? nextLessonFor(course, enrollment) : undefined;
  const quiz = course ? getQuiz(course.id) : undefined;

  const totalLessons = useMemo(() => (course ? lessonTotal(course) : 0), [course]);

  if (loading && !course) return <LoadingScreen message="Loading course…" />;

  if (!course) {
    return (
      <SafeAreaView className="flex-1 items-center justify-center bg-ink-50 px-8 dark:bg-ink-950">
        <Icon name="alert-circle-outline" size={44} className="text-ink-300" />
        <Text className="mt-4 text-center text-[16px] font-bold text-ink-900 dark:text-white">
          This course is no longer available
        </Text>
        <View className="mt-6 w-full max-w-[220px]">
          <Button title="Back to courses" onPress={() => router.replace('/(tabs)/courses')} />
        </View>
      </SafeAreaView>
    );
  }

  const category = categoryById(course.category);
  const saved = wishlist.includes(course.id);
  const reviews = showAllReviews ? course.reviews : course.reviews.slice(0, 2);

  const handlePrimary = async () => {
    if (enrolled) {
      router.push({
        pathname: '/learn/[courseId]',
        params: { courseId: course.id, lessonId: nextLesson?.id ?? '' },
      });
      return;
    }
    setEnrolling(true);
    try {
      await enroll(course.id);
    } finally {
      setEnrolling(false);
    }
  };

  return (
    <View className="flex-1 bg-ink-50 dark:bg-ink-950">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="pb-40">
        {/* Banner */}
        <View className="h-[280px] w-full bg-ink-200 dark:bg-ink-800">
          <Image
            source={{ uri: course.image }}
            style={{ width: '100%', height: '100%' }}
            contentFit="cover"
            transition={250}
          />
          <LinearGradient
            colors={['rgba(10,12,19,0.65)', 'rgba(10,12,19,0.05)', 'rgba(10,12,19,0.85)']}
            style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
          />

          <SafeAreaView edges={['top']} className="absolute left-0 right-0 top-0">
            <View className="flex-row items-center justify-between px-5 pt-1">
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Go back"
                onPress={() => (router.canGoBack() ? router.back() : router.replace('/(tabs)'))}
                className="h-11 w-11 items-center justify-center rounded-2xl bg-black/35"
              >
                <Icon name="chevron-back" size={20} color="#FFFFFF" />
              </Pressable>

              <View className="flex-row gap-2">
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={saved ? 'Remove from saved' : 'Save course'}
                  onPress={() => toggleWishlist(course.id)}
                  className="h-11 w-11 items-center justify-center rounded-2xl bg-black/35"
                >
                  <Icon
                    name={saved ? 'bookmark' : 'bookmark-outline'}
                    size={19}
                    color={saved ? '#FBBF24' : '#FFFFFF'}
                  />
                </Pressable>
              </View>
            </View>
          </SafeAreaView>

          <View className="absolute bottom-11 left-5 right-5">
            <View className="flex-row gap-2">
              <Badge label={category.label} tone="brand" icon={category.icon} />
              {course.bestseller ? <Badge label="Bestseller" tone="gold" /> : null}
              {course.isNew ? <Badge label="New" tone="accent" /> : null}
            </View>
            <Text className="mt-3 text-[24px] font-extrabold leading-8 tracking-tight text-white">
              {course.title}
            </Text>
            <Text className="mt-1 text-[13px] text-white/75">{course.subtitle}</Text>
          </View>
        </View>

        {/* Meta strip */}
        <View className="mx-5 -mt-6 flex-row items-center justify-between rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
          <Meta icon="star" value={course.rating.toFixed(1)} label={`${formatCount(course.ratingCount)} ratings`} />
          <View className="h-8 w-px bg-ink-100 dark:bg-ink-800" />
          <Meta icon="people-outline" value={formatCount(course.studentCount)} label="Students" />
          <View className="h-8 w-px bg-ink-100 dark:bg-ink-800" />
          <Meta icon="play-circle-outline" value={`${totalLessons}`} label="Lessons" />
          <View className="h-8 w-px bg-ink-100 dark:bg-ink-800" />
          <Meta icon="time-outline" value={formatDuration(course.durationMinutes)} label="Duration" />
        </View>

        {/* Enrolled progress */}
        {enrolled ? (
          <View className="mx-5 mt-4 rounded-3xl border border-brand-100 bg-brand-50 p-4 dark:border-brand-900 dark:bg-brand-950">
            <View className="mb-2 flex-row items-center justify-between">
              <Text className="text-[13px] font-bold text-brand-800 dark:text-brand-200">
                Your progress
              </Text>
              <Text className="text-[13px] font-extrabold text-brand-700 dark:text-brand-200">
                {percent}%
              </Text>
            </View>
            <ProgressBar value={percent} height={7} />
          </View>
        ) : null}

        {/* Facts */}
        <View className="mx-5 mt-5 flex-row flex-wrap gap-2">
          <Fact icon="bar-chart-outline" label={course.level} />
          <Fact icon="language-outline" label={course.language} />
          <Fact icon="refresh-outline" label={`Updated ${formatDate(course.updatedAt)}`} />
          <Fact icon="infinite-outline" label="Lifetime access" />
          {quiz ? <Fact icon="ribbon-outline" label="Certificate included" /> : null}
        </View>

        {/* Description */}
        <View className="mx-5 mt-7">
          <SectionHeader title="About this course" />
          <Text className="mt-2.5 text-[14px] leading-[22px] text-ink-600 dark:text-ink-300">
            {course.description}
          </Text>
        </View>

        {/* Outcomes */}
        <View className="mx-5 mt-7">
          <SectionHeader title="What you will learn" />
          <View className="mt-3 gap-2.5 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
            {course.outcomes.map((outcome) => (
              <View key={outcome} className="flex-row gap-2.5">
                <Icon
                  name="checkmark-circle"
                  size={17}
                  className="mt-px text-accent-500 dark:text-accent-400"
                />
                <Text className="flex-1 text-[13.5px] leading-[20px] text-ink-700 dark:text-ink-200">
                  {outcome}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Curriculum */}
        <View className="mx-5 mt-7">
          <SectionHeader
            title="Course curriculum"
            subtitle={`${course.sections.length} sections · ${totalLessons} lessons · ${formatDuration(course.durationMinutes)}`}
          />
          <View className="mt-3 gap-3">
            {course.sections.map((section, sectionIndex) => (
              <View
                key={section.id}
                className="overflow-hidden rounded-3xl border border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900"
              >
                <View className="flex-row items-center gap-2.5 border-b border-ink-100 px-4 py-3 dark:border-ink-800">
                  <View className="h-7 w-7 items-center justify-center rounded-lg bg-brand-50 dark:bg-brand-950">
                    <Text className="text-[12px] font-extrabold text-brand-600 dark:text-brand-300">
                      {sectionIndex + 1}
                    </Text>
                  </View>
                  <Text className="flex-1 text-[14px] font-extrabold text-ink-900 dark:text-white">
                    {section.title}
                  </Text>
                  <Text className="text-[11.5px] text-ink-400">
                    {section.lessons.length} lessons
                  </Text>
                </View>

                <View className="p-1.5">
                  {section.lessons.map((lesson, lessonIndex) => (
                    <LessonRow
                      key={lesson.id}
                      lesson={lesson}
                      index={lessonIndex}
                      completed={Boolean(enrollment?.lessons[lesson.id]?.completed)}
                      locked={!enrolled && !lesson.isPreview}
                      onPress={() =>
                        router.push({
                          pathname: '/learn/[courseId]',
                          params: { courseId: course.id, lessonId: lesson.id },
                        })
                      }
                    />
                  ))}
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Requirements */}
        <View className="mx-5 mt-7">
          <SectionHeader title="Requirements" />
          <View className="mt-3 gap-2.5">
            {course.requirements.map((requirement) => (
              <View key={requirement} className="flex-row gap-2.5">
                <View className="mt-[7px] h-1.5 w-1.5 rounded-full bg-ink-300 dark:bg-ink-600" />
                <Text className="flex-1 text-[13.5px] leading-[20px] text-ink-600 dark:text-ink-300">
                  {requirement}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Instructor */}
        <View className="mx-5 mt-7">
          <SectionHeader title="Your instructor" />
          <View className="mt-3">
            <InstructorCard instructor={course.instructor} />
          </View>
        </View>

        {/* Reviews */}
        <View className="mx-5 mt-7">
          <SectionHeader
            title="Student reviews"
            subtitle={`${course.rating.toFixed(1)} average from ${formatCount(course.ratingCount)} ratings`}
          />
          <View className="mt-3">
            {reviews.map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
            {course.reviews.length > 2 ? (
              <Pressable
                accessibilityRole="button"
                onPress={() => setShowAllReviews((value) => !value)}
                className="items-center py-2"
              >
                <Text className="text-[13px] font-bold text-brand-600 dark:text-brand-300">
                  {showAllReviews ? 'Show fewer reviews' : `Show all ${course.reviews.length} reviews`}
                </Text>
              </Pressable>
            ) : null}
          </View>
        </View>
      </ScrollView>

      {/* Sticky action bar */}
      <View className="absolute bottom-0 left-0 right-0 border-t border-ink-100 bg-white px-5 pb-8 pt-4 dark:border-ink-800 dark:bg-ink-900">
        <View className="flex-row items-center gap-4">
          {!enrolled ? (
            <View>
              <View className="flex-row items-baseline gap-2">
                <Text className="text-[22px] font-extrabold tracking-tight text-ink-900 dark:text-white">
                  {formatPrice(course.price)}
                </Text>
                {course.originalPrice ? (
                  <Text className="text-[13px] text-ink-300 line-through">
                    {formatPrice(course.originalPrice)}
                  </Text>
                ) : null}
              </View>
              {course.originalPrice ? (
                <Text className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                  {Math.round((1 - course.price / course.originalPrice) * 100)}% off today
                </Text>
              ) : null}
            </View>
          ) : (
            <View className="flex-1">
              <Text className="text-[12px] font-semibold text-ink-400">
                {percent === 100 ? 'Course complete' : `${percent}% complete`}
              </Text>
              <Text
                numberOfLines={1}
                className="text-[13.5px] font-bold text-ink-900 dark:text-white"
              >
                {nextLesson?.title ?? course.title}
              </Text>
            </View>
          )}

          <View className={enrolled ? 'w-[150px]' : 'flex-1'}>
            <Button
              title={enrolled ? 'Start Learning' : 'Enroll Now'}
              size="lg"
              loading={enrolling}
              icon={enrolled ? 'play' : 'flash'}
              onPress={handlePrimary}
            />
          </View>
        </View>

        {enrolled && percent === 100 && quiz ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push({ pathname: '/quiz/[courseId]', params: { courseId: course.id } })}
            className="mt-3 flex-row items-center justify-center gap-1.5"
          >
            <Icon name="ribbon-outline" size={15} className="text-brand-600 dark:text-brand-300" />
            <Text className="text-[13px] font-bold text-brand-600 dark:text-brand-300">
              Take the final assessment
            </Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

function Meta({ icon, value, label }: { icon: IconName; value: string; label: string }) {
  return (
    <View className="items-center">
      <Icon name={icon} size={16} className="text-brand-500" />
      <Text className="mt-1 text-[13.5px] font-extrabold text-ink-900 dark:text-white">{value}</Text>
      <Text className="text-[10px] text-ink-400">{label}</Text>
    </View>
  );
}

function Fact({ icon, label }: { icon: IconName; label: string }) {
  return (
    <View className="flex-row items-center gap-1.5 rounded-full border border-ink-100 bg-white px-3 py-1.5 dark:border-ink-800 dark:bg-ink-900">
      <Icon name={icon} size={13} className="text-ink-400" />
      <Text className="text-[11.5px] font-semibold text-ink-600 dark:text-ink-300">{label}</Text>
    </View>
  );
}
