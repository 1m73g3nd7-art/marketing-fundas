import { useLocalSearchParams, useRouter } from 'expo-router';
import { useVideoPlayer, VideoView } from 'expo-video';
import * as WebBrowser from 'expo-web-browser';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { LessonRow } from '@/components/course/LessonRow';
import { Avatar } from '@/components/ui/Avatar';
import { Button } from '@/components/ui/Button';
import { Icon, type IconName } from '@/components/ui/Icon';
import { LoadingScreen } from '@/components/ui/Loading';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { SegmentedTabs } from '@/components/ui/SegmentedTabs';
import { palette } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { useLearning } from '@/context/LearningContext';
import { useSettings } from '@/context/SettingsContext';
import type { Lesson, LessonResource } from '@/types';
import { formatDuration } from '@/utils/format';
import { flattenLessons, nextLessonFor, progressPercent } from '@/utils/progress';

type TabKey = 'overview' | 'notes' | 'resources' | 'discussion';

const TABS: { value: TabKey; label: string }[] = [
  { value: 'overview', label: 'Overview' },
  { value: 'notes', label: 'Notes' },
  { value: 'resources', label: 'Resources' },
  { value: 'discussion', label: 'Discussion' },
];

export function LearningScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const { isDark } = useSettings();
  const { courseId, lessonId } = useLocalSearchParams<{ courseId: string; lessonId?: string }>();
  const {
    loading,
    getCourse,
    getEnrollment,
    isEnrolled,
    enroll,
    setLastLesson,
    setLessonComplete,
    saveLessonPosition,
    notes,
    saveNote,
    getQuiz,
  } = useLearning();

  const course = getCourse(courseId);
  const enrollment = course ? getEnrollment(course.id) : undefined;

  const lessons = useMemo(() => (course ? flattenLessons(course) : []), [course]);

  const [activeId, setActiveId] = useState<string | undefined>(undefined);
  const [tab, setTab] = useState<TabKey>('overview');
  const [noteDraft, setNoteDraft] = useState('');
  const [noteSaved, setNoteSaved] = useState(false);
  const [showCurriculum, setShowCurriculum] = useState(true);

  // Resolve the lesson to play: explicit param → resume point → first lesson.
  useEffect(() => {
    if (!course || activeId) return;
    const requested = lessonId && lessons.find((item) => item.id === lessonId);
    const resume = nextLessonFor(course, enrollment);
    setActiveId((requested || resume || lessons[0])?.id);
  }, [activeId, course, enrollment, lessonId, lessons]);

  const activeIndex = lessons.findIndex((item) => item.id === activeId);
  const lesson: Lesson | undefined = activeIndex >= 0 ? lessons[activeIndex] : undefined;
  const completed = Boolean(lesson && enrollment?.lessons[lesson.id]?.completed);
  const percent = course ? progressPercent(course, enrollment) : 0;
  const quiz = course ? getQuiz(course.id) : undefined;

  const player = useVideoPlayer(lesson?.videoUrl ?? null, (instance) => {
    instance.loop = false;
    instance.timeUpdateEventInterval = 5;
  });

  // Auto-enrol when a learner opens a lesson directly from a shared link.
  useEffect(() => {
    if (course && !isEnrolled(course.id)) void enroll(course.id);
  }, [course, enroll, isEnrolled]);

  // Record the resume point whenever the active lesson changes.
  useEffect(() => {
    if (course && lesson) void setLastLesson(course.id, lesson.id);
  }, [course, lesson, setLastLesson]);

  useEffect(() => {
    setNoteDraft(lesson ? (notes[lesson.id] ?? '') : '');
    setNoteSaved(false);
  }, [lesson, notes]);

  // Persist playback position periodically so learners resume mid-lesson.
  const positionRef = useRef(0);
  useEffect(() => {
    if (!course || !lesson) return;
    const timer = setInterval(() => {
      const current = player.currentTime ?? 0;
      if (current > 0 && Math.abs(current - positionRef.current) >= 5) {
        positionRef.current = current;
        void saveLessonPosition(course.id, lesson.id, Math.round(current));
      }
    }, 5000);
    return () => clearInterval(timer);
  }, [course, lesson, player, saveLessonPosition]);

  const goTo = useCallback(
    (index: number) => {
      const target = lessons[index];
      if (!target) return;
      setActiveId(target.id);
      setTab('overview');
    },
    [lessons],
  );

  const toggleComplete = useCallback(async () => {
    if (!course || !lesson) return;
    await setLessonComplete(course.id, lesson.id, !completed);
    if (!completed && activeIndex < lessons.length - 1) goTo(activeIndex + 1);
  }, [activeIndex, completed, course, goTo, lesson, lessons.length, setLessonComplete]);

  const persistNote = useCallback(async () => {
    if (!lesson) return;
    await saveNote(lesson.id, noteDraft);
    setNoteSaved(true);
  }, [lesson, noteDraft, saveNote]);

  if (loading && !course) return <LoadingScreen message="Opening your lesson…" />;

  if (!course || !lesson) {
    return (
      <SafeAreaView className="flex-1 items-center justify-center bg-ink-50 px-8 dark:bg-ink-950">
        <Icon name="videocam-off-outline" size={44} className="text-ink-300" />
        <Text className="mt-4 text-center text-[16px] font-bold text-ink-900 dark:text-white">
          This lesson is not available
        </Text>
        <View className="mt-6 w-full max-w-[220px]">
          <Button title="Back to My Learning" onPress={() => router.replace('/(tabs)/learning')} />
        </View>
      </SafeAreaView>
    );
  }

  const isLast = activeIndex === lessons.length - 1;

  return (
    <View className="flex-1 bg-ink-50 dark:bg-ink-950">
      {/* Player */}
      <SafeAreaView edges={['top']} className="bg-black">
        <View className="relative aspect-video w-full bg-black">
          <VideoView
            player={player}
            style={{ width: '100%', height: '100%' }}
            fullscreenOptions={{ enable: true }}
            allowsPictureInPicture
            nativeControls
            contentFit="contain"
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Close lesson"
            onPress={() => (router.canGoBack() ? router.back() : router.replace('/(tabs)/learning'))}
            className="absolute left-3 top-3 h-10 w-10 items-center justify-center rounded-2xl bg-black/50"
          >
            <Icon name="chevron-down" size={20} color="#FFFFFF" />
          </Pressable>
        </View>
      </SafeAreaView>

      {/* Course progress strip */}
      <View className="flex-row items-center gap-3 border-b border-ink-100 bg-white px-5 py-3 dark:border-ink-800 dark:bg-ink-900">
        <View className="flex-1">
          <Text numberOfLines={1} className="text-[11.5px] font-semibold text-ink-400">
            {course.title}
          </Text>
          <View className="mt-1.5">
            <ProgressBar value={percent} height={5} />
          </View>
        </View>
        <Text className="text-[12px] font-extrabold text-brand-600 dark:text-brand-300">
          {percent}%
        </Text>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={80}
        className="flex-1"
      >
        <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="pb-32">
          {/* Lesson header */}
          <View className="px-5 pt-4">
            <Text className="text-[11px] font-bold uppercase tracking-wider text-brand-500">
              Lesson {activeIndex + 1} of {lessons.length}
            </Text>
            <Text className="mt-1 text-[19px] font-extrabold leading-6 tracking-tight text-ink-900 dark:text-white">
              {lesson.title}
            </Text>
            <View className="mt-2 flex-row items-center gap-3">
              <View className="flex-row items-center gap-1">
                <Icon name="time-outline" size={13} className="text-ink-400" />
                <Text className="text-[12px] text-ink-400">
                  {formatDuration(lesson.durationMinutes)}
                </Text>
              </View>
              {completed ? (
                <View className="flex-row items-center gap-1">
                  <Icon name="checkmark-circle" size={13} className="text-emerald-500" />
                  <Text className="text-[12px] font-semibold text-emerald-600 dark:text-emerald-400">
                    Completed
                  </Text>
                </View>
              ) : null}
            </View>
          </View>

          {/* Tabs */}
          <View className="mt-4 px-5">
            <SegmentedTabs options={TABS} value={tab} onChange={setTab} scrollable />
          </View>

          <View className="mt-4 px-5">
            {tab === 'overview' ? (
              <View>
                <Text className="text-[14px] leading-[22px] text-ink-600 dark:text-ink-300">
                  {lesson.description}
                </Text>
                <View className="mt-4 flex-row gap-2.5 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
                  <Avatar uri={course.instructor.avatar} name={course.instructor.name} size={38} />
                  <View className="flex-1">
                    <Text className="text-[13px] font-bold text-ink-900 dark:text-white">
                      {course.instructor.name}
                    </Text>
                    <Text numberOfLines={1} className="text-[11.5px] text-ink-400">
                      {course.instructor.title}
                    </Text>
                  </View>
                </View>
              </View>
            ) : null}

            {tab === 'notes' ? (
              <View>
                <Text className="mb-2 text-[12.5px] text-ink-400">
                  Notes are saved to this lesson and appear whenever you return.
                </Text>
                <TextInput
                  value={noteDraft}
                  onChangeText={(text) => {
                    setNoteDraft(text);
                    setNoteSaved(false);
                  }}
                  multiline
                  textAlignVertical="top"
                  placeholder="Write what you want to remember from this lesson…"
                  placeholderTextColor={isDark ? palette.ink[500] : palette.ink[400]}
                  className="min-h-[150px] rounded-3xl border border-ink-100 bg-white p-4 text-[14px] leading-[21px] text-ink-900 dark:border-ink-800 dark:bg-ink-900 dark:text-white"
                />
                <View className="mt-3 flex-row items-center gap-3">
                  <View className="flex-1">
                    <Button title="Save note" size="sm" icon="save-outline" onPress={persistNote} />
                  </View>
                  {noteSaved ? (
                    <View className="flex-row items-center gap-1">
                      <Icon name="checkmark-circle" size={15} className="text-emerald-500" />
                      <Text className="text-[12px] font-semibold text-emerald-600 dark:text-emerald-400">
                        Saved
                      </Text>
                    </View>
                  ) : null}
                </View>
              </View>
            ) : null}

            {tab === 'resources' ? (
              <View className="gap-2.5">
                {lesson.resources?.length ? (
                  lesson.resources.map((resource) => (
                    <ResourceRow key={resource.id} resource={resource} />
                  ))
                ) : (
                  <View className="items-center rounded-3xl border border-dashed border-ink-200 py-10 dark:border-ink-800">
                    <Icon name="folder-open-outline" size={28} className="text-ink-300" />
                    <Text className="mt-3 text-[13px] font-semibold text-ink-400">
                      No downloads for this lesson
                    </Text>
                  </View>
                )}
              </View>
            ) : null}

            {tab === 'discussion' ? (
              <DiscussionTab lessonTitle={lesson.title} userName={user?.fullName} />
            ) : null}
          </View>

          {/* Curriculum */}
          <View className="mt-7 px-5">
            <Pressable
              accessibilityRole="button"
              onPress={() => setShowCurriculum((value) => !value)}
              className="flex-row items-center justify-between"
            >
              <Text className="text-[16px] font-extrabold tracking-tight text-ink-900 dark:text-white">
                Course content
              </Text>
              <Icon
                name={showCurriculum ? 'chevron-up' : 'chevron-down'}
                size={18}
                className="text-ink-400"
              />
            </Pressable>

            {showCurriculum ? (
              <View className="mt-3 gap-3">
                {course.sections.map((section, sectionIndex) => (
                  <View
                    key={section.id}
                    className="overflow-hidden rounded-3xl border border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900"
                  >
                    <View className="border-b border-ink-100 px-4 py-2.5 dark:border-ink-800">
                      <Text className="text-[13px] font-extrabold text-ink-900 dark:text-white">
                        {sectionIndex + 1}. {section.title}
                      </Text>
                    </View>
                    <View className="p-1.5">
                      {section.lessons.map((item) => {
                        const index = lessons.findIndex((entry) => entry.id === item.id);
                        return (
                          <LessonRow
                            key={item.id}
                            lesson={item}
                            index={index}
                            active={item.id === lesson.id}
                            completed={Boolean(enrollment?.lessons[item.id]?.completed)}
                            onPress={() => goTo(index)}
                          />
                        );
                      })}
                    </View>
                  </View>
                ))}
              </View>
            ) : null}
          </View>

          {/* Finish course prompt */}
          {percent === 100 && quiz ? (
            <View className="mx-5 mt-6 rounded-3xl border border-brand-100 bg-brand-50 p-4 dark:border-brand-900 dark:bg-brand-950">
              <Text className="text-[14px] font-extrabold text-brand-800 dark:text-brand-100">
                All lessons complete 🎉
              </Text>
              <Text className="mt-1 text-[12.5px] leading-[18px] text-brand-700 dark:text-brand-300">
                Pass the final assessment to unlock your certificate.
              </Text>
              <View className="mt-3">
                <Button
                  title="Start final assessment"
                  size="sm"
                  icon="ribbon-outline"
                  onPress={() =>
                    router.push({ pathname: '/quiz/[courseId]', params: { courseId: course.id } })
                  }
                />
              </View>
            </View>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Bottom controls */}
      <View className="absolute bottom-0 left-0 right-0 flex-row items-center gap-2.5 border-t border-ink-100 bg-white px-5 pb-8 pt-3 dark:border-ink-800 dark:bg-ink-900">
        <NavButton
          icon="chevron-back"
          label="Previous"
          disabled={activeIndex <= 0}
          onPress={() => goTo(activeIndex - 1)}
        />

        <View className="flex-1">
          <Button
            title={completed ? 'Completed' : 'Mark as Complete'}
            icon={completed ? 'checkmark-circle' : 'checkmark'}
            variant={completed ? 'secondary' : 'primary'}
            onPress={toggleComplete}
          />
        </View>

        <NavButton
          icon="chevron-forward"
          label="Next"
          disabled={isLast}
          onPress={() => goTo(activeIndex + 1)}
        />
      </View>
    </View>
  );
}

function NavButton({
  icon,
  label,
  disabled,
  onPress,
}: {
  icon: IconName;
  label: string;
  disabled: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      className="h-12 w-12 items-center justify-center rounded-2xl border border-ink-100 dark:border-ink-800"
      style={{ opacity: disabled ? 0.4 : 1 }}
    >
      <Icon name={icon} size={20} className="text-ink-700 dark:text-ink-100" />
    </Pressable>
  );
}

const RESOURCE_ICONS: Record<LessonResource['type'], IconName> = {
  pdf: 'document-text-outline',
  link: 'link-outline',
  template: 'grid-outline',
  checklist: 'checkbox-outline',
};

function ResourceRow({ resource }: { resource: LessonResource }) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={() => WebBrowser.openBrowserAsync(resource.url).catch(() => undefined)}
      className="flex-row items-center gap-3 rounded-3xl border border-ink-100 bg-white p-3.5 dark:border-ink-800 dark:bg-ink-900"
    >
      <View className="h-10 w-10 items-center justify-center rounded-2xl bg-brand-50 dark:bg-brand-950">
        <Icon
          name={RESOURCE_ICONS[resource.type]}
          size={18}
          className="text-brand-600 dark:text-brand-300"
        />
      </View>
      <View className="flex-1">
        <Text className="text-[13.5px] font-bold text-ink-900 dark:text-white">
          {resource.title}
        </Text>
        <Text className="text-[11.5px] uppercase text-ink-400">
          {resource.type}
          {resource.size ? ` · ${resource.size}` : ''}
        </Text>
      </View>
      <Icon name="download-outline" size={18} className="text-ink-300" />
    </Pressable>
  );
}

function DiscussionTab({ lessonTitle, userName }: { lessonTitle: string; userName?: string }) {
  const { isDark } = useSettings();
  const [message, setMessage] = useState('');
  const [thread, setThread] = useState(() => [
    {
      id: 'seed-1',
      author: 'Priya S.',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&q=80',
      time: '2 days ago',
      body: `Rewatched "${lessonTitle}" twice — the framework finally clicked. Anyone else applying this to a live campaign?`,
    },
    {
      id: 'seed-2',
      author: 'Aarav Mehta',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=128&q=80',
      time: '1 day ago',
      body: 'Great to hear. Post your draft in the community thread and I will review a few this week.',
    },
  ]);

  const post = () => {
    const text = message.trim();
    if (!text) return;
    setThread((prev) => [
      ...prev,
      { id: `local-${Date.now()}`, author: userName ?? 'You', avatar: '', time: 'Just now', body: text },
    ]);
    setMessage('');
  };

  return (
    <View>
      {thread.map((entry) => (
        <View key={entry.id} className="mb-3 flex-row gap-3">
          <Avatar uri={entry.avatar || undefined} name={entry.author} size={36} />
          <View className="flex-1 rounded-3xl rounded-tl-md border border-ink-100 bg-white p-3.5 dark:border-ink-800 dark:bg-ink-900">
            <View className="flex-row items-center justify-between">
              <Text className="text-[13px] font-bold text-ink-900 dark:text-white">
                {entry.author}
              </Text>
              <Text className="text-[11px] text-ink-400">{entry.time}</Text>
            </View>
            <Text className="mt-1 text-[13px] leading-[19px] text-ink-600 dark:text-ink-300">
              {entry.body}
            </Text>
          </View>
        </View>
      ))}

      <View className="mt-2 flex-row items-center gap-2">
        <TextInput
          value={message}
          onChangeText={setMessage}
          placeholder="Ask a question…"
          placeholderTextColor={isDark ? palette.ink[500] : palette.ink[400]}
          className="h-12 flex-1 rounded-2xl border border-ink-100 bg-white px-4 text-[14px] text-ink-900 dark:border-ink-800 dark:bg-ink-900 dark:text-white"
          onSubmitEditing={post}
          returnKeyType="send"
        />
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Post comment"
          onPress={post}
          className="h-12 w-12 items-center justify-center rounded-2xl bg-brand-600"
        >
          <Icon name="send" size={17} color="#FFFFFF" />
        </Pressable>
      </View>
    </View>
  );
}
