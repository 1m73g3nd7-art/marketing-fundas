import * as Clipboard from 'expo-clipboard';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

import { CertificatePreview } from '@/components/course/CertificatePreview';
import { AppHeader } from '@/components/ui/AppHeader';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { Icon } from '@/components/ui/Icon';
import { LoadingScreen } from '@/components/ui/Loading';
import { Screen } from '@/components/ui/Screen';
import { useLearning } from '@/context/LearningContext';
import { certificateService } from '@/services/certificate.service';
import type { Certificate } from '@/types';
import { formatDate } from '@/utils/format';

export function CertificateScreen() {
  const router = useRouter();
  const { courseId } = useLocalSearchParams<{ courseId: string }>();
  const { loading, getCourse, certificateFor, issueCertificate, bestAttempt, courseProgress } =
    useLearning();

  const course = getCourse(courseId);
  const [certificate, setCertificate] = useState<Certificate | undefined>(
    courseId ? certificateFor(courseId) : undefined,
  );
  const [busy, setBusy] = useState<'share' | 'download' | null>(null);

  const attempt = courseId ? bestAttempt(courseId) : undefined;
  const eligible = Boolean(courseId) && courseProgress(courseId) === 100 && Boolean(attempt?.passed);

  useEffect(() => {
    if (!courseId || certificate || !eligible) return;
    void issueCertificate(courseId).then((issued) => {
      if (issued) setCertificate(issued);
    });
  }, [certificate, courseId, eligible, issueCertificate]);

  if (loading && !course) return <LoadingScreen message="Preparing your certificate…" />;

  if (!course) {
    return (
      <Screen>
        <AppHeader title="Certificate" />
        <EmptyState
          icon="ribbon-outline"
          title="Certificate not found"
          message="We could not find that course."
          actionLabel="Back to My Learning"
          onAction={() => router.replace('/(tabs)/learning')}
        />
      </Screen>
    );
  }

  if (!certificate) {
    return (
      <Screen>
        <AppHeader title="Certificate" subtitle={course.title} />
        <EmptyState
          icon="lock-closed-outline"
          title="Certificate locked"
          message={
            courseProgress(course.id) < 100
              ? 'Complete every lesson in this course, then pass the final assessment to unlock your certificate.'
              : 'Pass the final assessment to unlock your certificate.'
          }
          actionLabel={courseProgress(course.id) < 100 ? 'Continue learning' : 'Take the assessment'}
          onAction={() =>
            courseProgress(course.id) < 100
              ? router.push({ pathname: '/learn/[courseId]', params: { courseId: course.id } })
              : router.push({ pathname: '/quiz/[courseId]', params: { courseId: course.id } })
          }
        />
      </Screen>
    );
  }

  const handleShare = async () => {
    setBusy('share');
    try {
      await certificateService.share(certificate);
    } catch {
      Alert.alert('Sharing failed', 'We could not open the share sheet. Please try again.');
    } finally {
      setBusy(null);
    }
  };

  const handleDownload = async () => {
    setBusy('download');
    try {
      const uri = await certificateService.toPdf(certificate);
      Alert.alert(
        'Certificate saved',
        `Your PDF is ready.\n\n${uri}`,
        [
          { text: 'Done', style: 'cancel' },
          { text: 'Share / Save', onPress: handleShare },
        ],
      );
    } catch {
      Alert.alert('Download failed', 'We could not generate the PDF. Please try again.');
    } finally {
      setBusy(null);
    }
  };

  const copyId = async () => {
    await Clipboard.setStringAsync(certificate.id);
    Alert.alert('Copied', 'Certificate ID copied to clipboard.');
  };

  return (
    <Screen>
      <AppHeader title="Your Certificate" subtitle={course.title} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-10">
        <Animated.View entering={FadeInDown.duration(420)}>
          <CertificatePreview certificate={certificate} />
        </Animated.View>

        <View className="mt-5 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
          <DetailRow label="Student name" value={certificate.studentName} />
          <DetailRow label="Course" value={certificate.courseTitle} />
          <DetailRow label="Completion date" value={formatDate(certificate.issuedAt)} />
          <DetailRow label="Final score" value={`${certificate.score}%`} />
          <DetailRow label="Certificate ID" value={certificate.id} onPress={copyId} last />
        </View>

        <View className="mt-5 gap-3">
          <Button
            title="Download Certificate"
            icon="download-outline"
            loading={busy === 'download'}
            onPress={handleDownload}
          />
          <Button
            title="Share Certificate"
            variant="secondary"
            icon="share-social-outline"
            loading={busy === 'share'}
            onPress={handleShare}
          />
          <Button
            title="View Certificate (print preview)"
            variant="outline"
            icon="print-outline"
            onPress={() => certificateService.print(certificate).catch(() => undefined)}
          />
        </View>

        <View className="mt-6 flex-row gap-2.5 rounded-2xl bg-brand-50 p-4 dark:bg-brand-950">
          <Icon name="shield-checkmark" size={17} className="text-brand-600 dark:text-brand-300" />
          <Text className="flex-1 text-[12px] leading-[17px] text-brand-700 dark:text-brand-300">
            Share this certificate ID with employers so they can verify your completion with
            Marketing Fundas.
          </Text>
        </View>
      </ScrollView>
    </Screen>
  );
}

function DetailRow({
  label,
  value,
  onPress,
  last = false,
}: {
  label: string;
  value: string;
  onPress?: () => void;
  last?: boolean;
}) {
  return (
    <View
      className={`flex-row items-center justify-between gap-3 py-2.5 ${
        last ? '' : 'border-b border-ink-100 dark:border-ink-800'
      }`}
    >
      <Text className="text-[12.5px] text-ink-400">{label}</Text>
      <Text
        numberOfLines={1}
        onPress={onPress}
        className="flex-1 text-right text-[13px] font-bold text-ink-900 dark:text-white"
      >
        {value}
        {onPress ? '  ⧉' : ''}
      </Text>
    </View>
  );
}
