import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect } from 'react';
import { Dimensions, Text, View } from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeInUp,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';

import { APP_TAGLINE } from '@/constants/config';
import { gradients } from '@/constants/theme';

const { width } = Dimensions.get('window');

/** Animated brand splash shown while the session and catalogue load. */
export function SplashScreen({ message }: { message?: string }) {
  const scale = useSharedValue(0.7);
  const glow = useSharedValue(0.35);
  const orbit = useSharedValue(0);

  useEffect(() => {
    scale.value = withSequence(
      withTiming(1.08, { duration: 520, easing: Easing.out(Easing.back(1.6)) }),
      withTiming(1, { duration: 220 }),
    );
    glow.value = withDelay(
      260,
      withRepeat(withTiming(0.85, { duration: 1400, easing: Easing.inOut(Easing.quad) }), -1, true),
    );
    orbit.value = withRepeat(withTiming(1, { duration: 9000, easing: Easing.linear }), -1, false);
  }, [glow, orbit, scale]);

  const markStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const glowStyle = useAnimatedStyle(() => ({
    opacity: glow.value,
    transform: [{ scale: 1 + glow.value * 0.35 }],
  }));
  const orbitStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${orbit.value * 360}deg` }],
  }));

  return (
    <View className="flex-1">
      <LinearGradient
        colors={gradients.hero}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
      >
        {/* Orbiting AI-inspired ring */}
        <Animated.View
          style={[
            orbitStyle,
            {
              position: 'absolute',
              width: width * 0.86,
              height: width * 0.86,
              borderRadius: width * 0.43,
              borderWidth: 1,
              borderColor: 'rgba(255,255,255,0.16)',
              borderStyle: 'dashed',
            },
          ]}
        >
          <View
            style={{ position: 'absolute', top: -5, left: width * 0.43 - 5 }}
            className="h-2.5 w-2.5 rounded-full bg-accent-300"
          />
          <View
            style={{ position: 'absolute', bottom: -4, left: width * 0.43 - 4 }}
            className="h-2 w-2 rounded-full bg-white/70"
          />
        </Animated.View>

        <Animated.View
          style={[
            glowStyle,
            {
              position: 'absolute',
              width: 200,
              height: 200,
              borderRadius: 100,
              backgroundColor: 'rgba(45,212,196,0.28)',
            },
          ]}
        />

        <Animated.View style={markStyle}>
          <View className="h-[104px] w-[104px] items-center justify-center rounded-[34px] bg-white/95">
            <Text className="text-[38px] font-extrabold tracking-tighter text-brand-700">MF</Text>
          </View>
        </Animated.View>

        <Animated.Text
          entering={FadeInUp.delay(320).duration(600)}
          className="mt-7 text-[30px] font-extrabold tracking-tight text-white"
        >
          Marketing Fundas
        </Animated.Text>

        <Animated.Text
          entering={FadeInUp.delay(480).duration(600)}
          className="mt-2 px-10 text-center text-[13.5px] leading-5 text-white/75"
        >
          {APP_TAGLINE}
        </Animated.Text>

        <Animated.View
          entering={FadeIn.delay(700).duration(600)}
          className="absolute bottom-16 items-center"
        >
          <View className="h-1 w-28 overflow-hidden rounded-full bg-white/20">
            <LoadingBar />
          </View>
          <Text className="mt-3 text-[11.5px] font-medium text-white/60">
            {message ?? 'Preparing your learning space…'}
          </Text>
        </Animated.View>
      </LinearGradient>
    </View>
  );
}

function LoadingBar() {
  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = withRepeat(
      withTiming(1, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
      -1,
      false,
    );
  }, [progress]);

  const style = useAnimatedStyle(() => ({
    transform: [{ translateX: -112 + progress.value * 224 }],
  }));

  return <Animated.View style={style} className="h-full w-16 rounded-full bg-white" />;
}
