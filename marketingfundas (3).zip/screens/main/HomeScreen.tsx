import { useRouter } from 'expo-router';
import React, { useCallback, useMemo, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, Text, View } from 'react-native';
import * as WebBrowser from 'expo-web-browser';

import { RingProgress } from '@/components/charts/RingProgress';
import { StatTile } from '@/components/charts/StatTile';
import { CategoryChips } from '@/components/course/CategoryChips';
import { CourseCard } from '@/components/course/CourseCard';
import { AiToolCard } from '@/components/home/AiToolCard';
import { ContinueLearningCard } from '@/components/home/ContinueLearningCard';
import { HomeHeader } from '@/components/home/HomeHeader';
import { Icon } from '@/components/ui/Icon';
import { CourseCardSkeleton } from '@/components/ui/Loading';
import { Screen } from '@/components/ui/Screen';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { AI_TOOLS } from '@/constants/ai-tools';
import { useAuth } from '@/context/AuthContext';
import { useLearning } from '@/context/LearningContext';
import { formatDuration } from '@/utils/format';
import { nextLessonFor } from '@/utils/progress';

export function HomeScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const {
    loading,
    courses,
    enrolledCourses,
    stats,
    unreadCount,
    courseProgress,
    refresh,
  } = useLearning();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
  }, [refresh]);

  const current = enrolledCourses.find((item) => !item.completed) ?? enrolledCourses[0];
  const nextLesson = current ? nextLessonFor(current.course, current.enrollment) : undefined;

  const popular = useMemo(
    () => [...courses].sort((a, b) => b.studentCount - a.studentCount).slice(0, 6),
    [courses],
  );

  const fresh = useMemo(
    () =>
      [...courses]
        .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
        .slice(0, 6),
    [courses],
  );

  const openTool = (url: string) => {
    WebBrowser.openBrowserAsync(url).catch(() => undefined);
  };

  return (
    <Screen>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerClassName="pb-8"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <HomeHeader
          name={user?.fullName}
          photoURL={user?.photoURL}
          unreadCount={unreadCount}
          onProfilePress={() => router.push('/(tabs)/profile')}
          onNotificationsPress={() => router.push('/notifications')}
        />

        {/* Search entry */}
        <Pressable
          accessibilityRole="search"
          onPress={() => router.push('/(tabs)/courses')}
          className="mx-5 h-12 flex-row items-center rounded-2xl border border-ink-100 bg-white px-4 dark:border-ink-800 dark:bg-ink-900"
        >
          <Icon name="search-outline" size={18} className="text-ink-400" />
          <Text className="ml-2.5 flex-1 text-[14px] text-ink-400">
            Search courses, topics, instructors
          </Text>
          <View className="h-7 w-7 items-center justify-center rounded-lg bg-brand-50 dark:bg-brand-950">
            <Icon name="sparkles" size={13} className="text-brand-600 dark:text-brand-300" />
          </View>
        </Pressable>

        {/* Continue learning */}
        {current ? (
          <View className="mt-5 px-5">
            <ContinueLearningCard
              item={current}
              nextLesson={nextLesson}
              onPress={() =>
                router.push({
                  pathname: '/learn/[courseId]',
                  params: { courseId: current.course.id, lessonId: nextLesson?.id ?? '' },
                })
              }
            />
          </View>
        ) : (
          <View className="mt-5 px-5">
            <Pressable
              accessibilityRole="button"
              onPress={() => router.push('/(tabs)/courses')}
              className="flex-row items-center gap-3 rounded-3xl border border-dashed border-brand-200 bg-brand-50 p-4 dark:border-brand-800 dark:bg-brand-950"
            >
              <View className="h-11 w-11 items-center justify-center rounded-2xl bg-white dark:bg-ink-900">
                <Icon name="rocket-outline" size={20} className="text-brand-600 dark:text-brand-300" />
              </View>
              <View className="flex-1">
                <Text className="text-[14.5px] font-extrabold text-ink-900 dark:text-white">
                  Start your first course
                </Text>
                <Text className="mt-0.5 text-[12px] text-ink-500 dark:text-ink-300">
                  Pick a track and build a skill this week.
                </Text>
              </View>
              <Icon name="chevron-forward" size={18} className="text-brand-500" />
            </Pressable>
          </View>
        )}

        {/* My progress */}
        <View className="mt-7 px-5">
          <SectionHeader
            title="My Progress"
            subtitle="Your learning at a glance"
            actionLabel="Details"
            onAction={() => router.push('/progress')}
          />

          <View className="mt-3 flex-row items-center gap-4 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
            <RingProgress value={stats.overallPercent} size={104} strokeWidth={10} caption="Overall" />
            <View className="flex-1 gap-2.5">
              <ProgressRow
                icon="albums-outline"
                label="Courses enrolled"
                value={`${stats.totalCourses}`}
              />
              <ProgressRow
                icon="checkmark-done-outline"
                label="Lessons completed"
                value={`${stats.completedLessons}/${stats.totalLessons}`}
              />
              <ProgressRow
                icon="time-outline"
                label="Time learned"
                value={formatDuration(stats.minutesLearned)}
              />
            </View>
          </View>

          <View className="mt-3 flex-row gap-3">
            <StatTile
              icon="flame-outline"
              tone="gold"
              value={`${stats.streakDays}`}
              label="Day streak"
            />
            <StatTile
              icon="trophy-outline"
              tone="success"
              value={`${stats.completedCourses}`}
              label="Completed"
            />
            <StatTile
              icon="ribbon-outline"
              tone="accent"
              value={`${stats.certificates}`}
              label="Certificates"
            />
          </View>
        </View>

        {/* Popular courses */}
        <View className="mt-8">
          <View className="px-5">
            <SectionHeader
              title="Popular Courses"
              subtitle="What learners are taking right now"
              actionLabel="See all"
              onAction={() => router.push('/(tabs)/courses')}
            />
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerClassName="gap-3 px-5 pt-3"
          >
            {loading
              ? [0, 1].map((key) => <CourseCardSkeleton key={key} />)
              : popular.map((course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                    onPress={() =>
                      router.push({ pathname: '/course/[id]', params: { id: course.id } })
                    }
                    progress={courseProgress(course.id) || undefined}
                  />
                ))}
          </ScrollView>
        </View>

        {/* New courses */}
        <View className="mt-8">
          <View className="px-5">
            <SectionHeader
              title="New Courses"
              subtitle="Freshly updated for 2026"
              actionLabel="See all"
              onAction={() => router.push('/(tabs)/courses')}
            />
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerClassName="gap-3 px-5 pt-3"
          >
            {loading
              ? [0, 1].map((key) => <CourseCardSkeleton key={key} />)
              : fresh.map((course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                    width={240}
                    onPress={() =>
                      router.push({ pathname: '/course/[id]', params: { id: course.id } })
                    }
                  />
                ))}
          </ScrollView>
        </View>

        {/* AI tools */}
        <View className="mt-8">
          <View className="px-5">
            <SectionHeader
              title="AI Tools for Marketers"
              subtitle="Hand-picked tools we teach inside the courses"
            />
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerClassName="gap-3 px-5 pt-3"
          >
            {AI_TOOLS.map((tool) => (
              <AiToolCard key={tool.id} tool={tool} onPress={() => openTool(tool.url)} />
            ))}
          </ScrollView>
        </View>

        {/* Categories */}
        <View className="mt-8">
          <View className="px-5">
            <SectionHeader title="Browse by Category" />
          </View>
          <View className="pt-3">
            <CategoryChips
              value="all"
              onChange={(category) =>
                router.push({
                  pathname: '/(tabs)/courses',
                  params: category === 'all' ? {} : { category },
                })
              }
            />
          </View>
        </View>
      </ScrollView>
    </Screen>
  );
}

function ProgressRow({
  icon,
  label,
  value,
}: {
  icon: React.ComponentProps<typeof Icon>['name'];
  label: string;
  value: string;
}) {
  return (
    <View className="flex-row items-center gap-2.5">
      <Icon name={icon} size={15} className="text-ink-400" />
      <Text className="flex-1 text-[12.5px] text-ink-500 dark:text-ink-300">{label}</Text>
      <Text className="text-[13px] font-extrabold text-ink-900 dark:text-white">{value}</Text>
    </View>
  );
}
