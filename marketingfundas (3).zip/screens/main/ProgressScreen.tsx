import { useRouter } from 'expo-router';
import React from 'react';
import { ScrollView, Text, View } from 'react-native';

import { RingProgress } from '@/components/charts/RingProgress';
import { StatTile } from '@/components/charts/StatTile';
import { WeeklyBars } from '@/components/charts/WeeklyBars';
import { AppHeader } from '@/components/ui/AppHeader';
import { EmptyState } from '@/components/ui/EmptyState';
import { Icon } from '@/components/ui/Icon';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { Screen } from '@/components/ui/Screen';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { useLearning } from '@/context/LearningContext';
import { formatDuration } from '@/utils/format';

export function ProgressScreen() {
  const router = useRouter();
  const { stats, enrolledCourses, attempts, certificates } = useLearning();

  const weeklyTotal = stats.weeklyMinutes.reduce((sum, value) => sum + value, 0);
  const bestAttempts = attempts.reduce<Record<string, number>>((map, attempt) => {
    map[attempt.courseId] = Math.max(map[attempt.courseId] ?? 0, attempt.percentage);
    return map;
  }, {});

  return (
    <Screen>
      <AppHeader title="My Progress" subtitle="Every lesson you finish counts" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-10">
        {/* Overall ring */}
        <View className="items-center rounded-[28px] border border-ink-100 bg-white p-6 dark:border-ink-800 dark:bg-ink-900">
          <RingProgress value={stats.overallPercent} size={166} strokeWidth={15} caption="Complete" />
          <Text className="mt-4 text-center text-[13.5px] leading-5 text-ink-500 dark:text-ink-300">
            {stats.completedLessons} of {stats.totalLessons} lessons finished across{' '}
            {stats.totalCourses} course{stats.totalCourses === 1 ? '' : 's'}
          </Text>
        </View>

        {/* Stat grid */}
        <View className="mt-3 flex-row gap-3">
          <StatTile
            icon="checkmark-done-outline"
            value={`${stats.completedCourses}`}
            label="Courses completed"
            tone="success"
          />
          <StatTile
            icon="play-circle-outline"
            value={`${stats.completedLessons}`}
            label="Lessons completed"
          />
        </View>
        <View className="mt-3 flex-row gap-3">
          <StatTile
            icon="flame-outline"
            value={`${stats.streakDays} day${stats.streakDays === 1 ? '' : 's'}`}
            label="Learning streak"
            tone="gold"
          />
          <StatTile
            icon="hourglass-outline"
            value={formatDuration(stats.minutesLearned)}
            label="Time spent learning"
            tone="accent"
          />
        </View>

        {/* Weekly chart */}
        <View className="mt-5 rounded-[28px] border border-ink-100 bg-white p-5 dark:border-ink-800 dark:bg-ink-900">
          <SectionHeader
            title="This week"
            subtitle={`${formatDuration(weeklyTotal)} of study in the last 7 days`}
          />
          <View className="mt-4">
            <WeeklyBars data={stats.weeklyMinutes} />
          </View>
        </View>

        {/* Per-course progress */}
        <View className="mt-6">
          <SectionHeader title="Course progress" />
          {enrolledCourses.length ? (
            <View className="mt-3 gap-3">
              {enrolledCourses.map((item) => (
                <View
                  key={item.course.id}
                  className="rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900"
                >
                  <View className="flex-row items-start justify-between gap-3">
                    <Text
                      numberOfLines={2}
                      className="flex-1 text-[14px] font-extrabold leading-5 text-ink-900 dark:text-white"
                    >
                      {item.course.title}
                    </Text>
                    <Text className="text-[14px] font-extrabold text-brand-600 dark:text-brand-300">
                      {item.percent}%
                    </Text>
                  </View>

                  <View className="mt-3">
                    <ProgressBar value={item.percent} height={7} tone={item.completed ? 'accent' : 'brand'} />
                  </View>

                  <View className="mt-3 flex-row items-center gap-4">
                    <Chip
                      icon="list-outline"
                      label={`${item.completedLessons}/${item.totalLessons} lessons`}
                    />
                    {bestAttempts[item.course.id] !== undefined ? (
                      <Chip icon="school-outline" label={`Quiz ${bestAttempts[item.course.id]}%`} />
                    ) : null}
                    {certificates.some((certificate) => certificate.courseId === item.course.id) ? (
                      <Chip icon="ribbon-outline" label="Certified" />
                    ) : null}
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <EmptyState
              icon="stats-chart-outline"
              title="No progress yet"
              message="Enrol in a course and your progress will show up here."
              actionLabel="Browse courses"
              onAction={() => router.push('/(tabs)/courses')}
            />
          )}
        </View>
      </ScrollView>
    </Screen>
  );
}

function Chip({ icon, label }: { icon: React.ComponentProps<typeof Icon>['name']; label: string }) {
  return (
    <View className="flex-row items-center gap-1.5">
      <Icon name={icon} size={13} className="text-ink-400" />
      <Text className="text-[11.5px] font-semibold text-ink-500 dark:text-ink-300">{label}</Text>
    </View>
  );
}
