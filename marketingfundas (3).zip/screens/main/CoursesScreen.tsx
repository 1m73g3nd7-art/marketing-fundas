import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { FlatList, Modal, Pressable, Text, View } from 'react-native';

import { CategoryChips } from '@/components/course/CategoryChips';
import { CourseListItem } from '@/components/course/CourseListItem';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { Icon } from '@/components/ui/Icon';
import { Screen } from '@/components/ui/Screen';
import { SearchBar } from '@/components/ui/SearchBar';
import { useLearning } from '@/context/LearningContext';
import { useDebounce } from '@/hooks/useDebounce';
import type { CategoryId, Course, CourseLevel } from '@/types';

type SortKey = 'popular' | 'rating' | 'newest' | 'price-low' | 'price-high';

const SORTS: { key: SortKey; label: string }[] = [
  { key: 'popular', label: 'Most popular' },
  { key: 'rating', label: 'Highest rated' },
  { key: 'newest', label: 'Newest' },
  { key: 'price-low', label: 'Price: low to high' },
  { key: 'price-high', label: 'Price: high to low' },
];

const LEVELS: CourseLevel[] = ['Beginner', 'Intermediate', 'Advanced', 'All Levels'];

export function CoursesScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ category?: string }>();
  const { courses, isEnrolled, enroll, wishlist, toggleWishlist } = useLearning();

  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<CategoryId | 'all'>(
    (params.category as CategoryId) ?? 'all',
  );
  const [sort, setSort] = useState<SortKey>('popular');
  const [levels, setLevels] = useState<CourseLevel[]>([]);
  const [freeOnly, setFreeOnly] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const debouncedQuery = useDebounce(query, 250);
  const filtersActive = levels.length > 0 || freeOnly || sort !== 'popular';

  const results = useMemo(() => {
    const needle = debouncedQuery.trim().toLowerCase();

    let list = courses.filter((course) => {
      if (category !== 'all' && course.category !== category) return false;
      if (levels.length && !levels.includes(course.level)) return false;
      if (freeOnly && course.price > 0) return false;
      if (!needle) return true;
      return (
        course.title.toLowerCase().includes(needle) ||
        course.subtitle.toLowerCase().includes(needle) ||
        course.instructor.name.toLowerCase().includes(needle) ||
        course.tags.some((tag) => tag.toLowerCase().includes(needle))
      );
    });

    list = [...list].sort((a, b) => {
      switch (sort) {
        case 'rating':
          return b.rating - a.rating;
        case 'newest':
          return b.updatedAt.localeCompare(a.updatedAt);
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        default:
          return b.studentCount - a.studentCount;
      }
    });

    return list;
  }, [category, courses, debouncedQuery, freeOnly, levels, sort]);

  const openCourse = (course: Course) =>
    router.push({ pathname: '/course/[id]', params: { id: course.id } });

  const handleEnroll = async (course: Course) => {
    if (isEnrolled(course.id)) {
      router.push({ pathname: '/learn/[courseId]', params: { courseId: course.id } });
      return;
    }
    await enroll(course.id);
  };

  const toggleLevel = (level: CourseLevel) =>
    setLevels((prev) =>
      prev.includes(level) ? prev.filter((item) => item !== level) : [...prev, level],
    );

  const resetFilters = () => {
    setLevels([]);
    setFreeOnly(false);
    setSort('popular');
  };

  return (
    <Screen>
      <View className="px-5 pb-3 pt-2">
        <Text className="text-[24px] font-extrabold tracking-tight text-ink-900 dark:text-white">
          Explore Courses
        </Text>
        <Text className="mt-0.5 text-[13px] text-ink-400">
          {results.length} course{results.length === 1 ? '' : 's'} across Digital Marketing and AI
        </Text>
      </View>

      <View className="px-5">
        <SearchBar
          value={query}
          onChangeText={setQuery}
          onFilterPress={() => setFiltersOpen(true)}
          filterActive={filtersActive}
        />
      </View>

      <View className="mt-3">
        <CategoryChips value={category} onChange={setCategory} />
      </View>

      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        className="mt-4"
        contentContainerClassName="px-5 pb-8"
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        renderItem={({ item }) => (
          <CourseListItem
            course={item}
            onPress={() => openCourse(item)}
            onEnroll={() => handleEnroll(item)}
            enrolled={isEnrolled(item.id)}
            saved={wishlist.includes(item.id)}
            onToggleSave={() => toggleWishlist(item.id)}
          />
        )}
        ListEmptyComponent={
          <EmptyState
            icon="search-outline"
            title="No courses found"
            message="Try a different search term, or clear the filters to see the full catalogue."
            actionLabel="Clear filters"
            onAction={() => {
              setQuery('');
              setCategory('all');
              resetFilters();
            }}
          />
        }
      />

      <FiltersSheet
        visible={filtersOpen}
        sort={sort}
        levels={levels}
        freeOnly={freeOnly}
        onSort={setSort}
        onToggleLevel={toggleLevel}
        onToggleFree={() => setFreeOnly((value) => !value)}
        onReset={resetFilters}
        onClose={() => setFiltersOpen(false)}
        resultCount={results.length}
      />
    </Screen>
  );
}

interface FiltersSheetProps {
  visible: boolean;
  sort: SortKey;
  levels: CourseLevel[];
  freeOnly: boolean;
  resultCount: number;
  onSort: (value: SortKey) => void;
  onToggleLevel: (level: CourseLevel) => void;
  onToggleFree: () => void;
  onReset: () => void;
  onClose: () => void;
}

function FiltersSheet({
  visible,
  sort,
  levels,
  freeOnly,
  resultCount,
  onSort,
  onToggleLevel,
  onToggleFree,
  onReset,
  onClose,
}: FiltersSheetProps) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable className="flex-1 bg-black/45" onPress={onClose} />
      <View className="rounded-t-[32px] bg-white px-6 pb-10 pt-5 dark:bg-ink-950">
        <View className="mb-5 h-1.5 w-12 self-center rounded-full bg-ink-200 dark:bg-ink-800" />

        <View className="flex-row items-center justify-between">
          <Text className="text-[19px] font-extrabold tracking-tight text-ink-900 dark:text-white">
            Filters
          </Text>
          <Pressable accessibilityRole="button" onPress={onReset} hitSlop={8}>
            <Text className="text-[13px] font-bold text-brand-600 dark:text-brand-300">Reset</Text>
          </Pressable>
        </View>

        <Text className="mb-2 mt-6 text-[12px] font-bold uppercase tracking-wider text-ink-400">
          Sort by
        </Text>
        <View className="gap-1">
          {SORTS.map((option) => (
            <Pressable
              key={option.key}
              accessibilityRole="radio"
              accessibilityState={{ selected: sort === option.key }}
              onPress={() => onSort(option.key)}
              className="flex-row items-center gap-3 py-2.5"
            >
              <View
                className={`h-5 w-5 items-center justify-center rounded-full border-2 ${
                  sort === option.key ? 'border-brand-600' : 'border-ink-300 dark:border-ink-600'
                }`}
              >
                {sort === option.key ? (
                  <View className="h-2.5 w-2.5 rounded-full bg-brand-600" />
                ) : null}
              </View>
              <Text className="text-[14px] font-medium text-ink-800 dark:text-ink-100">
                {option.label}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text className="mb-2 mt-6 text-[12px] font-bold uppercase tracking-wider text-ink-400">
          Level
        </Text>
        <View className="flex-row flex-wrap gap-2">
          {LEVELS.map((level) => {
            const active = levels.includes(level);
            return (
              <Pressable
                key={level}
                accessibilityRole="button"
                accessibilityState={{ selected: active }}
                onPress={() => onToggleLevel(level)}
                className={`h-9 items-center justify-center rounded-full px-4 ${
                  active
                    ? 'bg-brand-600'
                    : 'border border-ink-200 bg-white dark:border-ink-700 dark:bg-ink-900'
                }`}
              >
                <Text
                  className={`text-[13px] font-bold ${
                    active ? 'text-white' : 'text-ink-600 dark:text-ink-200'
                  }`}
                >
                  {level}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <Pressable
          accessibilityRole="switch"
          accessibilityState={{ checked: freeOnly }}
          onPress={onToggleFree}
          className="mt-6 flex-row items-center gap-3"
        >
          <View
            className={`h-5 w-5 items-center justify-center rounded-md border ${
              freeOnly ? 'border-brand-600 bg-brand-600' : 'border-ink-300 dark:border-ink-600'
            }`}
          >
            {freeOnly ? <Icon name="checkmark" size={13} color="#FFFFFF" /> : null}
          </View>
          <Text className="text-[14px] font-medium text-ink-800 dark:text-ink-100">
            Free courses only
          </Text>
        </Pressable>

        <View className="mt-8">
          <Button title={`Show ${resultCount} courses`} size="lg" onPress={onClose} />
        </View>
      </View>
    </Modal>
  );
}
