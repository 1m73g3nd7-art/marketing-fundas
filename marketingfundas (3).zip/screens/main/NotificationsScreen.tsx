import { useRouter } from 'expo-router';
import React from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';

import { AppHeader } from '@/components/ui/AppHeader';
import { EmptyState } from '@/components/ui/EmptyState';
import { Icon, type IconName } from '@/components/ui/Icon';
import { Screen } from '@/components/ui/Screen';
import { useLearning } from '@/context/LearningContext';
import type { AppNotification, NotificationType } from '@/types';
import { formatRelative } from '@/utils/format';

const META: Record<NotificationType, { icon: IconName; bg: string; tint: string }> = {
  'new-course': { icon: 'sparkles', bg: 'bg-brand-50 dark:bg-brand-950', tint: 'text-brand-600 dark:text-brand-300' },
  'new-lesson': { icon: 'play-circle', bg: 'bg-accent-100 dark:bg-accent-900', tint: 'text-accent-600 dark:text-accent-300' },
  'course-update': { icon: 'refresh-circle', bg: 'bg-ink-100 dark:bg-ink-800', tint: 'text-ink-600 dark:text-ink-200' },
  'quiz-reminder': { icon: 'help-circle', bg: 'bg-amber-100 dark:bg-amber-950', tint: 'text-amber-600 dark:text-amber-400' },
  'learning-reminder': { icon: 'alarm', bg: 'bg-amber-100 dark:bg-amber-950', tint: 'text-amber-600 dark:text-amber-400' },
  achievement: { icon: 'trophy', bg: 'bg-emerald-100 dark:bg-emerald-950', tint: 'text-emerald-600 dark:text-emerald-400' },
};

export function NotificationsScreen() {
  const router = useRouter();
  const { notifications, unreadCount, markNotificationRead, markAllNotificationsRead } =
    useLearning();

  const open = (notification: AppNotification) => {
    void markNotificationRead(notification.id);
    if (notification.courseId) {
      router.push({ pathname: '/course/[id]', params: { id: notification.courseId } });
    }
  };

  return (
    <Screen>
      <AppHeader
        title="Notifications"
        subtitle={unreadCount ? `${unreadCount} unread` : 'You are all caught up'}
        right={
          unreadCount ? (
            <Pressable
              accessibilityRole="button"
              onPress={markAllNotificationsRead}
              hitSlop={8}
              className="rounded-full bg-brand-50 px-3 py-2 dark:bg-brand-950"
            >
              <Text className="text-[12px] font-bold text-brand-600 dark:text-brand-300">
                Mark all read
              </Text>
            </Pressable>
          ) : null
        }
      />

      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        contentContainerClassName="px-5 pb-10"
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const meta = META[item.type];
          return (
            <Pressable
              accessibilityRole="button"
              onPress={() => open(item)}
              className={`mb-2.5 flex-row gap-3 rounded-3xl border p-4 ${
                item.read
                  ? 'border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900'
                  : 'border-brand-100 bg-brand-50/60 dark:border-brand-900 dark:bg-brand-950'
              }`}
            >
              <View className={`h-11 w-11 items-center justify-center rounded-2xl ${meta.bg}`}>
                <Icon name={meta.icon} size={19} className={meta.tint} />
              </View>

              <View className="flex-1">
                <View className="flex-row items-start justify-between gap-2">
                  <Text className="flex-1 text-[14px] font-extrabold leading-5 text-ink-900 dark:text-white">
                    {item.title}
                  </Text>
                  {!item.read ? <View className="mt-1.5 h-2 w-2 rounded-full bg-brand-500" /> : null}
                </View>
                <Text className="mt-1 text-[12.5px] leading-[18px] text-ink-500 dark:text-ink-300">
                  {item.body}
                </Text>
                <Text className="mt-1.5 text-[11px] text-ink-400">
                  {formatRelative(item.createdAt)}
                </Text>
              </View>
            </Pressable>
          );
        }}
        ListEmptyComponent={
          <EmptyState
            icon="notifications-off-outline"
            title="No notifications"
            message="Course updates, new lessons and learning reminders will appear here."
          />
        }
      />
    </Screen>
  );
}
