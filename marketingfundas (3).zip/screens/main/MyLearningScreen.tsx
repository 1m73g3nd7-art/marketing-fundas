import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { FlatList, Text, View } from 'react-native';

import { EnrolledCourseCard } from '@/components/course/EnrolledCourseCard';
import { EmptyState } from '@/components/ui/EmptyState';
import { Screen } from '@/components/ui/Screen';
import { SegmentedTabs } from '@/components/ui/SegmentedTabs';
import { useLearning } from '@/context/LearningContext';
import { nextLessonFor } from '@/utils/progress';

type Filter = 'all' | 'in-progress' | 'completed';

export function MyLearningScreen() {
  const router = useRouter();
  const { enrolledCourses, stats } = useLearning();
  const [filter, setFilter] = useState<Filter>('all');

  const counts = useMemo(
    () => ({
      all: enrolledCourses.length,
      'in-progress': enrolledCourses.filter((item) => !item.completed).length,
      completed: enrolledCourses.filter((item) => item.completed).length,
    }),
    [enrolledCourses],
  );

  const visible = useMemo(() => {
    if (filter === 'in-progress') return enrolledCourses.filter((item) => !item.completed);
    if (filter === 'completed') return enrolledCourses.filter((item) => item.completed);
    return enrolledCourses;
  }, [enrolledCourses, filter]);

  return (
    <Screen>
      <View className="px-5 pb-3 pt-2">
        <Text className="text-[24px] font-extrabold tracking-tight text-ink-900 dark:text-white">
          My Learning
        </Text>
        <Text className="mt-0.5 text-[13px] text-ink-400">
          {stats.completedLessons} of {stats.totalLessons} lessons completed
        </Text>
      </View>

      <View className="px-5">
        <SegmentedTabs
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'in-progress', label: 'In Progress', count: counts['in-progress'] },
            { value: 'completed', label: 'Completed', count: counts.completed },
            { value: 'all', label: 'All', count: counts.all },
          ]}
        />
      </View>

      <FlatList
        data={visible}
        keyExtractor={(item) => item.course.id}
        className="mt-4"
        contentContainerClassName="px-5 pb-8"
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <EnrolledCourseCard
            item={item}
            onPress={() =>
              router.push({ pathname: '/course/[id]', params: { id: item.course.id } })
            }
            onContinue={() =>
              router.push({
                pathname: '/learn/[courseId]',
                params: {
                  courseId: item.course.id,
                  lessonId: nextLessonFor(item.course, item.enrollment)?.id ?? '',
                },
              })
            }
          />
        )}
        ListEmptyComponent={
          <EmptyState
            icon={filter === 'completed' ? 'trophy-outline' : 'school-outline'}
            title={
              filter === 'completed'
                ? 'No completed courses yet'
                : enrolledCourses.length
                  ? 'Nothing here right now'
                  : 'You have not enrolled yet'
            }
            message={
              filter === 'completed'
                ? 'Finish all the lessons in a course and it will appear here with your certificate.'
                : 'Browse the catalogue and enrol in your first Digital Marketing or AI course.'
            }
            actionLabel="Browse courses"
            onAction={() => router.push('/(tabs)/courses')}
          />
        }
      />
    </Screen>
  );
}
