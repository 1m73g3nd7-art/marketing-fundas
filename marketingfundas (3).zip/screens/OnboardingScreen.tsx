import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import React, { useCallback, useRef, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Pressable,
  Text,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button } from '@/components/ui/Button';
import { Icon, type IconName } from '@/components/ui/Icon';
import { useOnboarding } from '@/hooks/useOnboarding';

const { width, height } = Dimensions.get('window');
const ILLUSTRATION_HEIGHT = Math.max(260, Math.min(400, height * 0.44));

interface Slide {
  key: string;
  title: string;
  body: string;
  icon: IconName;
  accents: IconName[];
  colors: readonly [string, string, ...string[]];
}

const SLIDES: Slide[] = [
  {
    key: 'learn',
    title: 'Learn Digital Marketing',
    body: 'Master the skills required to succeed in the modern digital world.',
    icon: 'rocket-outline',
    accents: ['megaphone-outline', 'search-outline', 'share-social-outline'],
    colors: ['#2F2778', '#4F3BDE'],
  },
  {
    key: 'ai',
    title: 'Learn with AI',
    body: 'Discover powerful AI tools and use them to improve your marketing skills.',
    icon: 'sparkles-outline',
    accents: ['chatbubbles-outline', 'color-palette-outline', 'flash-outline'],
    colors: ['#412FBA', '#14B8AA'],
  },
  {
    key: 'future',
    title: 'Build Your Future',
    body: 'Learn practical skills, track your progress, and become career-ready.',
    icon: 'trophy-outline',
    accents: ['ribbon-outline', 'trending-up-outline', 'briefcase-outline'],
    colors: ['#0B948B', '#4F3BDE'],
  },
];

export function OnboardingScreen() {
  const router = useRouter();
  const { complete } = useOnboarding();
  const listRef = useRef<FlatList<Slide>>(null);
  const [index, setIndex] = useState(0);

  const finish = useCallback(async () => {
    await complete();
    router.replace('/(auth)/login');
  }, [complete, router]);

  const goNext = useCallback(() => {
    if (index >= SLIDES.length - 1) return void finish();
    const next = index + 1;
    setIndex(next);
    listRef.current?.scrollToOffset({ offset: next * width, animated: true });
  }, [finish, index]);

  const onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const page = Math.round(event.nativeEvent.contentOffset.x / width);
    if (page !== index) setIndex(page);
  };

  const slide = SLIDES[index];

  return (
    <View className="flex-1 bg-ink-950">
      <LinearGradient
        colors={slide.colors}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />

      <SafeAreaView edges={['top', 'bottom']} className="flex-1">
        <View className="h-12 flex-row items-center justify-end px-5">
          {index < SLIDES.length - 1 ? (
            <Pressable accessibilityRole="button" onPress={finish} hitSlop={10}>
              <Text className="text-[14px] font-bold text-white/80">Skip</Text>
            </Pressable>
          ) : null}
        </View>

        <View style={{ height: ILLUSTRATION_HEIGHT }}>
          <FlatList
            ref={listRef}
            data={SLIDES}
            keyExtractor={(item) => item.key}
            horizontal
            pagingEnabled
            bounces={false}
            showsHorizontalScrollIndicator={false}
            onScroll={onScroll}
            scrollEventThrottle={16}
            renderItem={({ item }) => <Illustration slide={item} />}
          />
        </View>

        <View className="mt-auto rounded-t-[36px] bg-white px-7 pb-8 pt-8 dark:bg-ink-950">
          <View className="flex-row gap-2">
            {SLIDES.map((item, dot) => (
              <View
                key={item.key}
                className={`h-2 rounded-full ${
                  dot === index ? 'w-7 bg-brand-600' : 'w-2 bg-ink-200 dark:bg-ink-800'
                }`}
              />
            ))}
          </View>

          <Animated.Text
            key={`title-${slide.key}`}
            entering={FadeInUp.duration(360)}
            className="mt-5 text-[27px] font-extrabold leading-8 tracking-tight text-ink-900 dark:text-white"
          >
            {slide.title}
          </Animated.Text>

          <Animated.Text
            key={`body-${slide.key}`}
            entering={FadeInUp.delay(80).duration(360)}
            className="mt-2.5 text-[14.5px] leading-[22px] text-ink-500 dark:text-ink-300"
          >
            {slide.body}
          </Animated.Text>

          <View className="mt-7">
            <Button
              title={index === SLIDES.length - 1 ? 'Get Started' : 'Next'}
              size="lg"
              iconRight={index === SLIDES.length - 1 ? 'arrow-forward' : 'chevron-forward'}
              onPress={goNext}
            />
          </View>

          {index === SLIDES.length - 1 ? (
            <Pressable
              accessibilityRole="button"
              onPress={finish}
              className="mt-3 items-center py-2"
            >
              <Text className="text-[13px] font-semibold text-ink-400">
                Already have an account? <Text className="text-brand-600">Sign in</Text>
              </Text>
            </Pressable>
          ) : null}
        </View>
      </SafeAreaView>
    </View>
  );
}

function Illustration({ slide }: { slide: Slide }) {
  return (
    <View style={{ width, height: '100%' }} className="items-center justify-center px-10">
      <Animated.View entering={FadeInDown.duration(500)}>
        <View className="h-[188px] w-[188px] items-center justify-center rounded-[64px] border border-white/25 bg-white/10">
          <View className="h-[132px] w-[132px] items-center justify-center rounded-[46px] bg-white/95">
            <Icon name={slide.icon} size={58} color="#412FBA" />
          </View>
        </View>

        {slide.accents.map((accent, position) => {
          const layout = [
            { top: -6, left: -18 },
            { bottom: 12, left: -26 },
            { top: 30, right: -24 },
          ][position];
          return (
            <View
              key={accent}
              style={{ position: 'absolute', ...layout }}
              className="h-12 w-12 items-center justify-center rounded-2xl border border-white/25 bg-white/15"
            >
              <Icon name={accent} size={21} color="#FFFFFF" />
            </View>
          );
        })}
      </Animated.View>
    </View>
  );
}
