import * as WebBrowser from 'expo-web-browser';
import React, { useState } from 'react';
import { Linking, Pressable, ScrollView, Text, View } from 'react-native';

import { AppHeader } from '@/components/ui/AppHeader';
import { Icon } from '@/components/ui/Icon';
import { ListGroup, ListRow } from '@/components/ui/ListRow';
import { Screen } from '@/components/ui/Screen';
import { SUPPORT_EMAIL, SUPPORT_PHONE, WEBSITE } from '@/constants/config';

const FAQS = [
  {
    q: 'How long do I have access to a course?',
    a: 'Enrolment gives you lifetime access. Your progress syncs to your account, so you can switch devices any time.',
  },
  {
    q: 'When do I get my certificate?',
    a: 'Complete every lesson in the course and score at least 70% on the final assessment. The certificate appears immediately in My Certificates.',
  },
  {
    q: 'Can I retake a quiz?',
    a: 'Yes. There is no limit on attempts, and your highest score is the one recorded on your certificate.',
  },
  {
    q: 'Do the courses cover AI tools?',
    a: 'Yes. AI-Powered Marketing and AI Content Studio are dedicated AI tracks, and most other courses include AI-assisted workflows.',
  },
  {
    q: 'Can I learn offline?',
    a: 'Lesson notes and progress are stored on your device, so your learning state survives losing connection. Video streaming still needs a connection.',
  },
];

export function HelpScreen() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <Screen>
      <AppHeader title="Help & Support" subtitle="We usually reply within one working day" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-10">
        <ListGroup title="Contact us">
          <ListRow
            icon="mail-outline"
            title="Email support"
            subtitle={SUPPORT_EMAIL}
            onPress={() => Linking.openURL(`mailto:${SUPPORT_EMAIL}`).catch(() => undefined)}
          />
          <ListRow
            icon="call-outline"
            title="Call us"
            subtitle={SUPPORT_PHONE}
            onPress={() =>
              Linking.openURL(`tel:${SUPPORT_PHONE.replace(/\s/g, '')}`).catch(() => undefined)
            }
          />
          <ListRow
            icon="globe-outline"
            title="Visit our website"
            subtitle={WEBSITE.replace('https://', '')}
            onPress={() => WebBrowser.openBrowserAsync(WEBSITE).catch(() => undefined)}
          />
        </ListGroup>

        <Text className="mb-2 px-1 text-[12px] font-bold uppercase tracking-wider text-ink-400">
          Frequently asked
        </Text>

        <View className="gap-2.5">
          {FAQS.map((faq, index) => {
            const expanded = open === index;
            return (
              <Pressable
                key={faq.q}
                accessibilityRole="button"
                accessibilityState={{ expanded }}
                onPress={() => setOpen(expanded ? null : index)}
                className="rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900"
              >
                <View className="flex-row items-center gap-3">
                  <Text className="flex-1 text-[13.5px] font-bold text-ink-900 dark:text-white">
                    {faq.q}
                  </Text>
                  <Icon
                    name={expanded ? 'chevron-up' : 'chevron-down'}
                    size={16}
                    className="text-ink-400"
                  />
                </View>
                {expanded ? (
                  <Text className="mt-2.5 text-[13px] leading-[20px] text-ink-500 dark:text-ink-300">
                    {faq.a}
                  </Text>
                ) : null}
              </Pressable>
            );
          })}
        </View>
      </ScrollView>
    </Screen>
  );
}
