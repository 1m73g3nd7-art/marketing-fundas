import { useRouter } from 'expo-router';
import React from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';

import { AppHeader } from '@/components/ui/AppHeader';
import { EmptyState } from '@/components/ui/EmptyState';
import { Icon } from '@/components/ui/Icon';
import { Screen } from '@/components/ui/Screen';
import { useLearning } from '@/context/LearningContext';
import { formatDate } from '@/utils/format';

export function CertificatesScreen() {
  const router = useRouter();
  const { certificates } = useLearning();

  return (
    <Screen>
      <AppHeader
        title="My Certificates"
        subtitle={
          certificates.length
            ? `${certificates.length} certificate${certificates.length === 1 ? '' : 's'} earned`
            : 'Complete a course to earn your first'
        }
      />

      <FlatList
        data={certificates}
        keyExtractor={(item) => item.id}
        contentContainerClassName="px-5 pb-10"
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <Pressable
            accessibilityRole="button"
            onPress={() =>
              router.push({ pathname: '/certificate/[courseId]', params: { courseId: item.courseId } })
            }
            className="mb-3 flex-row items-center gap-3 rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900"
          >
            <View className="h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 dark:bg-amber-950">
              <Icon name="ribbon" size={22} className="text-amber-600 dark:text-amber-400" />
            </View>

            <View className="flex-1">
              <Text numberOfLines={2} className="text-[14px] font-extrabold leading-5 text-ink-900 dark:text-white">
                {item.courseTitle}
              </Text>
              <Text className="mt-1 text-[11.5px] text-ink-400">
                {formatDate(item.issuedAt)} · Score {item.score}% · {item.id}
              </Text>
            </View>

            <Icon name="chevron-forward" size={17} className="text-ink-300" />
          </Pressable>
        )}
        ListEmptyComponent={
          <EmptyState
            icon="ribbon-outline"
            title="No certificates yet"
            message="Finish all the lessons in a course and pass its final assessment to earn a certificate you can share."
            actionLabel="Continue learning"
            onAction={() => router.push('/(tabs)/learning')}
          />
        }
      />
    </Screen>
  );
}
