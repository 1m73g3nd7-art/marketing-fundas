import { useRouter } from 'expo-router';
import React from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';

import { AppHeader } from '@/components/ui/AppHeader';
import { Icon, type IconName } from '@/components/ui/Icon';
import { ListGroup, ListRow, SwitchRow } from '@/components/ui/ListRow';
import { Screen } from '@/components/ui/Screen';
import { useAuth } from '@/context/AuthContext';
import { useSettings } from '@/context/SettingsContext';
import type { AppSettings } from '@/types';

const THEME_OPTIONS: { value: AppSettings['themeMode']; label: string; icon: IconName }[] = [
  { value: 'light', label: 'Light', icon: 'sunny-outline' },
  { value: 'dark', label: 'Dark', icon: 'moon-outline' },
  { value: 'system', label: 'System', icon: 'phone-portrait-outline' },
];

export function SettingsScreen() {
  const router = useRouter();
  const { settings, update, setThemeMode, isDark } = useSettings();
  const { deleteAccount, signOut } = useAuth();

  const confirmDelete = () => {
    Alert.alert(
      'Delete account',
      'This permanently removes your account, enrolments, progress and certificates. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteAccount();
              router.replace('/(auth)/login');
            } catch (error) {
              Alert.alert('Could not delete account', (error as Error).message);
            }
          },
        },
      ],
    );
  };

  return (
    <Screen>
      <AppHeader title="Settings" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-10">
        {/* Appearance */}
        <View className="mb-5">
          <Text className="mb-2 px-1 text-[12px] font-bold uppercase tracking-wider text-ink-400">
            Appearance
          </Text>
          <View className="rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900">
            <SwitchRowInline
              title="Dark Mode"
              subtitle={isDark ? 'Currently on' : 'Currently off'}
              value={isDark}
              onValueChange={(value) => setThemeMode(value ? 'dark' : 'light')}
            />

            <View className="mt-4 flex-row gap-2">
              {THEME_OPTIONS.map((option) => {
                const active = settings.themeMode === option.value;
                return (
                  <Pressable
                    key={option.value}
                    accessibilityRole="radio"
                    accessibilityState={{ selected: active }}
                    onPress={() => setThemeMode(option.value)}
                    className={`flex-1 items-center gap-1.5 rounded-2xl border py-3 ${
                      active
                        ? 'border-brand-500 bg-brand-50 dark:bg-brand-950'
                        : 'border-ink-100 dark:border-ink-800'
                    }`}
                  >
                    <Icon
                      name={option.icon}
                      size={18}
                      className={active ? 'text-brand-600 dark:text-brand-300' : 'text-ink-400'}
                    />
                    <Text
                      className={`text-[12px] font-bold ${
                        active ? 'text-brand-700 dark:text-brand-200' : 'text-ink-500 dark:text-ink-300'
                      }`}
                    >
                      {option.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </View>

        <ListGroup title="Notifications">
          <SwitchRow
            icon="phone-portrait-outline"
            title="Push notifications"
            subtitle="Course updates and new lessons"
            value={settings.pushEnabled}
            onValueChange={(value) => update('pushEnabled', value)}
          />
          <SwitchRow
            icon="mail-outline"
            title="Email updates"
            subtitle="Weekly progress summary"
            value={settings.emailEnabled}
            onValueChange={(value) => update('emailEnabled', value)}
          />
          <SwitchRow
            icon="alarm-outline"
            title="Learning reminders"
            subtitle="A daily nudge to keep your streak"
            value={settings.learningReminders}
            onValueChange={(value) => update('learningReminders', value)}
          />
          <SwitchRow
            icon="help-circle-outline"
            title="Quiz reminders"
            subtitle="When an assessment is waiting"
            value={settings.quizReminders}
            onValueChange={(value) => update('quizReminders', value)}
          />
        </ListGroup>

        <ListGroup title="Playback">
          <SwitchRow
            icon="play-forward-outline"
            title="Autoplay next lesson"
            value={settings.autoplay}
            onValueChange={(value) => update('autoplay', value)}
          />
          <SwitchRow
            icon="wifi-outline"
            title="Download over Wi-Fi only"
            value={settings.downloadOverWifiOnly}
            onValueChange={(value) => update('downloadOverWifiOnly', value)}
          />
        </ListGroup>

        <ListGroup title="Security & Privacy">
          <ListRow
            icon="key-outline"
            title="Change Password"
            onPress={() => router.push('/change-password')}
          />
          <ListRow
            icon="lock-closed-outline"
            title="Privacy settings"
            subtitle="Control what other learners can see"
            onPress={() => router.push('/privacy')}
          />
        </ListGroup>

        <ListGroup title="Danger zone">
          <ListRow
            icon="log-out-outline"
            title="Log out"
            showChevron={false}
            onPress={async () => {
              await signOut();
              router.replace('/(auth)/login');
            }}
          />
          <ListRow
            icon="trash-outline"
            title="Delete Account"
            subtitle="Permanently remove your data"
            danger
            showChevron={false}
            onPress={confirmDelete}
          />
        </ListGroup>
      </ScrollView>
    </Screen>
  );
}

function SwitchRowInline({
  title,
  subtitle,
  value,
  onValueChange,
}: {
  title: string;
  subtitle: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}) {
  return (
    <View className="-mx-4 -mt-1">
      <SwitchRow
        icon="contrast-outline"
        title={title}
        subtitle={subtitle}
        value={value}
        onValueChange={onValueChange}
      />
    </View>
  );
}
