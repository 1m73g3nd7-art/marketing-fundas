import React from 'react';
import { ScrollView, Text, View } from 'react-native';

import { AppHeader } from '@/components/ui/AppHeader';
import { ListGroup, SwitchRow } from '@/components/ui/ListRow';
import { Screen } from '@/components/ui/Screen';
import { useSettings } from '@/context/SettingsContext';

const POLICY = [
  {
    title: 'What we store',
    body: 'Your name, email, phone number and learning activity — enrolments, lesson progress, quiz attempts and certificates.',
  },
  {
    title: 'How it is used',
    body: 'To show your progress, issue certificates and recommend relevant courses. We never sell your data.',
  },
  {
    title: 'Your control',
    body: 'You can edit your profile, export nothing you did not create, and delete your account and all associated records at any time from Settings.',
  },
];

export function PrivacyScreen() {
  const { settings, update } = useSettings();

  return (
    <Screen>
      <AppHeader title="Privacy" subtitle="You control what is visible" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="px-5 pb-10">
        <ListGroup title="Visibility">
          <SwitchRow
            icon="people-outline"
            title="Public profile"
            subtitle="Let other learners see your name and certificates"
            value={settings.profilePublic}
            onValueChange={(value) => update('profilePublic', value)}
          />
        </ListGroup>

        <View className="gap-3">
          {POLICY.map((item) => (
            <View
              key={item.title}
              className="rounded-3xl border border-ink-100 bg-white p-4 dark:border-ink-800 dark:bg-ink-900"
            >
              <Text className="text-[14px] font-extrabold text-ink-900 dark:text-white">
                {item.title}
              </Text>
              <Text className="mt-1.5 text-[13px] leading-[20px] text-ink-500 dark:text-ink-300">
                {item.body}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </Screen>
  );
}
