import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import React from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';

import { Avatar } from '@/components/ui/Avatar';
import { Icon } from '@/components/ui/Icon';
import { ListGroup, ListRow } from '@/components/ui/ListRow';
import { Screen } from '@/components/ui/Screen';
import { gradients } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { useLearning } from '@/context/LearningContext';
import { formatDuration } from '@/utils/format';

export function ProfileScreen() {
  const router = useRouter();
  const { user, signOut } = useAuth();
  const { stats, unreadCount } = useLearning();

  const confirmSignOut = () => {
    Alert.alert('Log out', 'Are you sure you want to log out of Marketing Fundas?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log out',
        style: 'destructive',
        onPress: async () => {
          await signOut();
          router.replace('/(auth)/login');
        },
      },
    ]);
  };

  return (
    <Screen>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="pb-10">
        {/* Profile card */}
        <View className="px-5 pt-2">
          <LinearGradient
            colors={gradients.hero}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{ borderRadius: 28, padding: 20 }}
          >
            <View className="flex-row items-center gap-4">
              <Avatar uri={user?.photoURL} name={user?.fullName} size={68} ring />
              <View className="flex-1">
                <Text numberOfLines={1} className="text-[19px] font-extrabold tracking-tight text-white">
                  {user?.fullName ?? 'Learner'}
                </Text>
                <View className="mt-1 flex-row items-center gap-1.5">
                  <Icon name="mail-outline" size={12} color="rgba(255,255,255,0.75)" />
                  <Text numberOfLines={1} className="flex-1 text-[12px] text-white/75">
                    {user?.email ?? '—'}
                  </Text>
                </View>
                {user?.phone ? (
                  <View className="mt-0.5 flex-row items-center gap-1.5">
                    <Icon name="call-outline" size={12} color="rgba(255,255,255,0.75)" />
                    <Text className="text-[12px] text-white/75">{user.phone}</Text>
                  </View>
                ) : null}
              </View>
            </View>

            <View className="mt-5 flex-row rounded-2xl bg-white/12 p-3">
              <MiniStat value={`${stats.totalCourses}`} label="Courses" />
              <View className="w-px bg-white/20" />
              <MiniStat value={formatDuration(stats.minutesLearned)} label="Learned" />
              <View className="w-px bg-white/20" />
              <MiniStat value={`${stats.certificates}`} label="Certificates" />
            </View>
          </LinearGradient>
        </View>

        <View className="mt-6 px-5">
          <ListGroup title="Account">
            <ListRow
              icon="person-outline"
              title="Edit Profile"
              subtitle="Name, phone and profile picture"
              onPress={() => router.push('/edit-profile')}
            />
            <ListRow
              icon="ribbon-outline"
              title="My Certificates"
              subtitle={`${stats.certificates} earned`}
              onPress={() => router.push('/certificates')}
            />
            <ListRow
              icon="stats-chart-outline"
              title="My Progress"
              subtitle="Streak, time spent and completion"
              onPress={() => router.push('/progress')}
            />
            <ListRow
              icon="notifications-outline"
              title="Notifications"
              subtitle={unreadCount ? `${unreadCount} unread` : 'All caught up'}
              onPress={() => router.push('/notifications')}
            />
          </ListGroup>

          <ListGroup title="Preferences">
            <ListRow
              icon="settings-outline"
              title="Settings"
              subtitle="Appearance, notifications and privacy"
              onPress={() => router.push('/settings')}
            />
            <ListRow
              icon="help-buoy-outline"
              title="Help & Support"
              subtitle="FAQs and contact options"
              onPress={() => router.push('/help')}
            />
          </ListGroup>

          <ListGroup>
            <ListRow icon="log-out-outline" title="Logout" danger showChevron={false} onPress={confirmSignOut} />
          </ListGroup>

          <Text className="mt-2 text-center text-[11.5px] text-ink-400">
            Marketing Fundas · v1.0.0
          </Text>
        </View>
      </ScrollView>
    </Screen>
  );
}

function MiniStat({ value, label }: { value: string; label: string }) {
  return (
    <View className="flex-1 items-center">
      <Text className="text-[15px] font-extrabold text-white">{value}</Text>
      <Text className="mt-0.5 text-[10.5px] font-semibold uppercase tracking-wider text-white/65">
        {label}
      </Text>
    </View>
  );
}
