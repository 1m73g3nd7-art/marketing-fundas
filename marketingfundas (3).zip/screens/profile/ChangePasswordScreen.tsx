import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Text, View } from 'react-native';

import { AppHeader } from '@/components/ui/AppHeader';
import { Button } from '@/components/ui/Button';
import { Icon } from '@/components/ui/Icon';
import { Input } from '@/components/ui/Input';
import { Screen } from '@/components/ui/Screen';
import { useAuth } from '@/context/AuthContext';
import { passwordStrength } from '@/utils/validation';

export function ChangePasswordScreen() {
  const router = useRouter();
  const { changePassword, busy } = useAuth();

  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState<{ current?: string; next?: string; confirm?: string }>({});
  const [formError, setFormError] = useState<string | null>(null);

  const strength = useMemo(() => passwordStrength(next), [next]);

  const submit = async () => {
    const nextErrors: typeof errors = {};
    if (!current) nextErrors.current = 'Enter your current password';
    if (next.length < 8) nextErrors.next = 'Use at least 8 characters';
    if (confirm !== next) nextErrors.confirm = 'Passwords do not match';
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;

    try {
      await changePassword(current, next);
      Alert.alert('Password updated', 'Use your new password the next time you sign in.');
      router.back();
    } catch (error) {
      setFormError((error as Error).message);
    }
  };

  return (
    <Screen>
      <AppHeader title="Change Password" />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        className="flex-1"
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerClassName="px-5 pb-10"
          keyboardShouldPersistTaps="handled"
        >
          <View className="gap-4 pt-2">
            <Input
              label="Current Password"
              icon="lock-closed-outline"
              secure
              value={current}
              onChangeText={(text) => {
                setCurrent(text);
                setErrors((prev) => ({ ...prev, current: undefined }));
                setFormError(null);
              }}
              error={errors.current}
            />

            <View>
              <Input
                label="New Password"
                icon="key-outline"
                secure
                value={next}
                onChangeText={(text) => {
                  setNext(text);
                  setErrors((prev) => ({ ...prev, next: undefined }));
                }}
                error={errors.next}
              />
              {next.length > 0 && !errors.next ? (
                <View className="mt-2 flex-row items-center gap-2">
                  <View className="h-1.5 flex-1 flex-row gap-1">
                    {[0, 1, 2, 3].map((bar) => (
                      <View
                        key={bar}
                        className="h-full flex-1 rounded-full bg-ink-100 dark:bg-ink-800"
                        style={bar < strength.score ? { backgroundColor: strength.color } : undefined}
                      />
                    ))}
                  </View>
                  <Text className="text-[11px] font-bold" style={{ color: strength.color }}>
                    {strength.label}
                  </Text>
                </View>
              ) : null}
            </View>

            <Input
              label="Confirm New Password"
              icon="shield-checkmark-outline"
              secure
              value={confirm}
              onChangeText={(text) => {
                setConfirm(text);
                setErrors((prev) => ({ ...prev, confirm: undefined }));
              }}
              error={errors.confirm}
            />
          </View>

          {formError ? (
            <View className="mt-4 flex-row items-center gap-2 rounded-2xl bg-red-50 px-4 py-3 dark:bg-red-950">
              <Icon name="alert-circle" size={16} className="text-red-500" />
              <Text className="flex-1 text-[13px] font-medium text-red-600 dark:text-red-300">
                {formError}
              </Text>
            </View>
          ) : null}

          <View className="mt-7">
            <Button title="Update Password" size="lg" loading={busy} onPress={submit} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}
