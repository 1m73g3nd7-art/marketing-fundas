import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native';

import { AppHeader } from '@/components/ui/AppHeader';
import { Avatar } from '@/components/ui/Avatar';
import { Button } from '@/components/ui/Button';
import { Icon } from '@/components/ui/Icon';
import { Input } from '@/components/ui/Input';
import { Screen } from '@/components/ui/Screen';
import { useAuth } from '@/context/AuthContext';
import { isPhone } from '@/utils/validation';

export function EditProfileScreen() {
  const router = useRouter();
  const { user, updateProfile, busy } = useAuth();

  const [fullName, setFullName] = useState(user?.fullName ?? '');
  const [phone, setPhone] = useState(user?.phone ?? '');
  const [headline, setHeadline] = useState(user?.headline ?? '');
  const [photoURL, setPhotoURL] = useState(user?.photoURL ?? '');
  const [errors, setErrors] = useState<{ fullName?: string; phone?: string }>({});

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(
        'Permission needed',
        'Allow photo access in your device settings to change your profile picture.',
      );
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });
    if (!result.canceled && result.assets[0]?.uri) setPhotoURL(result.assets[0].uri);
  };

  const save = async () => {
    const nextErrors: typeof errors = {};
    if (fullName.trim().length < 3) nextErrors.fullName = 'Please enter your full name';
    if (phone.trim() && !isPhone(phone)) nextErrors.phone = 'Enter a valid phone number';
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;

    try {
      await updateProfile({
        fullName: fullName.trim(),
        phone: phone.trim(),
        headline: headline.trim(),
        photoURL: photoURL || undefined,
      });
      Alert.alert('Profile updated', 'Your changes have been saved.');
      router.back();
    } catch (error) {
      Alert.alert('Could not save', (error as Error).message);
    }
  };

  return (
    <Screen>
      <AppHeader title="Edit Profile" subtitle="Keep your details up to date" />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        className="flex-1"
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerClassName="px-5 pb-10"
          keyboardShouldPersistTaps="handled"
        >
          <View className="items-center py-4">
            <Pressable accessibilityRole="button" accessibilityLabel="Change photo" onPress={pickImage}>
              <Avatar uri={photoURL || undefined} name={fullName} size={104} ring />
              <View className="absolute bottom-0 right-0 h-9 w-9 items-center justify-center rounded-full border-[3px] border-ink-50 bg-brand-600 dark:border-ink-950">
                <Icon name="camera" size={15} color="#FFFFFF" />
              </View>
            </Pressable>
            <Text className="mt-3 text-[12.5px] font-semibold text-brand-600 dark:text-brand-300">
              Tap to change photo
            </Text>
          </View>

          <View className="gap-4">
            <Input
              label="Full Name"
              icon="person-outline"
              value={fullName}
              onChangeText={(text) => {
                setFullName(text);
                setErrors((prev) => ({ ...prev, fullName: undefined }));
              }}
              error={errors.fullName}
              autoCapitalize="words"
            />

            <Input
              label="Email"
              icon="mail-outline"
              value={user?.email ?? ''}
              editable={false}
              hint="Email cannot be changed from the app"
            />

            <Input
              label="Phone Number"
              icon="call-outline"
              value={phone}
              onChangeText={(text) => {
                setPhone(text);
                setErrors((prev) => ({ ...prev, phone: undefined }));
              }}
              error={errors.phone}
              keyboardType="phone-pad"
            />

            <Input
              label="Headline"
              icon="pricetag-outline"
              placeholder="e.g. Performance marketer learning AI"
              value={headline}
              onChangeText={setHeadline}
            />
          </View>

          <View className="mt-7 gap-3">
            <Button title="Save Changes" size="lg" loading={busy} onPress={save} />
            <Button title="Cancel" variant="ghost" onPress={() => router.back()} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}
