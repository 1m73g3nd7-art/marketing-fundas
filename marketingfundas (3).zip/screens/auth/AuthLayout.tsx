import { LinearGradient } from 'expo-linear-gradient';
import React, { type ReactNode } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Text,
  View,
} from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BrandLogo } from '@/components/ui/BrandLogo';
import { IconButton } from '@/components/ui/IconButton';
import { gradients } from '@/constants/theme';

interface AuthLayoutProps {
  title: string;
  subtitle: string;
  children: ReactNode;
  onBack?: () => void;
}

/** Shared gradient header + white sheet used across the auth flow. */
export function AuthLayout({ title, subtitle, children, onBack }: AuthLayoutProps) {
  return (
    <View className="flex-1 bg-white dark:bg-ink-950">
      <LinearGradient
        colors={gradients.hero}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 260 }}
      />

      <SafeAreaView edges={['top']} className="flex-1">
        <View className="flex-row items-center gap-3 px-5 pb-2 pt-1">
          {onBack ? (
            <IconButton
              name="chevron-back"
              variant="glass"
              accessibilityLabel="Go back"
              onPress={onBack}
            />
          ) : null}
          <BrandLogo size={38} inverted />
        </View>

        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          className="flex-1"
        >
          <ScrollView
            className="flex-1"
            contentContainerClassName="grow"
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <Animated.View
              entering={FadeInDown.duration(420)}
              className="mt-6 flex-1 rounded-t-[36px] bg-white px-6 pb-10 pt-8 dark:bg-ink-950"
            >
              <Text className="text-[27px] font-extrabold tracking-tight text-ink-900 dark:text-white">
                {title}
              </Text>
              <Text className="mt-1.5 text-[14px] leading-5 text-ink-400">{subtitle}</Text>

              <View className="mt-7">{children}</View>
            </Animated.View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}
