import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, Text, View } from 'react-native';

import { Button } from '@/components/ui/Button';
import { Icon } from '@/components/ui/Icon';
import { Input } from '@/components/ui/Input';
import { useAuth } from '@/context/AuthContext';
import { hasErrors, passwordStrength, validateSignup, type Errors } from '@/utils/validation';
import { AuthLayout } from './AuthLayout';

type Values = {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
};

const EMPTY: Values = {
  fullName: '',
  email: '',
  phone: '',
  password: '',
  confirmPassword: '',
};

export function SignupScreen() {
  const router = useRouter();
  const { signUp, busy } = useAuth();
  const [values, setValues] = useState<Values>(EMPTY);
  const [errors, setErrors] = useState<Errors<Values>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [accepted, setAccepted] = useState(true);

  const strength = useMemo(() => passwordStrength(values.password), [values.password]);

  const setField = (key: keyof Values) => (text: string) => {
    setValues((prev) => ({ ...prev, [key]: text }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
    if (formError) setFormError(null);
  };

  const submit = async () => {
    const nextErrors = validateSignup(values);
    setErrors(nextErrors);
    if (hasErrors(nextErrors)) return;
    if (!accepted) {
      setFormError('Please accept the Terms of Use and Privacy Policy to continue.');
      return;
    }

    try {
      await signUp({
        fullName: values.fullName,
        email: values.email,
        phone: values.phone,
        password: values.password,
      });
      router.replace('/(tabs)');
    } catch (error) {
      setFormError((error as Error).message);
    }
  };

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Start learning Digital Marketing and AI in minutes."
      onBack={() => router.back()}
    >
      <View className="gap-4">
        <Input
          label="Full Name"
          icon="person-outline"
          placeholder="Your full name"
          autoCapitalize="words"
          autoComplete="name"
          value={values.fullName}
          onChangeText={setField('fullName')}
          error={errors.fullName}
        />

        <Input
          label="Email"
          icon="mail-outline"
          placeholder="you@example.com"
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
          value={values.email}
          onChangeText={setField('email')}
          error={errors.email}
        />

        <Input
          label="Phone Number"
          icon="call-outline"
          placeholder="+91 90000 00000"
          keyboardType="phone-pad"
          autoComplete="tel"
          value={values.phone}
          onChangeText={setField('phone')}
          error={errors.phone}
        />

        <View>
          <Input
            label="Password"
            icon="lock-closed-outline"
            placeholder="At least 8 characters"
            secure
            value={values.password}
            onChangeText={setField('password')}
            error={errors.password}
          />
          {values.password.length > 0 && !errors.password ? (
            <View className="mt-2 flex-row items-center gap-2">
              <View className="h-1.5 flex-1 flex-row gap-1">
                {[0, 1, 2, 3].map((bar) => (
                  <View
                    key={bar}
                    className="h-full flex-1 rounded-full bg-ink-100 dark:bg-ink-800"
                    style={bar < strength.score ? { backgroundColor: strength.color } : undefined}
                  />
                ))}
              </View>
              <Text className="text-[11px] font-bold" style={{ color: strength.color }}>
                {strength.label}
              </Text>
            </View>
          ) : null}
        </View>

        <Input
          label="Confirm Password"
          icon="shield-checkmark-outline"
          placeholder="Re-enter your password"
          secure
          value={values.confirmPassword}
          onChangeText={setField('confirmPassword')}
          error={errors.confirmPassword}
        />
      </View>

      <Pressable
        accessibilityRole="checkbox"
        accessibilityState={{ checked: accepted }}
        onPress={() => setAccepted((value) => !value)}
        className="mt-5 flex-row items-start gap-3"
      >
        <View
          className={`mt-0.5 h-5 w-5 items-center justify-center rounded-md border ${
            accepted ? 'border-brand-600 bg-brand-600' : 'border-ink-300 dark:border-ink-600'
          }`}
        >
          {accepted ? <Icon name="checkmark" size={13} color="#FFFFFF" /> : null}
        </View>
        <Text className="flex-1 text-[12.5px] leading-[18px] text-ink-500 dark:text-ink-300">
          I agree to the Marketing Fundas Terms of Use and Privacy Policy.
        </Text>
      </Pressable>

      {formError ? (
        <View className="mt-4 flex-row items-center gap-2 rounded-2xl bg-red-50 px-4 py-3 dark:bg-red-950">
          <Icon name="alert-circle" size={16} className="text-red-500" />
          <Text className="flex-1 text-[13px] font-medium text-red-600 dark:text-red-300">
            {formError}
          </Text>
        </View>
      ) : null}

      <View className="mt-6">
        <Button title="Create Account" size="lg" loading={busy} onPress={submit} />
      </View>

      <View className="mt-6 flex-row items-center justify-center gap-1">
        <Text className="text-[13.5px] text-ink-400">Already have an account?</Text>
        <Pressable accessibilityRole="button" onPress={() => router.replace('/(auth)/login')} hitSlop={8}>
          <Text className="text-[13.5px] font-extrabold text-brand-600 dark:text-brand-300">
            Login
          </Text>
        </Pressable>
      </View>
    </AuthLayout>
  );
}
