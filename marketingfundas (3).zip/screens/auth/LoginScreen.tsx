import { useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { Pressable, Text, View } from 'react-native';

import { Button } from '@/components/ui/Button';
import { Divider } from '@/components/ui/Divider';
import { Icon } from '@/components/ui/Icon';
import { Input } from '@/components/ui/Input';
import { useAuth } from '@/context/AuthContext';
import { useGoogleAuth } from '@/hooks/useGoogleAuth';
import { hasErrors, validateLogin, type Errors } from '@/utils/validation';
import { AuthLayout } from './AuthLayout';
import { GoogleButton } from './GoogleButton';

type Values = { email: string; password: string };

export function LoginScreen() {
  const router = useRouter();
  const { signIn, busy, isDemoMode } = useAuth();
  const [values, setValues] = useState<Values>({ email: '', password: '' });
  const [errors, setErrors] = useState<Errors<Values>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [googleBusy, setGoogleBusy] = useState(false);

  const { signIn: googleSignIn, disabled: googleDisabled } = useGoogleAuth(
    useCallback((message: string) => {
      setFormError(message);
      setGoogleBusy(false);
    }, []),
  );

  const setField = (key: keyof Values) => (text: string) => {
    setValues((prev) => ({ ...prev, [key]: text }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
    if (formError) setFormError(null);
  };

  const submit = async () => {
    const nextErrors = validateLogin(values);
    setErrors(nextErrors);
    if (hasErrors(nextErrors)) return;

    try {
      await signIn(values.email, values.password);
      router.replace('/(tabs)');
    } catch (error) {
      setFormError((error as Error).message);
    }
  };

  const handleGoogle = async () => {
    setGoogleBusy(true);
    setFormError(null);
    try {
      await googleSignIn();
      router.replace('/(tabs)');
    } catch (error) {
      setFormError((error as Error).message);
    } finally {
      setGoogleBusy(false);
    }
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Sign in to continue your Digital Marketing + AI journey."
    >
      <View className="gap-4">
        <Input
          label="Email"
          icon="mail-outline"
          placeholder="you@example.com"
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
          value={values.email}
          onChangeText={setField('email')}
          error={errors.email}
        />

        <Input
          label="Password"
          icon="lock-closed-outline"
          placeholder="Enter your password"
          secure
          autoComplete="password"
          value={values.password}
          onChangeText={setField('password')}
          error={errors.password}
        />
      </View>

      <Pressable
        accessibilityRole="button"
        onPress={() => router.push('/(auth)/forgot-password')}
        className="mt-3 self-end py-1"
        hitSlop={8}
      >
        <Text className="text-[13px] font-bold text-brand-600 dark:text-brand-300">
          Forgot password?
        </Text>
      </Pressable>

      {formError ? (
        <View className="mt-4 flex-row items-center gap-2 rounded-2xl bg-red-50 px-4 py-3 dark:bg-red-950">
          <Icon name="alert-circle" size={16} className="text-red-500" />
          <Text className="flex-1 text-[13px] font-medium text-red-600 dark:text-red-300">
            {formError}
          </Text>
        </View>
      ) : null}

      <View className="mt-6">
        <Button title="Login" size="lg" loading={busy} onPress={submit} />
      </View>

      <Divider label="or" className="my-6" />

      <GoogleButton onPress={handleGoogle} disabled={googleDisabled} loading={googleBusy} />

      <View className="mt-7 flex-row items-center justify-center gap-1">
        <Text className="text-[13.5px] text-ink-400">Don&apos;t have an account?</Text>
        <Pressable accessibilityRole="button" onPress={() => router.push('/(auth)/signup')} hitSlop={8}>
          <Text className="text-[13.5px] font-extrabold text-brand-600 dark:text-brand-300">
            Sign Up
          </Text>
        </Pressable>
      </View>

      {isDemoMode ? (
        <View className="mt-8 flex-row gap-2.5 rounded-2xl border border-brand-100 bg-brand-50 p-4 dark:border-brand-900 dark:bg-brand-950">
          <Icon name="information-circle" size={17} className="text-brand-600 dark:text-brand-300" />
          <View className="flex-1">
            <Text className="text-[12.5px] font-bold text-brand-800 dark:text-brand-200">
              Demo mode
            </Text>
            <Text className="mt-1 text-[12px] leading-[17px] text-brand-700 dark:text-brand-300">
              Firebase is not configured yet, so accounts are stored on this device. Create an
              account, or tap Continue with Google to sign in as a sample learner.
            </Text>
          </View>
        </View>
      ) : null}
    </AuthLayout>
  );
}
