import React from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';

import { Icon } from '@/components/ui/Icon';

interface GoogleButtonProps {
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  label?: string;
}

export function GoogleButton({
  onPress,
  disabled,
  loading,
  label = 'Continue with Google',
}: GoogleButtonProps) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={onPress}
      className="h-14 w-full flex-row items-center justify-center gap-2.5 rounded-2xl border border-ink-200 bg-white dark:border-ink-700 dark:bg-ink-900"
      style={({ pressed }) => ({ opacity: pressed || disabled ? 0.8 : 1 })}
    >
      {loading ? (
        <ActivityIndicator size="small" color="#6355F0" />
      ) : (
        <View className="h-6 w-6 items-center justify-center">
          <Icon name="logo-google" size={19} color="#EA4335" />
        </View>
      )}
      <Text className="text-[15px] font-bold text-ink-800 dark:text-ink-100">{label}</Text>
    </Pressable>
  );
}
