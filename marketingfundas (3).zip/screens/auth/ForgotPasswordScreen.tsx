import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Text, View } from 'react-native';

import { Button } from '@/components/ui/Button';
import { Icon } from '@/components/ui/Icon';
import { Input } from '@/components/ui/Input';
import { useAuth } from '@/context/AuthContext';
import { isEmail } from '@/utils/validation';
import { AuthLayout } from './AuthLayout';

export function ForgotPasswordScreen() {
  const router = useRouter();
  const { resetPassword, busy, isDemoMode } = useAuth();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | undefined>();
  const [sent, setSent] = useState(false);

  const submit = async () => {
    if (!isEmail(email)) {
      setError('Enter a valid email address');
      return;
    }
    setError(undefined);
    try {
      await resetPassword(email);
      setSent(true);
    } catch (caught) {
      setError((caught as Error).message);
    }
  };

  if (sent) {
    return (
      <AuthLayout
        title="Check your inbox"
        subtitle="We have sent password reset instructions to your email."
        onBack={() => router.back()}
      >
        <View className="items-center rounded-3xl border border-ink-100 bg-white p-7 dark:border-ink-800 dark:bg-ink-900">
          <View className="h-16 w-16 items-center justify-center rounded-3xl bg-emerald-100 dark:bg-emerald-950">
            <Icon name="mail-open-outline" size={28} className="text-emerald-600 dark:text-emerald-400" />
          </View>
          <Text className="mt-4 text-center text-[15px] font-bold text-ink-900 dark:text-white">
            Reset link sent to {email}
          </Text>
          <Text className="mt-2 text-center text-[13px] leading-5 text-ink-400">
            {isDemoMode
              ? 'Demo mode does not send real email. Sign in again with your existing password.'
              : 'Follow the link in the email to choose a new password. It expires in one hour.'}
          </Text>
        </View>

        <View className="mt-6">
          <Button title="Back to Login" size="lg" onPress={() => router.replace('/(auth)/login')} />
        </View>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      title="Forgot password?"
      subtitle="Enter the email linked to your account and we will send you a reset link."
      onBack={() => router.back()}
    >
      <Input
        label="Email"
        icon="mail-outline"
        placeholder="you@example.com"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={(text) => {
          setEmail(text);
          if (error) setError(undefined);
        }}
        error={error}
      />

      <View className="mt-6">
        <Button title="Send Reset Link" size="lg" loading={busy} onPress={submit} />
      </View>
    </AuthLayout>
  );
}
